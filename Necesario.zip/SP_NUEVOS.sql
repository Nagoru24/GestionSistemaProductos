﻿/* ----------------------- LOGIN DE LA PAGINA ---------------------------- ******************************/

---------- LOGIN ---------------------------------
CREATE OR ALTER PROCEDURE SP_LOGIN
    @USUARIO_NT VARCHAR(50),
    @CONTRASENA VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        F.ID_FUNCIONARIO AS idFuncionario,
        F.USUARIO_NT AS usuario,
        (F.PRIMER_NOMBRE + ' ' + F.APELLIDO_PATERNO) AS nombre,
        R.NOMBRE_ROL AS rol,
        F.COD_DIR AS codDir,
        F.COD_DEPTO AS codDepto,
        D.DESC_DEPARTAMENTO AS descDepartamento -- <-- CAMPO NUEVO AÑADIDO
    FROM T_DIM_FUNCIONARIO F
    INNER JOIN T_DIM_ROL R ON F.COD_ROL = R.COD_ROL
    INNER JOIN T_DIM_DEPARTAMENTO D ON F.COD_DIR = D.COD_DIR AND F.COD_DEPTO = D.COD_DEPTO -- <-- JOIN NUEVO AÑADIDO
    WHERE F.USUARIO_NT = @USUARIO_NT
      AND F.CONTRASENA = @CONTRASENA
      AND F.ESTADO_REGISTRO = 1;
END;
GO

/* ----------------------- PAGINA PARA CREAR PROYECTOS ---------------------------- ****************************************/

-----------  OBTIENE DATOS DE PARA EL FORMULARIO DE CREAR PROYECTOS  ----------------
CREATE OR ALTER PROCEDURE SP_GET_FORMULARIO_DATA
AS
BEGIN
    SET NOCOUNT ON;
    SELECT COD_DIR, COD_DEPTO, DESC_DEPARTAMENTO FROM T_DIM_DEPARTAMENTO WHERE ESTADO_REGISTRO = 1;
    SELECT COD_DIR, DESC_DIR FROM T_DIM_DIRECCION WHERE ESTADO_REGISTRO = 1;
    SELECT COD_TIPO, DESC_TIPO FROM T_DIM_TIPO_PROYECTO WHERE ESTADO_REGISTRO = 1;
    SELECT COD_PRIORIDAD, DESC_PRIORIDAD FROM T_DIM_PRIORIDAD WHERE ESTADO_REGISTRO = 1;
    SELECT COD_RELACION, SIGLAS_RELACION, DESC_RELACION FROM T_DIM_RELACION WHERE ESTADO_REGISTRO = 1;
END;
GO

---------- OBTIENE LOS PROYECTOS POR GERENCIA ----------------------
CREATE OR ALTER PROCEDURE SP_GET_PROYECTOS_POR_DEPARTAMENTO
    @COD_DIR INT,
    @COD_DEPTO INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ID_PROYECTO,
        p.DESC_PROYECTO,
        p.ALCANCE_PROYECTO,
        p.COD_ESTATUS,
        p.AVANCE_ALCANZADO,
        p.AVANCE_ESPERADO,
        p.FECHA_ENTREGA_ASIGNADA,
        -- CAMBIO: Se añade el nombre del departamento
        d.DESC_DEPARTAMENTO, 
        (SELECT COUNT(*) 
         FROM T_REL_FUNCIONARIO rf 
         WHERE rf.ID_PROYECTO = p.ID_PROYECTO AND rf.ESTADO_REGISTRO = 1) AS NUM_COLABORADORES
    FROM T_FACT_PROYECTO p
    -- CAMBIO: Se une con la tabla de departamentos para obtener el nombre
    INNER JOIN T_DIM_DEPARTAMENTO d ON p.COD_DIR = d.COD_DIR AND p.COD_DEPTO = d.COD_DEPTO
    WHERE 
        p.COD_DIR = @COD_DIR 
        AND p.COD_DEPTO = @COD_DEPTO
        AND p.ESTADO_REGISTRO = 1;
END
GO

------------------ OBTENER CATEGORIA POR DEPARTAMENTO -------------------
CREATE OR ALTER PROCEDURE SP_GET_CATEGORIAS_POR_DEPARTAMENTO
    @COD_DIR INT,
    @COD_DEPTO INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT COD_CATEGORIA, DESC_CATEGORIA
    FROM T_DIM_CATEGORIA
    WHERE COD_DIR = @COD_DIR 
      AND COD_DEPTO = @COD_DEPTO 
      AND ESTADO_REGISTRO = 1;
END;
GO

----------------- SP PARA CREAR EL PROYECTO ---------------------------
CREATE PROCEDURE SP_CREATE_PROYECTO
    @ROL VARCHAR(50),
    @ID_FUNCIONARIO INT,
    @COD_DIR INT,
    @COD_DEPTO INT,
    @ID_ARANDA VARCHAR(50),
    @UNIDAD_SOLICITANTE INT,
    @COD_CATEGORIA INT,
    @COD_RELACION INT,
    @COD_TIPO INT,
    @COD_PRIORIDAD INT,
    @DESC_PROYECTO VARCHAR(255),
    @ALCANCE_PROYECTO VARCHAR(600),
    @FECHA_INICIAL_PLANIFICADA DATE,
    @FECHA_FINAL_PLANIFICADA DATE,
    @MONTO_INVERSION DECIMAL(18, 2),
    @USUARIO_CREACION VARCHAR(100),
    @ID_PROYECTO_RELACIONADO INT,
    @TIPO_RELACION VARCHAR(50),
    @COD_ESTATUS INT,
    @ID_PROYECTO_OUT INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @RESPONSABLE_ID INT;
    DECLARE @NewProjectID INT;
    DECLARE @PERIODO INT;
    DECLARE @MES INT;

    BEGIN TRY
        BEGIN TRANSACTION;
        IF @ROL = 'Gerente'
        BEGIN
            IF NOT EXISTS (SELECT 1 FROM T_DIM_FUNCIONARIO WHERE ID_FUNCIONARIO = @ID_FUNCIONARIO AND COD_DIR = @COD_DIR AND COD_DEPTO = @COD_DEPTO)
                THROW 50001, 'Error de permiso: Como Gerente, solo puedes crear proyectos en tu propio departamento.', 1;
            SET @RESPONSABLE_ID = @ID_FUNCIONARIO;
        END
        ELSE IF @ROL = 'PM'
        BEGIN
            -- Verificar si el departamento seleccionado es el mismo que el del usuario PM
            IF EXISTS (SELECT 1 FROM T_DIM_FUNCIONARIO WHERE ID_FUNCIONARIO = @ID_FUNCIONARIO AND COD_DIR = @COD_DIR AND COD_DEPTO = @COD_DEPTO)
            BEGIN
                -- Si el PM crea el proyecto en su propia gerencia, se asigna como responsable
                SET @RESPONSABLE_ID = @ID_FUNCIONARIO;
            END
            ELSE
            BEGIN
                -- Si el PM selecciona otro departamento, buscar el gerente activo
                SELECT @RESPONSABLE_ID = F.ID_FUNCIONARIO
                FROM T_DIM_FUNCIONARIO F 
                JOIN T_DIM_ROL R ON F.COD_ROL = R.COD_ROL
                WHERE F.COD_DIR = @COD_DIR AND F.COD_DEPTO = @COD_DEPTO 
                AND R.NOMBRE_ROL = 'Gerente' AND F.ESTADO_REGISTRO = 1;

                IF @RESPONSABLE_ID IS NULL
                BEGIN
                    -- Asignar el PM como responsable si no hay gerente
                    SET @RESPONSABLE_ID = @ID_FUNCIONARIO;
                    INSERT INTO T_DIM_AUDITORIA (USUARIO, ENTIDAD, ID_REGISTRO, ACCION, MOTIVO_EVENTO)
                    VALUES (@USUARIO_CREACION, 'T_FACT_PROYECTO', NULL, 'WARNING', 'No se encontró gerente activo para el departamento, se asignó el PM como responsable.');
                END
            END
        END
        ELSE
            THROW 50003, 'Error de rol: Tu rol no tiene permisos para crear proyectos.', 1;

        SET @PERIODO = YEAR(@FECHA_INICIAL_PLANIFICADA);
        SET @MES = MONTH(@FECHA_INICIAL_PLANIFICADA);

        INSERT INTO T_FACT_PROYECTO (ID_FUNCIONARIO, ID_ARANDA, PERIODO, MES, COD_CATEGORIA, COD_RELACION, COD_TIPO, COD_PRIORIDAD, COD_ESTATUS, UNIDAD_SOLICITANTE, COD_DIR, COD_DEPTO, MONTO_INVERSION, DESC_PROYECTO, ALCANCE_PROYECTO, FECHA_INICIAL_PLANIFICADA, FECHA_FINAL_PLANIFICADA, USUARIO_CREACION)
        VALUES (@RESPONSABLE_ID, @ID_ARANDA, @PERIODO, @MES, @COD_CATEGORIA, @COD_RELACION, @COD_TIPO, @COD_PRIORIDAD, @COD_ESTATUS, @UNIDAD_SOLICITANTE, @COD_DIR, @COD_DEPTO, @MONTO_INVERSION, @DESC_PROYECTO, @ALCANCE_PROYECTO, @FECHA_INICIAL_PLANIFICADA, @FECHA_FINAL_PLANIFICADA, @USUARIO_CREACION);
        SET @NewProjectID = SCOPE_IDENTITY();

        IF @ID_PROYECTO_RELACIONADO IS NOT NULL AND @ID_PROYECTO_RELACIONADO > 0
        BEGIN
            INSERT INTO T_REL_PROYECTO_PROYECTO (ID_PROYECTO_BASE, ID_PROYECTO_RELACIONADO, TIPO_RELACION, USUARIO_CREACION)
            VALUES (@NewProjectID, @ID_PROYECTO_RELACIONADO, @TIPO_RELACION, @USUARIO_CREACION);
        END
        
        INSERT INTO T_DIM_AUDITORIA (USUARIO, ENTIDAD, ID_REGISTRO, ACCION, MOTIVO_EVENTO)
        VALUES (@USUARIO_CREACION, 'T_FACT_PROYECTO', @NewProjectID, 'INSERT', 'Creación de nuevo proyecto');
        COMMIT TRANSACTION;
        SET @ID_PROYECTO_OUT = @NewProjectID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
    SET NOCOUNT OFF;
END
GO


/* ----------------------- PAGINA PARA AÑADIR COLABORADORES AL PROYECTOS ---------------------------- *****************************************/

CREATE OR ALTER PROCEDURE SP_GET_COLABORADORES_POR_DEPARTAMENTO
    @COD_DIR INT,
    @COD_DEPTO INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        F.ID_FUNCIONARIO AS idFuncionario,
        ISNULL(F.PRIMER_NOMBRE, '') + ' ' + ISNULL(F.SEGUNDO_NOMBRE, '') + ' ' + 
        ISNULL(F.APELLIDO_PATERNO, '') + ' ' + ISNULL(F.APELLIDO_MATERNO, '') AS nombreCompleto,
        R.NOMBRE_ROL AS rol
    FROM T_DIM_FUNCIONARIO F
    INNER JOIN T_DIM_ROL R ON F.COD_ROL = R.COD_ROL
    WHERE F.COD_DIR = @COD_DIR
      AND F.COD_DEPTO = @COD_DEPTO
      AND F.ESTADO_REGISTRO = 1; -- <-- CORRECCIÓN: Cambiado de 'A' a 1
END;
GO

-------------------------------------- SP_GET_PROYECTOS_POR_FUNCIONARIO ------------------------------------------------------
CREATE OR ALTER PROCEDURE SP_GET_PROYECTOS_POR_FUNCIONARIO
    @ID_FUNCIONARIO INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT DISTINCT
        P.ID_PROYECTO,
        P.DESC_PROYECTO AS title,
        P.FECHA_INICIAL_PLANIFICADA AS plannedStart,
        P.FECHA_FINAL_PLANIFICADA AS plannedEnd,
        P.FECHA_INICIAL_REAL AS realStart,
        P.FECHA_FINAL_REAL AS realEnd
    FROM T_FACT_PROYECTO P
    INNER JOIN T_REL_FUNCIONARIO RF ON P.ID_PROYECTO = RF.ID_PROYECTO
    WHERE RF.ID_FUNCIONARIO = @ID_FUNCIONARIO
      AND P.ESTADO_REGISTRO = 1 -- <-- CORRECCIÓN: Cambiado de 'A' a 1
      AND RF.ESTADO_REGISTRO = 1; -- <-- CORRECCIÓN: Cambiado de 'A' a 1
END;
GO

----------------------------------------- SP_ASIGNAR_COLABORADORES ---------------------------------------------
CREATE OR ALTER PROCEDURE SP_ASIGNAR_COLABORADORES
    @ID_PROYECTO INT,
    @USUARIO_ASIGNACION VARCHAR(100),
    @COLABORADORES XML
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        IF @ID_PROYECTO IS NULL OR @USUARIO_ASIGNACION IS NULL OR @COLABORADORES IS NULL
            THROW 50001, 'Parámetros obligatorios faltantes.', 1;
        IF NOT EXISTS (SELECT 1 FROM T_FACT_PROYECTO WHERE ID_PROYECTO = @ID_PROYECTO AND ESTADO_REGISTRO = 1) -- <-- CORRECCIÓN: Cambiado de 'A' a 1
            THROW 50002, 'El proyecto especificado no existe o está inactivo.', 1;

        BEGIN TRANSACTION;

        IF EXISTS (
            SELECT 1
            FROM @COLABORADORES.nodes('/ids/id') AS T(id)
            WHERE EXISTS (
                SELECT 1 FROM T_REL_FUNCIONARIO RF
                WHERE RF.ID_PROYECTO = @ID_PROYECTO
                  AND RF.ID_FUNCIONARIO = T.id.value('.', 'INT')
                  AND RF.ESTADO_REGISTRO = 1 -- <-- CORRECCIÓN: Cambiado de 'A' a 1
            )
        )
            THROW 50003, 'Uno o más colaboradores ya están asignados al proyecto.', 1;

        INSERT INTO T_REL_FUNCIONARIO (ID_PROYECTO, ID_FUNCIONARIO, USUARIO_ASIGNACION, ESTADO_REGISTRO)
        SELECT 
            @ID_PROYECTO,
            T.id.value('.', 'INT'),
            @USUARIO_ASIGNACION,
            1 -- <-- CORRECCIÓN: Cambiado de 'A' a 1
        FROM @COLABORADORES.nodes('/ids/id') AS T(id);

        INSERT INTO T_DIM_AUDITORIA (USUARIO, ENTIDAD, ID_REGISTRO, ACCION, MOTIVO_EVENTO)
        VALUES (@USUARIO_ASIGNACION, 'T_REL_FUNCIONARIO', @ID_PROYECTO, 'INSERT', 'Asignación de colaboradores al proyecto');

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

------------------------------------------------  SP_GET_PROYECTO_POR_ID -------------------------------------------
CREATE OR ALTER PROCEDURE SP_GET_PROYECTO_POR_ID
    @ID_PROYECTO INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT 
        P.ID_PROYECTO AS idProyecto,
        ISNULL(P.ID_ARANDA, 'No asignado') AS idAranda,
        D.DESC_DEPARTAMENTO AS gerencia,
        DIR.DESC_DIR AS unidadSolicitanteTexto, -- Mantenemos el texto para vistas de "solo lectura"
        P.UNIDAD_SOLICITANTE AS unidadSolicitante, -- **AÑADIDO: Devolvemos el ID**
        TP.DESC_TIPO AS tipoProyecto,
        P.COD_TIPO AS codTipo, -- **AÑADIDO**
        C.DESC_CATEGORIA AS categoria,
        P.COD_CATEGORIA AS codCategoria, -- **AÑADIDO**
        R.DESC_RELACION AS relacion,
        P.COD_RELACION AS codRelacion, -- **AÑADIDO**
        PRI.DESC_PRIORIDAD AS prioridad,
        P.COD_PRIORIDAD AS codPrioridad, -- **AÑADIDO**
        PR.DESC_PROYECTO AS relacionOtroProyecto,
        PP.ID_PROYECTO_RELACIONADO AS idProyectoRelacionado, -- **AÑADIDO**
        PP.TIPO_RELACION AS tipoRelacion,
        P.DESC_PROYECTO AS descripcion,
        P.ALCANCE_PROYECTO AS alcance,
        ISNULL(P.MONTO_INVERSION, 0) AS inversion,
        P.FECHA_INICIAL_PLANIFICADA AS fechaInicial,
        P.FECHA_FINAL_PLANIFICADA AS fechaFinal,
        P.FECHA_INICIAL_REAL AS fechaInicialReal,
        P.FECHA_FINAL_REAL AS fechaFinalReal,
        P.COD_DIR AS codDir, 
        P.COD_DEPTO AS codDepto,
        P.APROBADO_POR_DIRECTOR AS aprobadoPorDirector
    FROM T_FACT_PROYECTO P
    LEFT JOIN T_DIM_DEPARTAMENTO D ON P.COD_DIR = D.COD_DIR AND P.COD_DEPTO = D.COD_DEPTO
    LEFT JOIN T_DIM_DIRECCION DIR ON P.UNIDAD_SOLICITANTE = DIR.COD_DIR
    LEFT JOIN T_DIM_TIPO_PROYECTO TP ON P.COD_TIPO = TP.COD_TIPO
    LEFT JOIN T_DIM_CATEGORIA C ON P.COD_CATEGORIA = C.COD_CATEGORIA
    LEFT JOIN T_DIM_RELACION R ON P.COD_RELACION = R.COD_RELACION
    LEFT JOIN T_DIM_PRIORIDAD PRI ON P.COD_PRIORIDAD = PRI.COD_PRIORIDAD
    LEFT JOIN T_REL_PROYECTO_PROYECTO PP ON P.ID_PROYECTO = PP.ID_PROYECTO_BASE
    LEFT JOIN T_FACT_PROYECTO PR ON PP.ID_PROYECTO_RELACIONADO = PR.ID_PROYECTO
    WHERE P.ID_PROYECTO = @ID_PROYECTO
      AND P.ESTADO_REGISTRO = 1;
END;
GO

-------------------------------------  SP_GET_COLABORADORES_POR_PROYECTO  ---------------------------------------
CREATE OR ALTER PROCEDURE SP_GET_COLABORADORES_POR_PROYECTO
    @ID_PROYECTO INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        RF.ID_FUNCIONARIO AS idFuncionario,
        ISNULL(F.PRIMER_NOMBRE, '') + ' ' + ISNULL(F.APELLIDO_PATERNO, '') AS nombreCompleto,
        R.NOMBRE_ROL AS rol,
        RF.FECHA_ASIGNACION AS fechaAsignacion,
        RF.ESTADO_REGISTRO AS estadoRegistro,
        (SELECT TOP 1 JUSTIFICACION_CAMBIO_ASIGNACION
         FROM T_DIM_AUDITORIA
         WHERE ENTIDAD = 'T_REL_FUNCIONARIO' AND ID_REGISTRO = RF.ID_PROYECTO AND ACCION IN ('INACTIVAR', 'REACTIVAR')
         ORDER BY FECHA_EVENTO DESC
        ) AS justificacion
    FROM T_REL_FUNCIONARIO RF
    INNER JOIN T_DIM_FUNCIONARIO F ON RF.ID_FUNCIONARIO = F.ID_FUNCIONARIO
    INNER JOIN T_DIM_ROL R ON F.COD_ROL = R.COD_ROL
    WHERE RF.ID_PROYECTO = @ID_PROYECTO
      AND F.ESTADO_REGISTRO = 1 -- <-- CORRECCIÓN: Cambiado de 'A' a 1
    ORDER BY nombreCompleto;
END;
GO

-------------------------- SP_ELIMINAR_COLABORADOR ----------------------
CREATE OR ALTER PROCEDURE SP_ELIMINAR_COLABORADOR
    @ID_PROYECTO INT,
    @ID_FUNCIONARIO INT,
    @USUARIO_MODIFICACION VARCHAR(100),
    @JUSTIFICACION VARCHAR(500)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        -- CORRECCIÓN: Variables con tipos de dato correctos
        DECLARE @APROBADO BIT;
        DECLARE @ESTADO_ACTUAL INT;

        SELECT @APROBADO = P.APROBADO_POR_DIRECTOR, @ESTADO_ACTUAL = RF.ESTADO_REGISTRO
        FROM T_FACT_PROYECTO P
        INNER JOIN T_REL_FUNCIONARIO RF ON P.ID_PROYECTO = RF.ID_PROYECTO
        WHERE P.ID_PROYECTO = @ID_PROYECTO AND RF.ID_FUNCIONARIO = @ID_FUNCIONARIO;

        IF @ESTADO_ACTUAL IS NULL
            THROW 50001, 'El colaborador no existe en el proyecto.', 1;

        -- CORRECCIÓN: Si el estado es 2 (Inactivo), se reactiva a 1 (Activo)
        IF @ESTADO_ACTUAL = 2
        BEGIN
            UPDATE T_REL_FUNCIONARIO SET ESTADO_REGISTRO = 1, FECHA_MODIFICACION = GETDATE(), USUARIO_MODIFICACION = @USUARIO_MODIFICACION
            WHERE ID_PROYECTO = @ID_PROYECTO AND ID_FUNCIONARIO = @ID_FUNCIONARIO;
        END
        -- CORRECCIÓN: Si el proyecto está aprobado (BIT = 1), se inactiva a 2
        ELSE IF @APROBADO = 1
        BEGIN
            UPDATE T_REL_FUNCIONARIO SET ESTADO_REGISTRO = 2, FECHA_MODIFICACION = GETDATE(), USUARIO_MODIFICACION = @USUARIO_MODIFICACION
            WHERE ID_PROYECTO = @ID_PROYECTO AND ID_FUNCIONARIO = @ID_FUNCIONARIO;
        END
        -- CORRECCIÓN: Si no está aprobado, se elimina el registro
        ELSE
        BEGIN
            DELETE FROM T_REL_FUNCIONARIO
            WHERE ID_PROYECTO = @ID_PROYECTO AND ID_FUNCIONARIO = @ID_FUNCIONARIO;
        END

        INSERT INTO T_DIM_AUDITORIA (ENTIDAD, ID_REGISTRO, ACCION, USUARIO, JUSTIFICACION_CAMBIO_ASIGNACION)
        VALUES (
            'T_REL_FUNCIONARIO', @ID_PROYECTO,
            CASE 
                WHEN @ESTADO_ACTUAL = 2 THEN 'REACTIVAR'
                WHEN @APROBADO = 1 THEN 'INACTIVAR'
                ELSE 'ELIMINAR' 
            END,
            @USUARIO_MODIFICACION, @JUSTIFICACION
        );

        SELECT 'Operación completada exitosamente' AS Mensaje;
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END;
GO

----------------------- SP_VERIFICAR_ACCESO_PROYECTO -----------------------------------

CREATE PROCEDURE SP_VERIFICAR_ACCESO_PROYECTO
    @ID_FUNCIONARIO INT,
    @ROL VARCHAR(50),
    @COD_DEPTO INT,
    @ID_PROYECTO INT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM T_FACT_PROYECTO WHERE ID_PROYECTO = @ID_PROYECTO)
    BEGIN
        RAISERROR('El proyecto especificado no existe.', 16, 1);
        RETURN;
    END

    IF @ROL IN ('PM', 'Director')
    BEGIN
        RETURN;
    END

    IF @ROL = 'Gerente'
    BEGIN
        IF EXISTS (SELECT 1 FROM T_FACT_PROYECTO WHERE ID_PROYECTO = @ID_PROYECTO AND COD_DEPTO = @COD_DEPTO)
        BEGIN
            RETURN;
        END
        ELSE
        BEGIN
            RAISERROR('Acceso denegado: Como Gerente, solo puedes acceder a proyectos de tu propio departamento.', 16, 1);
            RETURN;
        END
    END

    IF @ROL = 'Colaborador'
    BEGIN
        IF EXISTS (SELECT 1 FROM T_REL_FUNCIONARIO WHERE ID_PROYECTO = @ID_PROYECTO AND ID_FUNCIONARIO = @ID_FUNCIONARIO AND ESTADO_REGISTRO = 1)
        BEGIN
            RETURN;
        END
        ELSE
        BEGIN
            RAISERROR('Acceso denegado: No estás asignado a este proyecto.', 16, 1);
            RETURN;
        END
    END

    RAISERROR('Acceso denegado: Tu rol no tiene permisos para ver este recurso.', 16, 1);
    RETURN;
END;
GO

--------------------------- SP_GET_PROYECTOS_POR_USUARIO ------------------------------
CREATE PROCEDURE SP_GET_PROYECTOS_POR_USUARIO
    @ID_FUNCIONARIO INT,
    @ROL VARCHAR(50),
    @COD_DEPTO INT
AS
BEGIN
    SET NOCOUNT ON;
    IF @ROL IN ('PM', 'Director')
    BEGIN
        SELECT * FROM T_FACT_PROYECTO WHERE ESTADO_REGISTRO = 1;
    END
    ELSE IF @ROL = 'Gerente'
    BEGIN
        SELECT * FROM T_FACT_PROYECTO WHERE COD_DEPTO = @COD_DEPTO AND ESTADO_REGISTRO = 1;
    END
    ELSE IF @ROL = 'Colaborador'
    BEGIN
        SELECT P.*
        FROM T_FACT_PROYECTO P
        INNER JOIN T_REL_FUNCIONARIO RF ON P.ID_PROYECTO = RF.ID_PROYECTO
        WHERE RF.ID_FUNCIONARIO = @ID_FUNCIONARIO AND RF.ESTADO_REGISTRO = 1;
    END
END;
GO

/* ----------------------- PAGINA PARA VER PROYECTOS DE LAS GERENCIAS ---------------------------- ******************************************/

------------- OBTENER LAS GERENCIAS --------------------------
CREATE OR ALTER PROCEDURE SP_GET_DEPARTAMENTOS
AS
BEGIN
    SET NOCOUNT ON;
    SELECT 
        COD_DIR, 
        COD_DEPTO, 
        DESC_DEPARTAMENTO 
    FROM T_DIM_DEPARTAMENTO 
    WHERE ESTADO_REGISTRO = 1
    ORDER BY DESC_DEPARTAMENTO;
END
GO

-------------- MUESTRA DE TODOS LOS PROYECTOS EN LA PANTALLA DE PROYECTOS -------------------------------------
CREATE OR ALTER PROCEDURE SP_GET_PROYECTOS_POR_GERENCIA
    @COD_DIR INT,
    @COD_DEPTO INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ID_PROYECTO,
        p.DESC_PROYECTO,
        p.ALCANCE_PROYECTO,
        p.COD_ESTATUS,
        p.AVANCE_ALCANZADO,
        p.FECHA_FINAL_PLANIFICADA, 
        p.COD_DIR,
        p.COD_DEPTO,
        (CASE
            WHEN p.FECHA_INICIAL_REAL IS NULL OR p.FECHA_ENTREGA_ASIGNADA IS NULL THEN 0
            WHEN GETDATE() >= p.FECHA_ENTREGA_ASIGNADA THEN 100
            ELSE
                CAST(
                    (dbo.CalcularDiasHabiles(p.FECHA_INICIAL_REAL, GETDATE()) * 100.0) /
                    (dbo.CalcularDiasHabiles(p.FECHA_INICIAL_REAL, p.FECHA_ENTREGA_ASIGNADA) + 1)
                AS DECIMAL(5, 2))
        END) AS AVANCE_ESPERADO,
        (SELECT COUNT(*) 
         FROM T_REL_FUNCIONARIO rf 
         WHERE rf.ID_PROYECTO = p.ID_PROYECTO AND rf.ESTADO_REGISTRO = 1) AS NUM_COLABORADORES
    FROM T_FACT_PROYECTO p
    WHERE 
        p.COD_DIR = @COD_DIR 
        AND p.COD_DEPTO = @COD_DEPTO
        AND p.ESTADO_REGISTRO = 1;
END
GO


--------------------- FUNCION CALCULAR LOS DIAS HABILES ------------------------------

CREATE OR ALTER FUNCTION dbo.CalcularDiasHabiles (@StartDate DATE, @EndDate DATE)
RETURNS INT
AS
BEGIN
    DECLARE @WorkDays INT = 0;
    DECLARE @CurrentDate DATE = @StartDate;

    -- Asegurarnos que la fecha de fin no sea anterior a la de inicio
    IF @EndDate < @StartDate
        RETURN 0;

    WHILE @CurrentDate <= @EndDate
    BEGIN
        -- Verificamos 3 condiciones:
        -- 1. Que no sea Sábado (7) ni Domingo (1)
        --    Usamos DATENAME para evitar problemas con la configuración de @@DATEFIRST
        IF DATENAME(weekday, @CurrentDate) NOT IN ('Saturday', 'Sunday')
        -- 2. Y que no esté en nuestra tabla de feriados
        AND NOT EXISTS (SELECT 1 FROM T_DIM_FERIADOS WHERE FECHA = @CurrentDate)
        BEGIN
            SET @WorkDays = @WorkDays + 1;
        END

        SET @CurrentDate = DATEADD(day, 1, @CurrentDate);
    END

    RETURN @WorkDays;
END
GO

-------------------------- APROBAR PROYECTOS -------------------------------

CREATE OR ALTER PROCEDURE SP_APROBAR_PROYECTO
    @ID_PROYECTO INT,
    -- @FECHA_ENTREGA_ASIGNADA DATE, -- <-- PARÁMETRO ELIMINADO
    @USUARIO_MODIFICACION VARCHAR(100),
    @JUSTIFICACION VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;

    -- Validación de colaboradores (se mantiene igual)
    DECLARE @NumColaboradores INT;
    SELECT @NumColaboradores = COUNT(*)
    FROM T_REL_FUNCIONARIO
    WHERE ID_PROYECTO = @ID_PROYECTO AND ESTADO_REGISTRO = 1;

    IF @NumColaboradores = 0
    BEGIN
        THROW 50005, 'El proyecto no puede ser aprobado porque no tiene colaboradores asignados.', 1;
        RETURN;
    END

    -- --- INICIO DE LA MODIFICACIÓN ---
    DECLARE @FechaFinalPlanificada DATE;

    -- 1. Obtenemos la fecha final planificada directamente de la tabla del proyecto.
    SELECT @FechaFinalPlanificada = FECHA_FINAL_PLANIFICADA
    FROM T_FACT_PROYECTO
    WHERE ID_PROYECTO = @ID_PROYECTO;

    IF @FechaFinalPlanificada IS NULL
    BEGIN
        THROW 50006, 'El proyecto no tiene una fecha final planificada y no puede ser aprobado.', 1;
        RETURN;
    END

    -- 2. Calculamos los días hábiles usando la fecha planificada.
    DECLARE @DiasHabiles INT = dbo.CalcularDiasHabiles(GETDATE(), @FechaFinalPlanificada);
    -- --- FIN DE LA MODIFICACIÓN ---

    UPDATE T_FACT_PROYECTO
    SET
        COD_ESTATUS = 3, -- En Proceso
        APROBADO_POR_DIRECTOR = 1,
        FECHA_INICIAL_REAL = GETDATE(),
        -- 3. Asignamos la fecha planificada al campo de fecha de entrega.
        FECHA_ENTREGA_ASIGNADA = @FechaFinalPlanificada,
        DIAS = @DiasHabiles,
        USUARIO_MODIFICACION = @USUARIO_MODIFICACION,
        FECHA_MODIFICACION = GETDATE()
    WHERE ID_PROYECTO = @ID_PROYECTO;

    INSERT INTO T_DIM_AUDITORIA (USUARIO, ENTIDAD, ID_REGISTRO, ACCION, MOTIVO_EVENTO)
    VALUES (@USUARIO_MODIFICACION, 'T_FACT_PROYECTO', @ID_PROYECTO, 'APROBAR', @JUSTIFICACION);
END
GO



------------------ EDITAR LOS PROYECTOS PLANIFICADOS -------------------------


/* -------------------------- ACCIONES VARIADAS -----------------------------------****************************************/


------------ PAUSAR
CREATE OR ALTER PROCEDURE SP_PAUSAR_PROYECTO
    @ID_PROYECTO INT,
    @JUSTIFICACION VARCHAR(500),
    @USUARIO_MODIFICACION VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE T_FACT_PROYECTO
    SET COD_ESTATUS = 5 -- En Pausa
    WHERE ID_PROYECTO = @ID_PROYECTO;

    INSERT INTO T_DIM_AUDITORIA (USUARIO, ENTIDAD, ID_REGISTRO, ACCION, JUSTIFICACION_CAMBIO_ESTATUS)
    VALUES (@USUARIO_MODIFICACION, 'T_FACT_PROYECTO', @ID_PROYECTO, 'PAUSAR', @JUSTIFICACION);
END
GO

------------ REACTIVAR PROYECTO
CREATE OR ALTER PROCEDURE SP_REACTIVAR_PROYECTO
    @ID_PROYECTO INT,
    @USUARIO_MODIFICACION VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE T_FACT_PROYECTO
    SET COD_ESTATUS = 3 -- De vuelta a "En Proceso"
    WHERE ID_PROYECTO = @ID_PROYECTO;

    INSERT INTO T_DIM_AUDITORIA (USUARIO, ENTIDAD, ID_REGISTRO, ACCION, MOTIVO_EVENTO)
    VALUES (@USUARIO_MODIFICACION, 'T_FACT_PROYECTO', @ID_PROYECTO, 'REACTIVAR', 'El proyecto ha sido reactivado.');
END
GO

----------- COMPLETAR PROYECTO
CREATE OR ALTER PROCEDURE SP_COMPLETAR_PROYECTO
    @ID_PROYECTO INT,
    @USUARIO_MODIFICACION VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE T_FACT_PROYECTO
    SET
        COD_ESTATUS = 1, -- Completado
        FECHA_FINAL_REAL = GETDATE()
    WHERE ID_PROYECTO = @ID_PROYECTO;

    INSERT INTO T_DIM_AUDITORIA (USUARIO, ENTIDAD, ID_REGISTRO, ACCION, MOTIVO_EVENTO)
    VALUES (@USUARIO_MODIFICACION, 'T_FACT_PROYECTO', @ID_PROYECTO, 'COMPLETAR', 'El proyecto ha sido marcado como completado.');
END
GO


---------- ELIMINAR PROYECTO Y PONER EN I PARA SU ESTADO DE REGISTRO

CREATE OR ALTER PROCEDURE SP_ELIMINAR_PROYECTO
    @ID_PROYECTO INT,
    @USUARIO_MODIFICACION VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @COD_ESTATUS INT;

    SELECT @COD_ESTATUS = COD_ESTATUS FROM T_FACT_PROYECTO WHERE ID_PROYECTO = @ID_PROYECTO;

    IF @COD_ESTATUS IS NULL
        THROW 50001, 'El proyecto no existe.', 1;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF @COD_ESTATUS = 2 -- Si el proyecto está 'Por Iniciar'
        BEGIN
            -- Se elimina físicamente y NO se audita
            DELETE FROM T_REL_FUNCIONARIO WHERE ID_PROYECTO = @ID_PROYECTO;
            DELETE FROM T_REL_PROYECTO_PROYECTO WHERE ID_PROYECTO_BASE = @ID_PROYECTO OR ID_PROYECTO_RELACIONADO = @ID_PROYECTO;
            DELETE FROM T_FACT_PROYECTO WHERE ID_PROYECTO = @ID_PROYECTO;
        END
        ELSE -- Si ya está en otro estado
        BEGIN
            -- Se "elimina" lógicamente (soft delete)
            UPDATE T_FACT_PROYECTO
            SET ESTADO_REGISTRO = 2, -- 2 = Inactivo
                USUARIO_MODIFICACION = @USUARIO_MODIFICACION,
                FECHA_MODIFICACION = GETDATE()
            WHERE ID_PROYECTO = @ID_PROYECTO;

            -- CAMBIO: El registro de auditoría AHORA SOLO OCURRE AQUÍ
            INSERT INTO T_DIM_AUDITORIA (USUARIO, ENTIDAD, ID_REGISTRO, ACCION, MOTIVO_EVENTO)
            VALUES (@USUARIO_MODIFICACION, 'T_FACT_PROYECTO', @ID_PROYECTO, 'INACTIVAR', 'Inactivación de proyecto desde el tablero');
        END

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

------------ DETALLES DE PROYECTO COMPLETO POR MEDIO DEL ID -----------------------
CREATE OR ALTER PROCEDURE SP_GET_PROYECTO_COMPLETO_POR_ID
    @ID_PROYECTO INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Primer resultado: Detalles del proyecto
    EXEC SP_GET_PROYECTO_POR_ID @ID_PROYECTO;

    -- Segundo resultado: Colaboradores del proyecto
    EXEC SP_GET_COLABORADORES_POR_PROYECTO @ID_PROYECTO;
END
GO

------------------ EDITAR PROYECTO EN PLANIFICÁCIÓN ---------------------------------
CREATE OR ALTER PROCEDURE SP_EDITAR_PROYECTO_PLANIFICADO
    -- Parámetros de identificación
    @ID_PROYECTO INT,
    @USUARIO_MODIFICACION VARCHAR(100),

    -- CORRECCIÓN: Parámetros para cambiar la gerencia dueña
    @COD_DIR INT,
    @COD_DEPTO INT,

    -- Parámetros del formulario principal
    @ID_ARANDA VARCHAR(50),
    @UNIDAD_SOLICITANTE INT,
    @COD_CATEGORIA INT,
    @COD_RELACION INT,
    @COD_TIPO INT,
    @COD_PRIORIDAD INT,
    @DESC_PROYECTO VARCHAR(255),
    @ALCANCE_PROYECTO VARCHAR(600),
    @FECHA_INICIAL_PLANIFICADA DATE,
    @FECHA_FINAL_PLANIFICADA DATE,
    @MONTO_INVERSION DECIMAL(18, 2),

    -- Parámetros para la relación
    @ID_PROYECTO_RELACIONADO INT,
    @TIPO_RELACION VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        UPDATE T_FACT_PROYECTO SET
            COD_DIR = @COD_DIR,                          -- <--  CORRECCIÓN: Añadido
            COD_DEPTO = @COD_DEPTO,                      -- <--  CORRECCIÓN: Añadido
			ID_ARANDA = @ID_ARANDA,
			UNIDAD_SOLICITANTE = @UNIDAD_SOLICITANTE,
			COD_CATEGORIA = @COD_CATEGORIA,
			COD_RELACION = @COD_RELACION,
			COD_TIPO = @COD_TIPO,
			COD_PRIORIDAD = @COD_PRIORIDAD,
			DESC_PROYECTO = @DESC_PROYECTO,
			ALCANCE_PROYECTO = @ALCANCE_PROYECTO,
			FECHA_INICIAL_PLANIFICADA = @FECHA_INICIAL_PLANIFICADA,
			FECHA_FINAL_PLANIFICADA = @FECHA_FINAL_PLANIFICADA,
			MONTO_INVERSION = @MONTO_INVERSION,
			USUARIO_MODIFICACION = @USUARIO_MODIFICACION,
			FECHA_MODIFICACION = GETDATE()
		WHERE ID_PROYECTO = @ID_PROYECTO;
        
        -- ... (El resto de la lógica de relación no cambia) ...
        DECLARE @EXISTING_RELATION_ID INT;
        SELECT @EXISTING_RELATION_ID = ID_PROYECTO_RELACIONADO FROM T_REL_PROYECTO_PROYECTO WHERE ID_PROYECTO_BASE = @ID_PROYECTO AND ESTADO_REGISTRO = 1;

        IF @EXISTING_RELATION_ID IS NULL AND @ID_PROYECTO_RELACIONADO IS NOT NULL
        BEGIN
            INSERT INTO T_REL_PROYECTO_PROYECTO (ID_PROYECTO_BASE, ID_PROYECTO_RELACIONADO, TIPO_RELACION, USUARIO_CREACION)
            VALUES (@ID_PROYECTO, @ID_PROYECTO_RELACIONADO, @TIPO_RELACION, @USUARIO_MODIFICACION);
        END
        ELSE IF @EXISTING_RELATION_ID IS NOT NULL AND @ID_PROYECTO_RELACIONADO IS NOT NULL
        BEGIN
            UPDATE T_REL_PROYECTO_PROYECTO
            SET ID_PROYECTO_RELACIONADO = @ID_PROYECTO_RELACIONADO,
                TIPO_RELACION = @TIPO_RELACION,
                USUARIO_MODIFICACION = @USUARIO_MODIFICACION,
                FECHA_MODIFICACION = GETDATE()
            WHERE ID_PROYECTO_BASE = @ID_PROYECTO;
        END
        ELSE IF @EXISTING_RELATION_ID IS NOT NULL AND @ID_PROYECTO_RELACIONADO IS NULL
        BEGIN
            UPDATE T_REL_PROYECTO_PROYECTO
            SET ESTADO_REGISTRO = 2, -- Inactivo
                USUARIO_MODIFICACION = @USUARIO_MODIFICACION,
                FECHA_MODIFICACION = GETDATE()
            WHERE ID_PROYECTO_BASE = @ID_PROYECTO;
        END

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO


