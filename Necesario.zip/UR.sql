SELECT * FROM T_DIM_FUNCIONARIO
SELECT *FROM T_REL_FUNCIONARIO
SELECT * FROM T_FACT_PROYECTO

SELECT * FROM T_DIM_ESTADO_REGISTRO

SELECT * FROM T_DIM_ROL
SELECT * FROM T_REL_PROYECTO_PROYECTO
SELECT * FROM T_REL_FUNCIONARIO

SELECT * FROM T_DIM_AUDITORIA

-- Creaci�n de la tabla para almacenar d�as feriados
CREATE TABLE T_DIM_FERIADOS (
    FECHA DATE PRIMARY KEY,
    DESCRIPCION VARCHAR(100) NOT NULL
);
GO


SELECT ID_PROYECTO, APROBADO_POR_DIRECTOR, DESC_PROYECTO, ALCANCE_PROYECTO
FROM T_FACT_PROYECTO WHERE APROBADO_POR_DIRECTOR = 1


UPDATE T_FACT_PROYECTO
SET APROBADO_POR_DIRECTOR = 1
WHERE ID_PROYECTO = 22


-- Insertamos algunos feriados de Panam� para 2025 como ejemplo
-- Deber�s completar esta lista con todos los feriados oficiales
INSERT INTO T_DIM_FERIADOS (FECHA, DESCRIPCION) VALUES
('2025-01-01', 'A�o Nuevo'),
('2025-01-09', 'D�a de los M�rtires'),
('2025-03-03', 'Lunes de Carnaval'),
('2025-03-04', 'Martes de Carnaval'),
('2025-04-18', 'Viernes Santo'),
('2025-05-01', 'D�a del Trabajo'),
('2025-11-03', 'Separaci�n de Panam� de Colombia'),
('2025-11-05', 'D�a de Col�n'),
('2025-11-10', 'Primer Grito de Independencia de La Villa de Los Santos'),
('2025-11-28', 'Independencia de Panam� de Espa�a'),
('2025-12-08', 'D�a de la Madre'),
('2025-12-25', 'Navidad');
GO

-- Ejecuta esto en tu gestor de base de datos
EXEC SP_APROBAR_PROYECTO
    @ID_PROYECTO = 24, -- Usa un ID de proyecto v�lido que est� en estado "Por Iniciar"
    @FECHA_ENTREGA_ASIGNADA = '2025-12-31',
    @USUARIO_MODIFICACION = 'debug_user',
    @JUSTIFICACION = 'Prueba de depuraci�n directa.';
