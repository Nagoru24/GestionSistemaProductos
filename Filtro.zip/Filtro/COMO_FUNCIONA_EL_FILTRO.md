# Guía Definitiva del Sistema de Filtros del Kanban (Full-Stack)

Este documento explica en detalle cómo funciona el sistema de filtros de principio a fin, abarcando tanto el **Backend** (de donde vienen los datos) como el **Frontend** (donde el usuario interactúa con los filtros).

---

# Parte 1: Backend

El trabajo del backend es simple pero crucial: **consultar la base de datos y entregar la lista completa de proyectos para una gerencia específica.** En la versión actual, el backend ya no se encarga de filtrar. Simplemente sirve todos los datos en crudo para que el frontend pueda manipularlos dinámicamente.

El flujo es el siguiente: `Ruta -> Controlador -> Servicio -> Base de Datos`

### Archivo 1: La Ruta - `gerencias.routes.js`

Define la URL a la que el frontend llamará para obtener los proyectos. Actúa como una puerta de entrada.

**Ruta del archivo:** `server/src/routes/gerencias.routes.js`

```javascript
// (Fragmento relevante del archivo)

// ... otras rutas
import { getProyectosPorGerenciaHandler } from '../controllers/gerencias.controller.js';

// ...

// Esta es la ruta que nos interesa. Define que una petición GET a 
// /gerencias/:codDir/:codDepto/proyectos será manejada por 'getProyectosPorGerenciaHandler'
fastify.get(
    '/gerencias/:codDir/:codDepto/proyectos',
    { preHandler: [fastify.authenticate, fastify.authorize(['Gerente', 'Director', 'PM'])] },
    getProyectosPorGerenciaHandler
);

// ...
```

### Archivo 2: El Controlador - `gerencias.controller.js`

El controlador recibe la petición que llegó a la ruta. Su trabajo es llamar al servicio correspondiente y enviarle la respuesta al frontend.

**Ruta del archivo:** `server/src/controllers/gerencias.controller.js`

```javascript
// (Fragmento relevante del archivo)
import { getProyectosPorGerencia } from '../services/gerencias.service.js';

// ...

export const getProyectosPorGerenciaHandler = async (request, reply) => {
    try {
        // Extrae los parámetros de la URL (ej: los códigos de la gerencia)
        const params = request.params;
        
        // Llama a la función del servicio, que hará el trabajo pesado.
        const proyectos = await getProyectosPorGerencia(request.server, params);
        
        // Envía la lista de proyectos de vuelta al frontend.
        reply.send(proyectos);
    } catch (error) {
        request.log.error(error, "Error en getProyectosPorGerenciaHandler");
        reply.status(500).send({ message: "Error al obtener proyectos de la gerencia" });
    }
};

// ...
```

### Archivo 3: El Servicio - `gerencias.service.js`

Esta es la capa que habla con la base de datos. Prepara y ejecuta el Stored Procedure (`SP`) para obtener los datos.

**Ruta del archivo:** `server/src/services/gerencias.service.js`

```javascript
// (Fragmento relevante del archivo)
import sql from 'mssql';

// ...

export const getProyectosPorGerencia = async (fastify, filters) => {
    const pool = fastify.mssql;
    const request = pool.request();
    
    // Parámetros obligatorios para el SP
    request.input('COD_DIR', sql.Int, filters.codDir);
    request.input('COD_DEPTO', sql.Int, filters.codDepto);
    
    // IMPORTANTE: Pasamos NULL a los parámetros de filtro del SP.
    // Esto le indica al SP que no debe filtrar nada y debe devolver todos los proyectos.
    // La lógica de filtrado ahora vive 100% en el frontend.
    request.input('Statuses', sql.VarChar(100), null); 
    request.input('Collaborators', sql.VarChar(sql.MAX), null);
    request.input('SortBy', sql.VarChar(50), null);
    request.input('SortDirection', sql.VarChar(4), null);

    const result = await request.execute('SP_GET_PROYECTOS_POR_GERENCIA');
    return result.recordset;
};

// ...
```

---

# Parte 2: Frontend

El trabajo del frontend es:

1.  Llamar a la API del backend para obtener la lista completa de proyectos.
2.  Darle esa lista a un "cerebro" (un hook de React) que se encarga de la lógica de filtrado.
3.  Mostrarle al usuario un panel de filtros.
4.  Mostrar en pantalla la lista de proyectos ya filtrada que le devuelve el "cerebro".

### Archivo 1: La Lógica (El Cerebro) - `useKanbanFilters.js`

Este es el archivo más importante del frontend. Es un "custom hook" que se encarga de:

*   Guardar qué filtros están activos (qué estados, qué colaboradores, etc.).
*   Recibir la lista completa de proyectos que vino del backend.
*   Devolver una nueva lista con los proyectos ya filtrados y ordenados.
*   Proporcionar funciones para actualizar o limpiar los filtros.

**Ruta del archivo:** `client/src/hooks/useKanbanFilters.js`

```javascript
import { useState, useMemo, useCallback } from 'react';

const initialFilters = {
  status: [],
  collaborator: [],
  sortBy: 'FECHA_FINAL_PLANIFICADA',
  sortDirection: 'asc',
};

export const useKanbanFilters = (projects = []) => {
  const [filters, setFilters] = useState(initialFilters);

  const updateFilter = useCallback((key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  }, []);

  const clearFilters = useCallback(() => {
    setFilters(initialFilters);
  }, []);

  const filteredProjects = useMemo(() => {
    let processedProjects = [...projects];

    if (filters.status.length > 0) {
      const statusSet = new Set(filters.status);
      processedProjects = processedProjects.filter(p => statusSet.has(p.dynamicStatusId));
    }

    if (filters.collaborator.length > 0) {
      const collaboratorSet = new Set(filters.collaborator);
      processedProjects = processedProjects.filter(p => 
        p.colaboradores && p.colaboradores.some(c => collaboratorSet.has(c.idFuncionario))
      );
    }

    if (filters.sortBy && filters.sortDirection) {
      processedProjects.sort((a, b) => {
        const field = filters.sortBy;
        let valA = a[field];
        let valB = b[field];

        if (field.includes('FECHA')) {
          valA = valA ? new Date(valA) : new Date(0);
          valB = valB ? new Date(valB) : new Date(0);
        }
        
        if (field === 'MONTO_INVERSION' || field === 'AVANCE_ALCANZADO' || field === 'AVANCE_ESPERADO') {
            valA = Number(valA) || 0;
            valB = Number(valB) || 0;
        }

        if (valA < valB) return filters.sortDirection === 'asc' ? -1 : 1;
        if (valA > valB) return filters.sortDirection === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return processedProjects;
  }, [projects, filters]);

  return {
    filters,
    updateFilter,
    clearFilters,
    filteredProjects,
  };
};
```

### Archivo 2: La Interfaz de Usuario (El Panel) - `FilterDrawer.jsx`

Este componente es puramente visual. Su única responsabilidad es mostrar las opciones de filtro (ordenar, estados, colaboradores) y notificar a la lógica (Parte 1) cuando el usuario hace clic en algo.

**Ruta del archivo:** `client/src/components/gerencia_components/FilterDrawer.jsx`

```javascript
import React, { useState } from 'react';
import { ChevronDown, ArrowDown, ArrowUp, X } from 'lucide-react';
import { FilterCheckbox } from '../ui/FilterCheckbox';

// ... (código del componente Accordion y las opciones de filtro)

export const FilterDrawer = ({ isOpen, onClose, filters, updateFilter, onClear, collaboratorList = [] }) => {
  // ... (código interno del componente para manejar clics y renderizar el HTML)
};
```
*(El código completo de este archivo ya está en tu proyecto y es bastante largo, por lo que se omite aquí por brevedad. Su función es solo mostrar la UI)*

### Archivo 3: La Integración (La Página) - `KanbanPorGerenciaPage.jsx`

Esta es la página que el usuario ve. Su trabajo es conectar todas las partes anteriores.

*   Obtiene la lista completa de proyectos desde el backend.
*   Pasa esa lista al hook `useKanbanFilters`.
*   Recibe de vuelta la lista ya filtrada (`filteredProjects`).
*   Renderiza el panel `FilterDrawer` y le pasa las funciones para que los botones funcionen.
*   Muestra las columnas del Kanban usando la lista de `filteredProjects`.

**Ruta del archivo:** `client/src/pages/KanbanPorGerenciaPage.jsx`

```javascript
import React, { useState, useMemo } from 'react';
// ... otros imports
import { useGerencia } from '../hooks/useGerencia';
import { useKanbanFilters } from '../hooks/useKanbanFilters';

// ... (código del componente KanbanColumn)

export const KanbanPorGerenciaPage = () => {
  // ...

  // 1. Obtiene todos los proyectos del backend (a través de useGerencia)
  const { proyectos: allProjects, ... } = useGerencia({ codDir, codDepto });

  // ... (lógica para añadir estado dinámico de "Atrasado")

  // 2. Usa el hook de filtros, pasándole la lista completa de proyectos.
  // Recibe la lista ya filtrada y las funciones de control.
  const { filters, updateFilter, clearFilters, filteredProjects } = useKanbanFilters(projectsWithDynamicStatus);

  // ... (lógica para agrupar proyectos en columnas)

  return (
    <Layout title={gerenciaNombre}>
      <div className="flex flex-row h-full overflow-hidden">
        {/* 3. Renderiza el panel de filtros y le pasa las props necesarias */}
        <FilterDrawer 
          isOpen={isFilterDrawerOpen} 
          onClose={() => setIsFilterDrawerOpen(false)} 
          filters={filters} 
          updateFilter={updateFilter} 
          onClear={clearFilters} 
          collaboratorList={collaboratorList} 
        />
        <main className="flex-1 flex flex-col overflow-hidden">
          <KanbanHeader onOpenFilters={() => setIsFilterDrawerOpen(prev => !prev)} />
          <div className="flex-1 overflow-x-auto overflow-y-hidden p-4">
            {/* 4. Mapea y muestra las columnas usando la lista de filteredProjects */}
            <div className="flex h-full gap-4 pb-4">
              {COLUMN_ORDER.map(columnId => {
                const col = projectColumns[columnId];
                // ...
              })}
            </div>
          </div>
        </main>
      </div>
      {/* ... Modales */}
    </Layout>
  );
};
```
*(El código completo de este archivo ya está en tu proyecto y es bastante largo, por lo que se omite aquí por brevedad. Los puntos clave están numerados)*