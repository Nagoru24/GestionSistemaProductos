// src/services/proyectos.service.js

import sql from 'mssql';

// Las funciones ahora aceptan la instancia de fastify

export const getCategoriasPorDepartamento = async (fastify, codDir, codDepto) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('COD_DIR', sql.Int, codDir);
  request.input('COD_DEPTO', sql.Int, codDepto);
  const result = await request.execute('SP_GET_CATEGORIAS_POR_DEPARTAMENTO');
  return result.recordset;
};

export const getProyectosPorDepartamento = async (fastify, codDir, codDepto) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('COD_DIR', sql.Int, codDir);
  request.input('COD_DEPTO', sql.Int, codDepto);
  const result = await request.execute('SP_GET_PROYECTOS_POR_DEPARTAMENTO');
  return result.recordset;
};

export const createProyecto = async (fastify, projectData) => {
  const {
    rol, idFuncionario, codDir, codDepto, idAranda, unidadSolicitante, codCategoria,
    codRelacion, codTipo, codPrioridad, descProyecto, alcanceProyecto,
    fechaInicialPlanificada, fechaFinalPlanificada, montoInversion, usuarioCreacion,
    idProyectoRelacionado, tipoRelacion, codEstatus,
  } = projectData;

  const pool = fastify.mssql;
  const request = pool.request();
  
  request.input('ROL', sql.VarChar(50), rol);
  request.input('ID_FUNCIONARIO', sql.Int, idFuncionario);
  request.input('COD_DIR', sql.Int, codDir);
  request.input('COD_DEPTO', sql.Int, codDepto);
  request.input('ID_ARANDA', sql.VarChar(50), idAranda);
  request.input('UNIDAD_SOLICITANTE', sql.Int, unidadSolicitante);
  request.input('COD_CATEGORIA', sql.Int, codCategoria);
  request.input('COD_RELACION', sql.Int, codRelacion);
  request.input('COD_TIPO', sql.Int, codTipo);
  request.input('COD_PRIORIDAD', sql.Int, codPrioridad);
  request.input('DESC_PROYECTO', sql.VarChar(255), descProyecto);
  request.input('ALCANCE_PROYECTO', sql.VarChar(600), alcanceProyecto);
  request.input('FECHA_INICIAL_PLANIFICADA', sql.Date, fechaInicialPlanificada);
  request.input('FECHA_FINAL_PLANIFICADA', sql.Date, fechaFinalPlanificada);
  request.input('MONTO_INVERSION', sql.Decimal(18, 2), montoInversion);
  request.input('USUARIO_CREACION', sql.VarChar(100), usuarioCreacion);
  request.input('ID_PROYECTO_RELACIONADO', sql.Int, idProyectoRelacionado);
  request.input('TIPO_RELACION', sql.VarChar(50), tipoRelacion);
  request.input('COD_ESTATUS', sql.Int, codEstatus);
  request.output('ID_PROYECTO_OUT', sql.Int);
  
console.log('>>> [DEBUG] Parámetros para SP_CREATE_PROYECTO:', {
  rol,
  idFuncionario,
  codDir,
  codDepto
});

  const result = await request.execute('SP_CREATE_PROYECTO');
  
  return result.output.ID_PROYECTO_OUT;
};

export const getFormularioData = async (fastify) => {
  const pool = fastify.mssql;
  const request = pool.request();
  // We execute our single, unified stored procedure
  const result = await request.execute('SP_GET_FORMULARIO_DATA');
  
  // The SP returns multiple result sets, which the driver gives us in an array
  const [gerencias, unidadesSolicitantes, tiposProyecto, prioridades, relaciones] = result.recordsets;
  
  return { gerencias, unidadesSolicitantes, tiposProyecto, prioridades, relaciones };
};

export const getProyectosPorUsuario = async (fastify, usuario) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('ID_FUNCIONARIO', sql.Int, usuario.id);
    request.input('ROL', sql.VarChar(50), usuario.rol);
    request.input('COD_DEPTO', sql.Int, usuario.codDepto);
    const result = await request.execute('SP_GET_PROYECTOS_POR_USUARIO');
    return result.recordset;
};

export const getAllDepartamentos = async (fastify) => {
    const pool = fastify.mssql;
    const result = await pool.request().execute('SP_GET_DEPARTAMENTOS');
    return result.recordset;
};

export const getProyectosPorGerencia = async (fastify, { codDir, codDepto }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('COD_DIR', sql.Int, codDir);
    request.input('COD_DEPTO', sql.Int, codDepto);
    const result = await request.execute('SP_GET_PROYECTOS_POR_GERENCIA');
    return result.recordset;
};

export const aprobarProyecto = async (fastify, { idProyecto, fechaEntrega, usuario }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('ID_PROYECTO', sql.Int, idProyecto);
    request.input('FECHA_ENTREGA_ASIGNADA', sql.Date, fechaEntrega);
    request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuario.usuario);
    await request.execute('SP_APROBAR_PROYECTO');
    return { message: 'Proyecto aprobado correctamente' };
};

export const pausarProyecto = async (fastify, { idProyecto, justificacion, usuario }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('ID_PROYECTO', sql.Int, idProyecto);
    request.input('JUSTIFICACION', sql.VarChar(500), justificacion);
    request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuario.usuario);
    await request.execute('SP_PAUSAR_PROYECTO');
    return { message: 'Proyecto pausado correctamente' };
};

export const reactivarProyecto = async (fastify, { idProyecto, usuario }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('ID_PROYECTO', sql.Int, idProyecto);
    request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuario.usuario);
    await request.execute('SP_REACTIVAR_PROYECTO');
    return { message: 'Proyecto reactivado correctamente' };
};

export const completarProyecto = async (fastify, { idProyecto, usuario }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('ID_PROYECTO', sql.Int, idProyecto);
    request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuario.usuario);
    await request.execute('SP_COMPLETAR_PROYECTO');
    return { message: 'Proyecto completado correctamente' };
};