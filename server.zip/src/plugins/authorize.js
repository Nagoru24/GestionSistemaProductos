import fp from 'fastify-plugin';
import sql from 'mssql';

/**
 * Este plugin decora la instancia de Fastify con un manejador de autorización
 * que verifica si un usuario tiene acceso a un proyecto específico.
 */
async function authorizePlugin(fastify, options) {
  fastify.decorate('authorize', async function (request, reply) {
    try {
      // 1. Validar que la información necesaria exista.
      // El decorador 'authenticate' ya debió haber puesto 'request.user'.
      if (!request.user) {
        throw new Error('No hay información de usuario. El hook de autenticación debe ejecutarse primero.');
      }
      
      // El ID del proyecto debe venir en los parámetros de la URL.
      const idProyecto = request.params.idProyecto;
      if (!idProyecto) {
        throw new Error('No se especificó un ID de proyecto en la ruta.');
      }

      // 2. Obtener los datos del usuario del token.
      const { id: idFuncionario, rol, codDepto } = request.user;

      // 3. Llamar al SP "Guardián" para verificar el acceso.
      const pool = fastify.mssql;
      const spRequest = pool.request();

      spRequest.input('ID_FUNCIONARIO', sql.Int, idFuncionario);
      spRequest.input('ROL', sql.VarChar(50), rol);
      spRequest.input('COD_DEPTO', sql.Int, codDepto);
      spRequest.input('ID_PROYECTO', sql.Int, idProyecto);

      // Lo ejecutamos dentro de un try/catch. Si el SP lanza un error (RAISERROR),
      // la ejecución saltará directamente al bloque catch.
      await spRequest.execute('SP_VERIFICAR_ACCESO_PROYECTO');

      // Si el SP termina sin errores, significa que el acceso está permitido
      // y la petición puede continuar al controlador de la ruta.

    } catch (err) {
      // 4. Manejar los errores de acceso.
      // Aquí es donde interceptamos los RAISERROR del SP.
      if (err.number === 50000) {
        // Error de acceso prohibido.
        reply.code(403).send({ error: err.message });
      } else if (err.number === 5000) {
        // Error de recurso no encontrado.
        reply.code(404).send({ error: err.message });
      } else {  
        // Cualquier otro error (ej. de conexión, etc.)
        fastify.log.error(err, 'Error inesperado en el plugin de autorización');
        reply.code(500).send({ error: 'Error interno del servidor.' });
      }
    }
  });
}

export default fp(authorizePlugin);