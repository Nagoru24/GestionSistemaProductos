// Importamos el controlador usando llaves {} para una exportación nombrada
import { handleLogin } from '../controllers/auth.controller.js';

// Exportamos la función de rutas de forma nombrada
export const authRoutes = async (fastify, options) => {
  const loginSchema = {
    body: {
      type: 'object',
      required: ['usuario_nt', 'contrasena'],
      properties: {
        usuario_nt: { type: 'string' },
        contrasena: { type: 'string' },
      },
    },
    response: {
      200: {
        type: 'object',
        properties: {
          token: { type: 'string' },
        },
      },
    },
  };

  // Asignamos el controlador directamente a la ruta
  fastify.post('/login', { schema: loginSchema }, handleLogin);
};