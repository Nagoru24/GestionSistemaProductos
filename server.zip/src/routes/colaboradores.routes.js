import {
  getColaboradoresPorDepartamento,
  getProyectoPorId,
  getProyectosPorFuncionario,
  asignarColaboradores,
  getColaboradoresPorProyecto,
  eliminarColaborador,
} from '../controllers/colaboradores.controller.js';

export const colaboradoresRoutes = async (fastify, options) => {
  // Las rutas que NO dependen de un proyecto específico no necesitan el guardia de autorización.
  fastify.get('/colaboradores/usuarios', { preHandler: [fastify.authenticate] }, getColaboradoresPorDepartamento);
  fastify.get('/colaboradores/funcionarios/:idFuncionario/proyectos', { preHandler: [fastify.authenticate] }, getProyectosPorFuncionario);

  // --- RUTAS PROTEGIDAS POR AUTORIZACIÓN ---
  // A estas rutas les añadimos el nuevo guardia `fastify.authorize`.

  const opts = {
    preHandler: [fastify.authenticate, fastify.authorize] // <--- ¡AQUÍ ESTÁ EL CAMBIO!
  };

  // El guardia se ejecutará para las siguientes rutas:
  fastify.get('/colaboradores/proyectos/:idProyecto', opts, getProyectoPorId);
  fastify.post('/colaboradores/proyectos/:idProyecto/asignar-colaboradores', opts, asignarColaboradores);
  fastify.get('/colaboradores/proyectos/:idProyecto/colaboradores', opts, getColaboradoresPorProyecto);
  fastify.post('/colaboradores/proyectos/:idProyecto/eliminar-colaborador', opts, eliminarColaborador);
};