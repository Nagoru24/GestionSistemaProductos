import {
  getFormularioDataHandler,
  getProyectoDataPorDepartamentoHandler,
  createProyectoHandler,
  handleGetProyectosPorUsuario,
  getDepartamentos, // La importaste correctamente aquí
  handleGetProyectosPorGerencia,
  handleAprobarProyecto,
  handlePausarProyecto,
  handleReactivarProyecto,
  handleCompletarProyecto
} from '../controllers/proyectos.controller.js';

export const proyectosRoutes = async (fastify, options) => {
  // Objeto de configuración para aplicar el middleware a todas las rutas de este
  // archivo
  const opts = {
    preHandler: [fastify.authenticate],
  };

  fastify.get('/proyectos/formulario-data', opts, getFormularioDataHandler);
  fastify.get('/proyectos/departamento-data/:codDir/:codDepto', opts, getProyectoDataPorDepartamentoHandler);
  fastify.post('/proyectos/crear', opts, createProyectoHandler);
  fastify.get('/proyectos', { preHandler: [fastify.authenticate] }, handleGetProyectosPorUsuario);

  // Ruta para obtener los departamentos, protegida por autenticación y autorización
  fastify.get('/gerencias', { 
    preHandler: [fastify.authenticate, fastify.authorizeRoles(['Director', 'PM'])] // Usando los nombres de los roles que devuelve el SP_LOGIN
  }, getDepartamentos);

  // --- NUEVAS RUTAS PARA EL KANBAN Y ACCIONES ---

    // Obtener todos los proyectos para el tablero de una gerencia
    fastify.get('/gerencia/:codDir/:codDepto', {
        preHandler: [fastify.authenticate]
    }, handleGetProyectosPorGerencia);
    
    // Acciones sobre un proyecto específico
    const actionOpts = {
        preHandler: [fastify.authenticate, fastify.authorizeRoles(['Director', 'PM', 'Gerente'])]
    };


};