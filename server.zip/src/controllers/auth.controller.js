import jwt from 'jsonwebtoken';
// Importamos la función específica del servicio
import { validateUserCredentials } from '../services/auth.service.js';

/**
 * Maneja la solicitud de login.
 * @param {import('fastify').FastifyRequest} request
 * @param {import('fastify').FastifyReply} reply
 */
export const handleLogin = async (request, reply) => {
  const { usuario_nt, contrasena } = request.body;

  try {
    // Pasamos la instancia de fastify (request.server) al servicio
    const user = await validateUserCredentials(request.server, usuario_nt, contrasena);

    if (!user) {
      return reply.status(401).send({ error: 'Credenciales inválidas.' });
    }

    const payload = {
      id: user.idFuncionario,
      usuario: user.usuario,
      rol: user.rol,
      codDir: user.codDir,
      codDepto: user.codDepto,
      descDepartamento: user.descDepartamento,
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '8h',
    });

    reply.send({ token });

  } catch (error) {
    request.log.error(error, 'Error en el controlador de login');
    reply.status(500).send({ error: 'Error interno del servidor.' });
  }
};