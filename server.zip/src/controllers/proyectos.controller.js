import {
  getFormularioData, // Asumiendo que ya hiciste el cambio del SP unificado
  getCategoriasPorDepartamento,
  getProyectosPorDepartamento,
  createProyecto,
  getProyectosPorUsuario,
  getAllDepartamentos,
  getProyectosPorGerencia,
  aprobarProyecto,
  pausarProyecto,
  reactivarProyecto,
  completarProyecto
} from '../services/proyectos.service.js';


export const getFormularioDataHandler = async (request, reply) => {
  try {
    // A single, efficient call to the service
    const formularioData = await getFormularioData(request.server);
    reply.send(formularioData);
  } catch (err) {
    request.log.error(err);
    reply.status(500).send({ error: 'Error al obtener los datos del formulario.' });
  }
};

export const getProyectoDataPorDepartamentoHandler = async (request, reply) => {
  const { codDir, codDepto } = request.params;
  
  if (!codDir || !codDepto) {
    return reply.status(400).send({ error: 'Faltan parámetros de departamento.' });
  }

  try {
    const fastify = request.server;
    const categorias = await getCategoriasPorDepartamento(fastify, codDir, codDepto);
    const proyectosRelacionados = await getProyectosPorDepartamento(fastify, codDir, codDepto);
    
    reply.send({
      categorias,
      proyectosRelacionados,
    });
  } catch (err) {
    request.log.error(err);
    reply.status(500).send({ error: 'Error al obtener datos por departamento.' });
  }
};

export const createProyectoHandler = async (request, reply) => {
  const user = request.user; // ¡Obtenemos el usuario real del token!

  if (user.rol === 'Colaborador') {
    return reply.status(403).send({ error: 'El rol de Colaborador no tiene permiso para crear proyectos.' });
  }

  try {
    const projectData = {
      ...request.body,
      rol: user.rol,
      idFuncionario: user.id, 
      usuarioCreacion: user.usuario,
      codEstatus: 2,
    };
    
    const newProjectId = await createProyecto(request.server, projectData);

    reply.status(201).send({
      message: 'Proyecto creado exitosamente.',
      ID_PROYECTO_OUT: newProjectId,
    });
  } catch (err) {
    request.log.error(err);
    if (err.number >= 50000) {
      return reply.status(400).send({ error: err.message });
    }
    reply.status(500).send({ error: 'Error interno del servidor al crear el proyecto.' });
  }
};

export const handleGetProyectosPorUsuario = async (request, reply) => {
    try {
        // request.user viene del token gracias al guardia 'authenticate'
        const proyectos = await getProyectosPorUsuario(request.server, request.user);
        return reply.send(proyectos);
    } catch (error) {
        request.log.error(error);
        return reply.code(500).send({ error: 'Error al obtener la lista de proyectos.' });
    }
};

export const getDepartamentos = async (request, reply) => {
    try {
        const departamentos = await getAllDepartamentos(request.server);
        reply.send(departamentos);
    } catch (error) {
        request.log.error(error, "Error en el controlador getDepartamentos");
        reply.status(500).send({ message: "Error del servidor al obtener departamentos" });
    }
};

export const handleGetProyectosPorGerencia = async (request, reply) => {
    try {
        const { codDir, codDepto } = request.params;
        const proyectos = await getProyectosPorGerencia(request.server, { codDir, codDepto });
        reply.send(proyectos);
    } catch (error) {
        reply.status(500).send({ message: "Error al obtener proyectos de la gerencia" });
    }
};

export const handleAprobarProyecto = async (request, reply) => {
    try {
        const { id } = request.params;
        const { fechaEntregaAsignada } = request.body;
        const resultado = await aprobarProyecto(request.server, {
            idProyecto: id,
            fechaEntrega: fechaEntregaAsignada,
            usuario: request.user
        });
        reply.send(resultado);
    } catch (error) {
        reply.status(500).send({ message: "Error al aprobar el proyecto" });
    }
};

export const handlePausarProyecto = async (request, reply) => {
    try {
        const { id } = request.params;
        const { justificacion } = request.body;
        const resultado = await pausarProyecto(request.server, {
            idProyecto: id,
            justificacion,
            usuario: request.user
        });
        reply.send(resultado);
    } catch (error) {
        reply.status(500).send({ message: "Error al pausar el proyecto" });
    }
};

export const handleReactivarProyecto = async (request, reply) => {
    try {
        const { id } = request.params;
        const resultado = await reactivarProyecto(request.server, {
            idProyecto: id,
            usuario: request.user
        });
        reply.send(resultado);
    } catch (error) {
        reply.status(500).send({ message: "Error al reactivar el proyecto" });
    }
};

export const handleCompletarProyecto = async (request, reply) => {
    try {
        const { id } = request.params;
        const resultado = await completarProyecto(request.server, {
            idProyecto: id,
            usuario: request.user
        });
        reply.send(resultado);
    } catch (error) {
        reply.status(500).send({ message: "Error al completar el proyecto" });
    }
};

