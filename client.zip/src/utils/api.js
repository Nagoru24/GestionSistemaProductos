import axios from 'axios';

export const api = axios.create({
  baseURL: 'http://localhost:3000',
  headers: {
    'Content-Type': 'application/json',}, // Cambia esto según la URL de tu backend
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => {
  return Promise.reject(error);
});

// NUEVO: Función para la creación de proyectos, centraliza la lógica
export const createProject = async (projectData) => {
  try {
    const response = await api.post("/proyectos", projectData);
    return response.data;
  } catch (error) {
    console.error("Error al crear proyecto:", error);
    // Re-lanzar el error para que el componente que llama lo pueda manejar
    throw error; 
  }
};