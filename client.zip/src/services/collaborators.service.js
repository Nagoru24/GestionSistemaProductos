// src/services/collaborators.service.js

import { api } from '../utils/api';

export const getProyectoPorId = async (idProyecto) => {
  try {
    const response = await api.get(`/colaboradores/proyectos/${idProyecto}`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.error || 'Error al obtener el proyecto');
  }
};

export const getColaboradoresPorDepartamento = async (codDir, codDepto) => {
  try {
    const response = await api.get('/colaboradores/usuarios', {
      params: { codDir, codDepto },
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.error || 'Error al obtener usuarios por departamento');
  }
};

export const getProyectosPorFuncionario = async (idFuncionario) => {
  try {
    // --- CORRECCIÓN CLAVE ---
    // Se añade el prefijo "/colaboradores" para que coincida con la ruta del backend.
    const response = await api.get(`/colaboradores/funcionarios/${idFuncionario}/proyectos`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.error || 'Error al obtener proyectos por funcionario');
  }
};

export const asignarColaboradores = async (idProyecto, colaboradores) => {
  try {
    // --- VERIFICACIÓN CLAVE ---
    // Nos aseguramos de que el cuerpo de la petición sea un objeto
    // con la propiedad "colaboradores", que contendrá el array de IDs.
    const response = await api.post(`/colaboradores/proyectos/${idProyecto}/asignar-colaboradores`, {
      colaboradores,
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.error || 'Error al asignar colaboradores');
  }
};

export const getColaboradoresPorProyecto = async (idProyecto) => {
  try {
    const response = await api.get(`/colaboradores/proyectos/${idProyecto}/colaboradores`);
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.error || 'Error al obtener colaboradores asignados');
  }
};

export const eliminarColaborador = async (idProyecto, idFuncionario, justificacion) => {
  try {
    const response = await api.post(`/colaboradores/proyectos/${idProyecto}/eliminar-colaborador`, {
      idFuncionario,
      justificacion,
    });
    return response.data;
  } catch (error) {
    throw new Error(error.response?.data?.error || 'Error al eliminar/inactivar colaborador');
  }
};