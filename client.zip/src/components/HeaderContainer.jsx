// src/components/HeaderContainer.jsx

import { HeaderContent } from './HeaderContent';

// NUEVO: Se añade la prop 'isSidebarCollapsed' para sincronizar con el Sidebar.
export const HeaderContainer = ({ title, userName, userRole, onLogout, isSidebarCollapsed }) => {
  
  // Clases base para el header.
  const baseClasses = `
    fixed font-roboto top-0 right-0 h-14 bg-azul text-white 
    flex items-center px-4 md:px-6 z-10`;

  // Clases dinámicas para el margen izquierdo y la transición.
  const dynamicClasses = `
    transition-[left] duration-300 ease-in-out
    ${isSidebarCollapsed ? 'left-20' : 'left-[260px]'}
  `;

  return (
    <header className={`${baseClasses} ${dynamicClasses}`}>
      <HeaderContent 
        title={title} 
        userName={userName} 
        userRole={userRole} 
        onLogout={onLogout} 
      />
    </header>
  );
};
