import React from 'react';
import { useAddCollaborators } from '../hooks/useAddCollaborators.js'; // Importa el hook
import { UserPlus, CheckCircle } from 'lucide-react';
import { ConfirmationModal } from './ConfirmationModal.jsx';

export const AddCollaborators = () => {
  const {
    proyecto,
    usuarios,
    selectedUsers,
    setSelectedUsers,
    isModalOpen,
    isLoading,
    status,
    handleOpenModal,
    handleCloseModal,
    handleConfirmModal
  } = useAddCollaborators();

  const toggleSelect = (user) => {
    setSelectedUsers((prev) => {
      const isSelected = prev.some(u => u.idFuncionario === user.idFuncionario);
      if (isSelected) {
        return prev.filter((u) => u.idFuncionario !== user.idFuncionario);
      } else {
        return [...prev, user];
      }
    });
  };

  const isUserSelected = (userId) => {
    return selectedUsers.some(user => user.idFuncionario === userId);
  };

  return (
    <>
      <div className="container mx-auto mt-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-6 text-center">
          Añadir Colaboradores al Proyecto {proyecto?.idAranda || '...'}
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Proyecto: {proyecto?.descripcion || 'Cargando...'}
        </p>

        {status.message && (
          <div className={`p-4 mb-4 rounded-md text-white font-bold ${
            status.type === 'error' ? 'bg-red-500' : 'bg-green-500'
          }`}>
            {status.message}
          </div>
        )}

        {isLoading ? (
          <div className="text-center text-gray-500">
            Cargando...
          </div>
        ) : (
          <div className="mx-auto p-8 my-8 ml-[220px] bg-slate-50 rounded-xl shadow-lg select-none">
            <h3 className="text-xl font-bold text-gray-800 mb-6">Usuarios de la Gerencia</h3>
            {usuarios.length === 0 && <p className="text-center text-gray-500">No se encontraron usuarios.</p>}

            {usuarios.length > 0 && (
              <>
                <ul className="space-y-4">
                  {usuarios.map((user) => (
                    <li
                      key={user.idFuncionario}
                      className="bg-white border border-gray-200 rounded-lg p-4 hover:bg-gray-100 transition-colors duration-200"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-lg font-semibold text-gray-800">{user.nombreCompleto}</span>
                          <span className="text-sm text-gray-500 ml-2 italic">({user.rol})</span>
                        </div>
                        <div className="flex space-x-2 items-center">
                          <button
                            onClick={() => toggleSelect(user)}
                            className={`p-2 rounded-full ${isUserSelected(user.idFuncionario) ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'} hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-green-500 transition-colors duration-100`}
                            title={isUserSelected(user.idFuncionario) ? 'Deseleccionar' : 'Seleccionar'}
                          >
                            {isUserSelected(user.idFuncionario) ? (
                              <CheckCircle className="cursor-pointer w-5 h-5" />
                            ) : (
                              <UserPlus className="cursor-pointer w-5 h-5" />
                            )}
                          </button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
                <div className="mt-6 text-center">
                  <button
                    onClick={handleOpenModal}
                    className="cursor-pointer px-6 py-3 bg-indigo-600 text-white rounded-lg shadow-md hover:bg-indigo-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                    disabled={selectedUsers.length === 0}
                  >
                    Añadir Colaboradores ({selectedUsers.length})
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>

      <ConfirmationModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onConfirm={handleConfirmModal}
        selectedUsers={selectedUsers}
      />
    </>
  );
};
