// src/components/CreateProject.jsx
import { useCreateProject } from '../hooks/useCreateProject';
import { SelectField } from "./ui/SelectField";
import { InputField } from "./ui/InputField";
import { TextAreaField } from "./ui/TextAreaField";
import { DatePickerField } from "./ui/DatePickerField";
import { Modal } from "./ui/Modal";

export const CreateProject = () => {
  const {
    user,
    isLoading,
    formData,
    errors,
    isSubmitting,
    isModalOpen,
    showRelatedProjectSection,
    relatedProjectGerencia,
    gerencias,
    unidadesSolicitantes,
    tiposProyecto,
    categorias,
    prioridades,
    relaciones,
    relatedProyectos,
    handleChange,
    handleGerenciaChange,
    handleUnidadSolicitanteChange,
    handleRelatedGerenciaChange,
    handleToggleRelatedSection,
    handleDateChange,
    handleTextAreaChange,
    handleSubmit,
    handleConfirm,
    handleConfirmAndAddCollaborators,
    handleClearForm,
    handleCloseModal,
  } = useCreateProject();

  if (!user) return <div>Cargando...</div>;
  if (user.rol === 'Colaborador') {
    return (
      <div className="mx-auto p-8 bg-slate-50 rounded-xl shadow-lg select-none">
        <h1 className="text-3xl font-bold text-azul">Acceso Denegado</h1>
        <p className="text-slate-500 mt-1">Los colaboradores no pueden crear proyectos.</p>
      </div>
    );
  }

  const isGerente = user.rol === 'Gerente';

  return (
    <div className="mx-auto p-8 bg-slate-50 rounded-xl shadow-lg select-none">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-azul">Crear Nuevo Proyecto</h1>
        <p className="text-slate-500 mt-1">Complete el formulario para registrar un nuevo proyecto.</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-48">
          <p className="text-xl text-slate-500 animate-pulse">Cargando datos del formulario...</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* ... (Todo el contenido del formulario se mantiene igual) ... */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6 overflow-visible">
            <SelectField label="Gerencia" name="gerencia" value={formData.gerencia?.DESC_DEPARTAMENTO || ''} onChange={handleGerenciaChange} options={gerencias.map(g => ({ key: `${g.COD_DIR}-${g.COD_DEPTO}`, value: g.DESC_DEPARTAMENTO }))} error={errors.gerencia} required disabled={isGerente} />
            <SelectField label="Unidad Solicitante" name="unidadSolicitante" value={formData.unidadSolicitante?.DESC_DIR || ''} onChange={handleUnidadSolicitanteChange} options={unidadesSolicitantes.map(u => ({ key: u.COD_DIR, value: u.DESC_DIR }))} error={errors.unidadSolicitante} required />
            <InputField label="ID Aranda" name="idAranda" value={formData.idAranda} onChange={handleChange} placeholder="Ej: AR-12345" error={errors.idAranda} />
            <SelectField label="Tipo de Proyecto" name="tipoProyecto" value={formData.tipoProyecto} onChange={handleChange} options={tiposProyecto.map(t => ({ key: t.COD_TIPO, value: t.DESC_TIPO }))} error={errors.tipoProyecto} required />
            <div className="md:col-span-2"><TextAreaField label="Descripción del Proyecto" name="descripcion" value={formData.descripcion} onChange={handleTextAreaChange} maxLength={255} error={errors.descripcion} required /></div>
            <div className="md:col-span-2"><TextAreaField label="Alcance del Proyecto" name="alcance" value={formData.alcance} onChange={handleTextAreaChange} maxLength={600} error={errors.alcance} required /></div>
            <SelectField label="Prioridad" name="prioridad" value={formData.prioridad} onChange={handleChange} options={prioridades.map(p => ({ key: p.COD_PRIORIDAD, value: p.DESC_PRIORIDAD }))} error={errors.prioridad} required />
            <SelectField label="Categoría" name="categoria" value={formData.categoria} onChange={handleChange} options={categorias.map(c => ({ key: c.COD_CATEGORIA, value: c.DESC_CATEGORIA }))} error={errors.categoria} required disabled={!formData.gerencia} />
            <SelectField label="Relación" name="relacion" value={formData.relacion} onChange={handleChange} options={relaciones.map(r => ({ key: r.COD_RELACION, value: r.DESC_RELACION }))} error={errors.relacion} required />
            <SelectField label="¿Relacionar con otro proyecto?" name="toggleRelatedSection" value={showRelatedProjectSection ? 'Sí' : 'No'} onChange={handleToggleRelatedSection} options={[{ key: 'No', value: 'No' }, { key: 'Sí', value: 'Sí' }]} />
          </div>

          {/* ... (Sección de proyecto relacionado se mantiene igual) ... */}
          {showRelatedProjectSection && (
            <div className="p-4 border border-slate-200 rounded-lg mt-6 bg-slate-100">
              <h3 className="text-lg font-semibold text-azul mb-4">Detalles del Proyecto Relacionado</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6">
                <SelectField label="Gerencia del Proyecto Relacionado" name="relatedProjectGerencia" value={relatedProjectGerencia?.DESC_DEPARTAMENTO || ''} onChange={handleRelatedGerenciaChange} options={gerencias.map(g => ({ key: `rel-${g.COD_DIR}-${g.COD_DEPTO}`, value: g.DESC_DEPARTAMENTO }))} error={errors.relatedProjectGerencia} required />
                <SelectField label="Proyecto Relacionado" name="relacionOtroProyecto" value={formData.relacionOtroProyecto} onChange={handleChange} options={relatedProyectos.map(p => ({ key: p.ID_PROYECTO, value: p.DESC_PROYECTO }))} error={errors.relacionOtroProyecto} disabled={!relatedProjectGerencia} required />
                {formData.relacionOtroProyecto && (<SelectField label="Tipo de Relación" name="tipoRelacion" value={formData.tipoRelacion} onChange={handleChange} options={['Continuación', 'Al unísono'].map(v => ({ key: v, value: v }))} error={errors.tipoRelacion} required />)}
              </div>
            </div>
          )}
          
          {/* ... (Sección de inversión y fechas se mantiene igual) ... */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6 mt-6">
            <InputField label="Monto de Inversión" name="inversion" type="number" inputMode="decimal" pattern="[0-9]*\.?[0-9]*" placeholder="0.00" value={formData.inversion} onChange={(e) => { const sanitizedValue = e.target.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1'); handleChange({ target: { name: 'inversion', value: sanitizedValue } }); }} error={errors.inversion} />
            <div className="md:col-start-1"><DatePickerField label="Fecha Inicial Planificada" value={formData.fechaInicial} onChange={handleDateChange('fechaInicial')} error={errors.fechaInicial} required /></div>
            <div><DatePickerField label="Fecha Final Planificada" value={formData.fechaFinal} onChange={handleDateChange('fechaFinal')} error={errors.fechaFinal} required /></div>
          </div>

          {/* ESTE BLOQUE SE ELIMINA */}
          {/* {status.message && ( ... )} */}

          <div className="flex justify-end space-x-4 pt-4 border-t border-slate-200 mt-8">
            <button type="button" onClick={handleClearForm} className="px-6 py-2 rounded-md text-sm font-medium text-slate-700 bg-slate-200 hover:bg-slate-300 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500 cursor-pointer">Limpiar</button>
            <button type="submit" className="px-6 py-2 rounded-md text-sm font-medium text-white bg-azul hover:bg-indigo-900 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 shadow-sm cursor-pointer" disabled={isSubmitting}>{isSubmitting ? 'Creando...' : 'Crear Proyecto'}</button>
          </div>
        </form>
      )}
      <Modal isOpen={isModalOpen} onClose={handleCloseModal} onConfirm={handleConfirm} onConfirmAndAddCollaborators={handleConfirmAndAddCollaborators} formData={formData} showRelatedProjectSection={showRelatedProjectSection} relatedProjectGerencia={relatedProjectGerencia} />
    </div>
  );
};
