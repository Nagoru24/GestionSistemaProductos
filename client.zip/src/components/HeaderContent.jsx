// src/components/HeaderContent.jsx

// Se añaden los íconos a utilizar
import { HiOutlineLogout, HiOutlineUserCircle } from 'react-icons/hi';

export const HeaderContent = ({
  title = "Nombre Pantalla",
  userName = "Usuario de Prueba",
  userRole = "ROL",
  onLogout = () => console.log("Logout")
}) => {

  return (
    <div className="flex items-center justify-between w-full">
            
      {/* Título de la pantalla */}
      <h1 className="text-xl md:text-2xl text-white font-medium select-none truncate">
        {title}
      </h1>

      {/* --- INICIO: SECCIÓN DE PERFIL REDISEÑADA --- */}
      <div className="flex items-center gap-3 md:gap-4">
        
        {/* Contenedor de la información del Usuario */}
        {/* Este bloque se oculta en pantallas pequeñas para dar más espacio */}
        <div className="hidden md:flex items-center gap-3">
          
          {/* Avatar de usuario (placeholder) */}
          <HiOutlineUserCircle className="h-9 w-9 text-white/80" />
          
          {/* Nombre y Rol con mejor jerarquía visual */}
          <div className="text-left">
            <p className="text-sm font-semibold text-white select-none truncate leading-tight">
              {userName}
            </p>
            <p className="text-xs text-white/60 select-none uppercase tracking-wider leading-tight">
              {userRole}
            </p>
          </div>
        </div>

        {/* Separador visual sutil */}
        <div className="hidden md:block h-6 w-px bg-white/20"></div>

        {/* Botón de Logout con mejor estilo */}
        <button 
          onClick={onLogout} 
          className="cursor-pointer flex items-center justify-center h-10 w-10 rounded-full hover:bg-white/10 transition-colors duration-200" 
          aria-label="Cerrar sesión"
          title="Cerrar sesión" // Tooltip para mejorar la accesibilidad
        >
          <HiOutlineLogout className="cursor-pointer h-6 w-6 text-white" />
        </button>
      </div>
      {/* --- FIN: SECCIÓN DE PERFIL REDISEÑADA --- */}

    </div>
  );
};
