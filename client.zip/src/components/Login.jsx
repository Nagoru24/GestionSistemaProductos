// src/components/Login.jsx

import React, { useState } from 'react';
import { InputField } from './ui/InputField';
import { Eye, EyeOff } from 'lucide-react';
import { useAuth } from '../hooks/useAuth.js';

export const Login = () => {
  const [credentials, setCredentials] = useState({ usuario_nt: '', contrasena: '' });
  const [showPassword, setShowPassword] = useState(false);
  
  const { login, isLoading } = useAuth();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCredentials((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await login(credentials);
  };

  return (
    <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-xl shadow-lg">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-azul">Bienvenido a Proodev</h1>
        <p className="text-gray-500">Inicie sesión para continuar</p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-6 pt-4">
        <InputField
          label="Usuario"
          name="usuario_nt"
          value={credentials.usuario_nt}
          onChange={handleChange}
          placeholder="Ingrese su usuario"
          required
        />
        <div className="relative">
          <InputField
            label="Contraseña"
            name="contrasena"
            type={showPassword ? 'text' : 'password'}
            value={credentials.contrasena}
            onChange={handleChange}
            placeholder="Ingrese su contraseña"
            required
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute top-8 right-0 pr-3 text-gray-500 hover:text-gray-700 cursor-pointer"
          >
            {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
          </button>
        </div>
        
        <button
          type="submit"
          className="w-full cursor-pointer px-4 py-2 text-white bg-azul rounded-md hover:bg-indigo-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 transition-colors duration-300"
          disabled={isLoading}
        >
          {isLoading ? 'Ingresando...' : 'Ingresar'}
        </button>
      </form>
    </div>
  );
};
