// src/components/SidebarDropdown.jsx

import React, { useState, useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { HiChevronDown } from 'react-icons/hi';

// FIX: Se añade la prop 'onNavigate'
export const SidebarDropdown = ({ Icon, description, options, isCollapsed, onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (isCollapsed) {
      setIsOpen(false);
    }
  }, [isCollapsed]);

  const handleToggle = () => {
    if (!isCollapsed) {
      setIsOpen(!isOpen);
    }
  };

  const getSubLinkClasses = ({ isActive }) => {
    const baseClasses = `block w-full text-left py-2 px-3 rounded-md text-base text-white/70 hover:text-white hover:bg-white/5 transition-colors duration-150`;
    const activeClasses = 'bg-white/10 text-white';
    return isActive ? `${baseClasses} ${activeClasses}` : baseClasses;
  };

  return (
    <div className="text-white font-roboto select-none">
      <div 
        onClick={handleToggle} 
        className={`cursor-pointer flex items-center text-base font-medium rounded-lg overflow-hidden
                    hover:bg-white/10 transition-colors duration-200
                    ${isCollapsed ? 'w-full h-14 justify-center' : 'px-4 py-3 justify-between'}
                    ${isCollapsed ? 'cursor-default' : 'cursor-pointer'}`}
        title={isCollapsed ? description : undefined}
      >
        <div className="flex items-center">
          {Icon && <Icon className="w-6 h-6 flex-shrink-0" />}
          <span className={`
            whitespace-nowrap 
            transition-[width,opacity,margin-left] duration-300 ease-in-out
            ${isCollapsed ? 'w-0 opacity-0 ml-0' : 'w-auto opacity-100 ml-4'}
          `}>
            {description}
          </span>
        </div>
        
        {!isCollapsed && (
          <HiChevronDown 
            className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
          />
        )}
      </div>

      <div className={`transition-[max-height] duration-300 ease-in-out overflow-hidden ${isOpen && !isCollapsed ? 'max-h-96' : 'max-h-0'}`}>
        <ul className="pl-8 pt-1 pb-1 space-y-1">
          {options.map((option) => (
            <li key={option.id}>
              {/* FIX: Se añade el evento onClick a cada NavLink del submenú */}
              <NavLink to={option.path} className={getSubLinkClasses} onClick={onNavigate}>
                {option.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
