// src/components/SidebarContainer.jsx

import React, { useState, useEffect } from 'react';
// Se elimina useMediaQuery de aquí porque ahora se gestiona en Layout.jsx
import { 
  HiChevronLeft, 
  HiOutlineClipboardList,
  HiOutlineHome,
  HiOutlineViewGrid,
  HiOutlinePlusCircle,
  HiOutlineFolder,
  HiOutlineBriefcase,
  HiOutlineDocumentText
} from 'react-icons/hi';

// Componentes y hooks
import { SidebarOption } from './SidebarOption';
import { SidebarDropdown } from './SidebarDropdown';
import { useAuth } from '../hooks/useAuth.js';
import { getGerencias } from '../services/gerencia.service.js';
import { useNavigate } from 'react-router-dom';

// --- PASO 1: Aceptar las props isCollapsed y setIsCollapsed del componente padre ---
export const SidebarContainer = ({ isCollapsed, setIsCollapsed }) => {
  const { user } = useAuth();
  const [menuItems, setMenuItems] = useState([]);

  const navigate = useNavigate();

  // La función navigate con -1 nos lleva a la página anterior en el historial.
  const handleGoBack = () => {
    navigate(-1);
  };

  const closeSidebarOnMobile = () => {
    const isSmallScreen = window.innerWidth <= 1024;
    if (isSmallScreen) {
      setIsCollapsed(true);
    }
  };

  useEffect(() => {
    const buildMenu = (gerenciasApi = []) => {
      if (!user) {
        setMenuItems([]);
        return;
      }
      
      const menu = [
        { id: 1, type: 'option', Icon: HiOutlineHome, description: 'Pantalla Principal', path: '/pantalla-principal' },
        { id: 2, type: 'option', Icon: HiOutlineViewGrid, description: 'Dashboard', path: '/' },
      ];
      if (user.rol !== 'Colaborador') {
        menu.push({ id: 3, type: 'option', Icon: HiOutlinePlusCircle, description: 'Crear Proyecto', path: '/crear-proyecto' });
      }
      menu.push({ id: 4, type: 'option', Icon: HiOutlineFolder, description: 'Mis Proyectos', path: '/proyectos' });
      menu.push({ id: 'divider1', type: 'divider' });
      if (user.rol === 'PM' || user.rol === 'Director') {
        menu.push({
          id: 5, type: 'dropdown', Icon: HiOutlineBriefcase, description: 'Gerencia',
          options: gerenciasApi.map(g => ({
            id: `${g.COD_DIR}-${g.COD_DEPTO}`, label: g.DESC_DEPARTAMENTO, path: `/gerencia/${g.COD_DIR}/${g.COD_DEPTO}`
          })),
        });
      } else if (user.rol === 'Gerente' || user.rol === 'Colaborador') {
        menu.push({ id: 5, type: 'option', Icon: HiOutlineBriefcase, description: user.descDepartamento || 'Mi Gerencia', path: `/gerencia/${user.codDir}/${user.codDepto}` });
      }
      if (user.rol === 'PM' || user.rol === 'Director') {
        menu.push({ id: 'divider2', type: 'divider' });
        menu.push({ id: 6, type: 'option', Icon: HiOutlineDocumentText, description: 'Bitácoras', path: '/bitacora' });
      }
      setMenuItems(menu);
    };

    if (user?.rol === 'PM' || user?.rol === 'Director') {
      getGerencias()
        .then(data => buildMenu(data))
        .catch(err => {
          console.error("Error al cargar gerencias:", err);
          buildMenu();
        });
    } else if (user) {
      buildMenu();
    }
  }, [user]); // Ya no necesita depender de isSmallScreen

  return (
    <aside className={`fixed top-0 left-0 h-screen flex flex-col z-20 bg-azul
                       transition-[width] duration-300 ease-in-out
                       ${isCollapsed ? 'w-20' : 'w-[260px]'}`}>
      
      <div className={`flex items-center p-4 select-none overflow-hidden  ${isCollapsed ? 'justify-center' : ''}`}>
        <HiOutlineClipboardList className="w-8 h-8 text-white flex-shrink-0 cursor-pointer" onClick={handleGoBack} />
        <h1 className={`
          text-2xl font-bold text-white whitespace-nowrap cursor-pointer
          transition-[width,opacity,margin-left] duration-300 ease-in-out
          ${isCollapsed ? 'w-0 opacity-0 ml-0' : 'w-auto opacity-100 ml-4'}`} onClick={handleGoBack}>
          Proodev
        </h1>
      </div>

      <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto custom-scrollbar">
        {menuItems.map((item) => {
          if (item.type === 'divider') {
            return <div key={item.id} className="border-t border-white/10 my-2 mx-2" />;
          }
          if (item.type === 'dropdown') {
            return <SidebarDropdown key={item.id} {...item} isCollapsed={isCollapsed} onNavigate={closeSidebarOnMobile} />;
          }
          return <SidebarOption key={item.id} {...item} to={item.path} isCollapsed={isCollapsed} onNavigate={closeSidebarOnMobile} />;
        })}
      </nav>

      <div className="p-3 mt-auto">
          <button 
            onClick={() => setIsCollapsed(!isCollapsed)}
            className={`cursor-pointer flex items-center w-full h-12 rounded-lg
                       hover:bg-white/10 transition-colors duration-300
                       ${isCollapsed ? 'justify-center' : 'justify-end pr-4'}`}
            aria-label={isCollapsed ? "Expandir menú" : "Colapsar menú"}
          >
            <HiChevronLeft
              className={`w-6 h-6 text-white transition-transform duration-50 
                         ${isCollapsed ? 'rotate-180' : ''}`}
              aria-hidden="true"
            />
          </button>
      </div>
    </aside>
  );
};
