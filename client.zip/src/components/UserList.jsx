import React, { useState } from 'react';
import { UserPlus, CheckCircle, ChevronDown, ChevronUp } from 'lucide-react';
// Importa el componente Collapsible que creaste
import { Collapsible } from './ui/Collapsible';

export const UserList = ({
  usuarios,
  colaboradoresAsignados,
  proyectosPorFuncionario,
  fetchproyectosPorFuncionario,
  selectedUsers,
  toggleSelect,
  openModal,
  isLoading,
  error,
  gerenciaName,
}) => {
  const [expandedUsers, setExpandedUsers] = useState({});

  const isUserSelected = (userId) => {
    return selectedUsers.some((user) => user.idFuncionario === userId);
  };

  const isUserAssigned = (userId) => {
    return colaboradoresAsignados.some((c) => c.idFuncionario === userId);
  };

  const isUserAssignedActive = (userId) => {
  return colaboradoresAsignados.some((c) => c.idFuncionario === userId && c.estadoRegistro === 'A');
  };

  const toggleExpand = (userId) => {
    setExpandedUsers((prev) => ({
      ...prev,
      [userId]: !prev[userId],
    }));
    // Se asegura de cargar los proyectos si no están ya en caché
    if (!proyectosPorFuncionario[userId]) {
      fetchproyectosPorFuncionario(userId);
    }
  };

  const formatDate = (date) => {
    if (!date) return 'Sin fecha';
    const parsedDate = new Date(date);
    return isNaN(parsedDate) ? 'Sin fecha' : parsedDate.toLocaleDateString();
  };

  // src/components/UserList.jsx

// ... (mantén las importaciones y la lógica del componente igual)

return (
    <div className="mx-auto p-8 my-8 bg-slate-50 rounded-xl shadow-lg select-none">
      <h3 className="text-xl font-bold text-gray-800 mb-6">
        Colaboradores de la Gerencia: {gerenciaName || '...'}
      </h3>
      {isLoading && <p className="text-center text-gray-500">Cargando usuarios...</p>}
      {error && <p className="text-center text-red-500">Error: {error}</p>}
      {!isLoading && !error && usuarios.length === 0 && (
        <p className="text-center text-gray-500">No se encontraron usuarios.</p>
      )}

      {!isLoading && usuarios.length > 0 && (
        <>
          {/* CAMBIADO: Se aumentó el espaciado vertical entre usuarios de 'space-y-4' a 'space-y-5' */}
          <ul className="space-y-5">
            {usuarios.map((user) => (
              <li
                key={user.idFuncionario}
                // CAMBIADO: Se ajustó el padding para dar más espacio vertical interno 'p-4' -> 'px-4 py-5'
                className={`bg-white border border-gray-200 rounded-lg px-4 py-5 ${
                  isUserAssigned(user.idFuncionario) ? 'opacity-50' : 'hover:bg-gray-50' // Ligeramente más sutil el hover
                } transition-colors duration-200`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2"> {/* CAMBIADO: Ligero aumento de espacio 'space-x-2' -> 'space-x-3' */}
                    <span className="text-lg font-semibold text-gray-800">{user.nombreCompleto}</span>
                    <span className="text-sm text-gray-500 italic">({user.rol})</span>
                    {isUserAssigned(user.idFuncionario) && (
                      // AÑADIDO: Estilo más visual para la etiqueta "Asignado"
                      <span className="text-xs font-semibold px-2 py-1 bg-blue-100 text-blue-700 rounded-full">Asignado</span>
                    )}
                  </div>
                  {/* CAMBIADO: Se aumentó el espacio entre botones de 'space-x-2' a 'space-x-3' */}
                  <div className="flex space-x-3 items-center">
                    {!isUserAssigned(user.idFuncionario) && (
                      <button
                        onClick={() => toggleSelect(user)}
                        className={`p-2 rounded-full ${
                          isUserSelected(user.idFuncionario)
                            ? 'bg-green-100 text-green-700'
                            : isUserAssignedActive(user.idFuncionario)
                            ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                            : 'bg-gray-100 text-gray-700'
                        } hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-green-500 transition-colors duration-100`}
                        title={
                          isUserSelected(user.idFuncionario)
                            ? 'Deseleccionar'
                            : isUserAssignedActive(user.idFuncionario)
                            ? 'Usuario activo, no seleccionable'
                            : 'Seleccionar'
                        }
                        disabled={isUserAssignedActive(user.idFuncionario)}
                      >
                        {isUserSelected(user.idFuncionario) ? (
                          <CheckCircle className="cursor-pointer w-5 h-5" />
                        ) : (
                          <UserPlus className="cursor-pointer w-5 h-5" />
                        )}
                      </button>
                    )}
                    <button
                      onClick={() => toggleExpand(user.idFuncionario)}
                      className="cursor-pointer p-2 rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 transition-colors duration-100"
                      title={expandedUsers[user.idFuncionario] ? 'Ocultar proyectos' : 'Ver proyectos'}
                    >
                      {expandedUsers[user.idFuncionario] ? (
                        <ChevronUp className="cursor-pointer w-5 h-5" />
                      ) : (
                        <ChevronDown className="cursor-pointer w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>

                <Collapsible isOpen={expandedUsers[user.idFuncionario]}>
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    {proyectosPorFuncionario[user.idFuncionario]?.length > 0 ? (

                      <ul className="space-y-4 text-sm text-gray-700">
                        {proyectosPorFuncionario[user.idFuncionario].map((proyecto) => (
                            <li
                              key={proyecto.ID_PROYECTO}
                              className="border-l-2 border-gray-300 pl-4 py-2"
                            >
                              {/* Título del proyecto */}
                              <p className="font-semibold text-azul">
                                {proyecto.title || proyecto.descripcion}
                              </p>

                              {/* Contenedor de fechas usando flexbox para alinear */}
                              <div className="flex flex-col md:flex-row md:space-x-8 text-sm text-gray-500 space-y-1 md:space-y-0">
                                {/* Fechas Planificadas */}
                                <p>
                                  <span className="font-medium ">
                                    Planificadas:
                                  </span>{' '}
                                  <span className="font-bold text-black">
                                    {formatDate(proyecto.plannedStart)}
                                  </span>{' '}
                                  -{' '}
                                  <span className="font-bold  text-black">
                                    {formatDate(proyecto.plannedEnd)}
                                  </span>
                                </p>

                                {/* Fechas Reales */}
                                <p>
                                  <span className="font-medium  text-black">Reales:</span>{' '}
                                  <span className="font-bold  text-black">
                                    {proyecto.realStart
                                      ? formatDate(proyecto.realStart)
                                      : 'Sin fecha'}
                                  </span>{' '}
                                  -{' '}
                                  <span className="font-bold  text-black">
                                    {proyecto.realEnd
                                      ? formatDate(proyecto.realEnd)
                                      : 'Sin fecha'}
                                  </span>
                                </p>
                              </div>
                            </li>
                          ))}
                      </ul>

                    ) : (
                      <p className="pl-4 mt-2 text-sm text-gray-500">
                        {proyectosPorFuncionario[user.idFuncionario] ? 'No hay proyectos asignados.' : 'Cargando proyectos...'}
                      </p>
                    )}
                  </div>
                </Collapsible>
              </li>
            ))}
          </ul>
          <div className="mt-8 text-center"> {/* CAMBIADO: Aumentado margen superior de 'mt-6' a 'mt-8' */}
            <button
              onClick={openModal}
              className="cursor-pointer px-6 py-3 bg-indigo-600 text-white rounded-lg shadow-md hover:bg-indigo-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={selectedUsers.length === 0}
            >
              Añadir Colaboradores ({selectedUsers.length})
            </button>
          </div>
        </>
      )}
    </div>
  );
};