// src/components/ui/Notifications.jsx

import React from 'react';
import { Toaster } from 'react-hot-toast';
import { CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

// Este componente será el contenedor de todas nuestras notificaciones.
// Lo configuramos una vez y lo usamos en toda la aplicación.
export const Notifications = () => {
  return (
    <Toaster
      position="top-right" // Las notificaciones aparecerán en la esquina superior derecha.
      reverseOrder={false}
      gutter={8}
      toastOptions={{
        // Estilos y duración por defecto para todas las notificaciones
        duration: 5000, // 5 segundos
        style: {
          background: '#fff',
          color: '#333',
          borderRadius: '8px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
          padding: '16px',
          fontSize: '16px',
        },

        // Estilos específicos para cada tipo de notificación
        success: {
          duration: 3000,
          icon: <CheckCircle className="text-green-500" />,
          style: {
            borderLeft: '5px solid #28a745',
          },
        },
        error: {
          duration: 6000, // Los errores duran un poco más para que se puedan leer
          icon: <XCircle className="text-red-500" />,
          style: {
            borderLeft: '5px solid #dc3545',
          },
        },
        loading: {
          style: {
            borderLeft: '5px solid #17a2b8',
          },
        },
      }}
    />
  );
};
