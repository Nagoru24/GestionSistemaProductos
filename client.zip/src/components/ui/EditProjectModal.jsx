// src/components/ui/EditProjectModal.jsx
import React, { useState } from 'react'; // Importamos useState
import { ModalBaseBig } from './ModalBaseBig';
import { InputField } from './InputField';
import { TextAreaField } from './TextAreaField';
import { DatePickerField } from './DatePickerField';
import { SelectField } from './SelectField';
import { useEditProject } from '../../hooks/useEditProject';

export const EditProjectModal = ({ isOpen, onClose, onConfirm, project }) => {
  const {
    isLoading,
    formData,
    dropdownOptions,
    showRelatedProjectSection,
    relatedProjectGerencia,
    handleChange,
    handleDateChange,
    handleToggleRelatedSection,
    handleRelatedGerenciaChange,
  } = useEditProject(project);

  // Estado para manejar el mensaje de error
  const [errorMessage, setErrorMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setErrorMessage(''); // Limpiamos errores previos

    // --- ✨ CORRECCIÓN: La función ahora busca el objeto completo de la gerencia ---
    const findGerenciaByDesc = (list, desc) => {
      // Usamos gerencias para la unidad dueña, y unidadesSolicitantes para la solicitante
      const gerencia = dropdownOptions.gerencias.find(item => item.DESC_DEPARTAMENTO === desc);
      return gerencia || null;
    };

    const findIdByValue = (list, keyField, valueField, value) => {
      const found = list.find(item => item[valueField] === value);
      return found ? found[keyField] : null;
    };

    const selectedGerencia = findGerenciaByDesc(dropdownOptions.gerencias, formData.unidadSolicitante);

    const payload = {

      // --- ✨ CORRECCIÓN: Añadimos codDir y codDepto al payload ---
      codDir: selectedGerencia ? selectedGerencia.COD_DIR : null,
      codDepto: selectedGerencia ? selectedGerencia.COD_DEPTO : null,

      descripcion: formData.descripcion,
      alcance: formData.alcance,
      idAranda: formData.idAranda,
      inversion: parseFloat(formData.inversion) || 0,
      fechaInicial: formData.fechaInicial,
      fechaFinal: formData.fechaFinal,
      unidadSolicitante: findIdByValue(dropdownOptions.unidadesSolicitantes, 'COD_DIR', 'DESC_DIR', formData.unidadSolicitante),
      codTipo: findIdByValue(dropdownOptions.tiposProyecto, 'COD_TIPO', 'DESC_TIPO', formData.tipoProyecto),
      codPrioridad: findIdByValue(dropdownOptions.prioridades, 'COD_PRIORIDAD', 'DESC_PRIORIDAD', formData.prioridad),
      codCategoria: findIdByValue(dropdownOptions.categorias, 'COD_CATEGORIA', 'DESC_CATEGORIA', formData.categoria),
      codRelacion: findIdByValue(dropdownOptions.relaciones, 'COD_RELACION', 'DESC_RELACION', formData.relacion),
      idProyectoRelacionado: showRelatedProjectSection ? formData.idProyectoRelacionado : null,
      tipoRelacion: showRelatedProjectSection ? formData.tipoRelacion : null,
    };
    
    // --- ✨ CORRECCIÓN CLAVE: VALIDACIÓN ANTES DE ENVIAR ✨ ---
    if (!payload.unidadSolicitante || !payload.codTipo || !payload.codPrioridad || !payload.codCategoria) {
      setErrorMessage('Por favor, complete todos los campos obligatorios (Unidad, Tipo, Prioridad, Categoría).');
      return; // Detenemos la ejecución si falta algún dato
    }
    
    onConfirm(payload);
  };
  
  return (
    <ModalBaseBig isOpen={isOpen} onClose={onClose} title="Editar Proyecto en Planificación">
      {isLoading ? (
        <div className="text-center p-8">Cargando datos del formulario...</div>
      ) : (
        <form onSubmit={handleSubmit} className="max-h-[80vh] overflow-y-auto pr-4">
          {/* ... (El resto de tu JSX del formulario no cambia) ... */}
          
          {/* Mostramos el mensaje de error si existe */}
          {errorMessage && (
            <div className="my-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-center">
              {errorMessage}
            </div>
          )}

          {/* ... (El resto de tu JSX del formulario no cambia) ... */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3">
            <InputField label="ID Aranda" name="idAranda" value={formData.idAranda || ''} onChange={handleChange} />
            <SelectField
              label="Tipo de Proyecto"
              name="tipoProyecto"
              value={formData.tipoProyecto || ''}
              onChange={handleChange}
              options={dropdownOptions.tiposProyecto.map(o => ({ key: o.COD_TIPO, value: o.DESC_TIPO }))}
            />
            <div className="md:col-span-2">
              <TextAreaField label="Descripción del Proyecto" name="descripcion" value={formData.descripcion || ''} onChange={handleChange} maxLength={255} />
            </div>
            <div className="md:col-span-2">
              <TextAreaField label="Alcance del Proyecto" name="alcance" value={formData.alcance || ''} onChange={handleChange} maxLength={600} />
            </div>
            <SelectField
              label="Unidad Solicitante"
              name="unidadSolicitante"
              value={formData.unidadSolicitante || ''}
              onChange={handleChange}
              options={dropdownOptions.unidadesSolicitantes.map(o => ({ key: o.COD_DIR, value: o.DESC_DIR }))}
            />
            <SelectField
              label="Prioridad"
              name="prioridad"
              value={formData.prioridad || ''}
              onChange={handleChange}
              options={dropdownOptions.prioridades.map(o => ({ key: o.COD_PRIORIDAD, value: o.DESC_PRIORIDAD }))}
            />
            <SelectField
              label="Categoría"
              name="categoria"
              value={formData.categoria || ''}
              onChange={handleChange}
              options={dropdownOptions.categorias.map(o => ({ key: o.COD_CATEGORIA, value: o.DESC_CATEGORIA }))}
              disabled={!dropdownOptions.categorias.length}
            />
            <SelectField
              label="Relación"
              name="relacion"
              value={formData.relacion || ''}
              onChange={handleChange}
              options={dropdownOptions.relaciones.map(o => ({ key: o.COD_RELACION, value: o.DESC_RELACION }))}
            />
            <SelectField
              label="¿Relacionar con otro proyecto?"
              name="toggleRelatedSection"
              value={showRelatedProjectSection ? 'Sí' : 'No'}
              onChange={handleToggleRelatedSection}
              options={[{ key: 'No', value: 'No' }, { key: 'Sí', value: 'Sí' }]}
            />
          </div>

          {showRelatedProjectSection && (
            <div className="p-4 border border-slate-200 rounded-lg mt-6 bg-slate-100">
              <h3 className="text-lg font-semibold text-azul mb-4">Detalles del Proyecto Relacionado</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6">
                <SelectField
                  label="Gerencia del Proyecto Relacionado"
                  name="relatedProjectGerencia"
                  value={relatedProjectGerencia?.DESC_DEPARTAMENTO || ''}
                  onChange={handleRelatedGerenciaChange}
                  options={dropdownOptions.gerencias.map(g => ({ key: `${g.COD_DIR}-${g.COD_DEPTO}`, value: g.DESC_DEPARTAMENTO }))}
                />
                <SelectField
                  label="Proyecto Relacionado"
                  name="idProyectoRelacionado"
                  value={formData.idProyectoRelacionado || ''}
                  onChange={handleChange}
                  options={dropdownOptions.relatedProyectosList.map(p => ({ key: p.ID_PROYECTO, value: p.DESC_PROYECTO }))}
                  disabled={!relatedProjectGerencia}
                  useKeyAsValue
                />
                {formData.idProyectoRelacionado && (
                  <SelectField
                    label="Tipo de Relación"
                    name="tipoRelacion"
                    value={formData.tipoRelacion || ''}
                    onChange={handleChange}
                    options={['Continuación', 'Al unísono'].map(v => ({ key: v, value: v }))}
                  />
                )}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6 mt-6">
            <InputField label="Monto de Inversión" name="inversion" type="number" value={formData.inversion || ''} onChange={handleChange} />
            <div className="md:col-start-1">
              <DatePickerField label="Fecha Inicial Planificada" value={formData.fechaInicial} onChange={handleDateChange('fechaInicial')} />
            </div>
            <div>
              <DatePickerField label="Fecha Final Planificada" value={formData.fechaFinal} onChange={handleDateChange('fechaFinal')} />
            </div>
          </div>
          
          <div className="flex justify-end pt-4 border-t border-slate-200 mt-8">
            <button type="button" onClick={onClose} className="mr-3 py-2 px-4 rounded-lg text-slate-700 bg-slate-200 hover:bg-slate-300">Cancelar</button>
            <button type="submit" className="py-2 px-4 rounded-lg text-white bg-blue-600 hover:bg-blue-700">Guardar Cambios</button>
          </div>
        </form>
      )}
    </ModalBaseBig>
  );
};
