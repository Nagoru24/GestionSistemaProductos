// src/components/ActionModal.jsx

import React, { useState, useEffect } from 'react';
import { ModalBase } from './ModalBase';

export const ActionModal = ({ isOpen, onClose, onConfirm, actionType, projectTitle }) => {
  const [justificacion, setJustificacion] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen) {
      setJustificacion('');
      setError('');
    }
  }, [isOpen, actionType]);
  
  const isJustificacionValid = justificacion.trim().replace(/\s/g, '').length >= 20;
  let isFormValid = false;
  let title = '';
  let message = '';

  switch (actionType) {
    case 'aprobar':
      title = `Aprobar Proyecto`;
      message = 'Al confirmar, el proyecto se iniciará utilizando las fechas planificadas. Por favor, proporciona una justificación.';
      isFormValid = isJustificacionValid;
      break;
    case 'pausar':
      title = `Pausar Proyecto`;
      message = 'Por favor, proporciona una justificación para pausar el proyecto.';
      isFormValid = isJustificacionValid;
      break;
    default:
      return null; 
  }

  const handleConfirm = () => {
    if (!isFormValid) {
      setError('Por favor, completa todos los campos requeridos correctamente.');
      return;
    }
    onConfirm({ justificacion });
  };
  
  return (
    <ModalBase isOpen={isOpen} onClose={onClose} title={title}>
      <p className="text-slate-600 mb-2">Proyecto: <span className="font-semibold">{projectTitle}</span></p>
      <p className="text-slate-600 mb-6">{message}</p>

      <div className="space-y-4">

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">
            Justificación <span className="text-red-500">*</span> (mín. 20 caracteres)
          </label>
          <textarea
            value={justificacion}
            onChange={(e) => setJustificacion(e.target.value)}
            className="w-full p-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-azul"
            rows="4"
            placeholder="Describe el motivo de esta acción..."
          ></textarea>
          {!isJustificacionValid && justificacion.length > 0 && (
            <p className="text-xs text-red-500 mt-1">La justificación debe tener al menos 20 caracteres.</p>
          )}
        </div>
      </div>

      {error && <p className="text-sm text-red-600 mt-4">{error}</p>}

      <div className="flex justify-end space-x-3 mt-6">
        <button
          onClick={onClose}
          className="px-4 py-2 bg-slate-200 text-slate-800 rounded-md hover:bg-slate-300 focus:outline-none"
        >
          Cancelar
        </button>
        <button
          onClick={handleConfirm}
          className="px-5 py-2 bg-azul text-white rounded-md hover:bg-indigo-950 transition-colors disabled:bg-slate-400 disabled:cursor-not-allowed"
          disabled={!isFormValid}
        >
          Confirmar
        </button>
      </div>
    </ModalBase>
  );
};
