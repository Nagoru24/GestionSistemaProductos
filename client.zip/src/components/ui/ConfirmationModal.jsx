import React from 'react';

export const ConfirmationModal = ({
  isOpen,
  onClose,
  onConfirm,
  selectedUsers,
  title = 'Confirmar Acción',
  message = '¿Estás seguro de que deseas realizar esta acción?',
  showJustification = false,
  justificacion = '',
  setJustificacion,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 backdrop-blur-lg flex items-center justify-center z-50">
      <div className="bg-white p-8 rounded-xl shadow-2xl w-[50vw] max-w-5xl">
        <h2 className="text-lg font-bold text-gray-800 mb-4">{title}</h2>
        <p className="text-gray-600 mb-4">{message}</p>
        {selectedUsers.length > 0 && (
          <ul className="mb-4 max-h-40 overflow-y-auto">
            {selectedUsers.map((user) => (
              <li key={user?.idFuncionario} className="text-sm text-gray-700">
                {user?.nombreCompleto} ({user?.rol})
              </li>
            ))}
          </ul>
        )}
        {showJustification && (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Justificación <span className="text-red-500">*</span>
            </label>
            <textarea
              value={justificacion}
              onChange={(e) => setJustificacion(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              rows="3"
              placeholder="Ingresa el motivo de la eliminación/inactivación"
            ></textarea>
          </div>
        )}
        <div className="flex justify-end space-x-2">
          <button
            onClick={onClose}
            className="cursor-pointer px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-500"
          >
            Cancelar
          </button>
          <button
            onClick={onConfirm}
            className="px-6 py-2 bg-azul text-white rounded hover:bg-indigo-950 transition-colors cursor-pointer"
            disabled={showJustification && !justificacion.trim()}
          >
            Confirmar
          </button>
        </div>
      </div>
    </div>
  );
};