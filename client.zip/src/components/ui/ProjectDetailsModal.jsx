import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Users } from 'lucide-react';
import { Collapsible } from './Collapsible';
import { ModalBase } from './ModalBase';

export const ProjectDetailsModal = ({ isOpen, onClose, project, collaborators = [], isLoading }) => {
  const [isDetailsExpanded, setIsDetailsExpanded] = useState(false);
  const [isCollabExpanded, setIsCollabExpanded] = useState(false);

  const formatDate = (date) => {
    if (!date) return 'En espera';
    // Ajuste para asegurar que la fecha se muestre correctamente sin problemas de zona horaria
    return new Date(date).toLocaleDateString('es-PA', { timeZone: 'UTC' });
  };
  
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount || 0);
  };

  const renderLoading = () => (
    <div className="text-center p-8">
      <h2 className="text-lg font-semibold text-slate-600">Cargando detalles del proyecto...</h2>
    </div>
  );

  const renderContent = () => (
    <>
      <div className="flex justify-between items-start mb-4">
        <p className="text-sm text-slate-500">
          <strong>Gerencia:</strong> {project?.gerencia}
        </p>
        <div className="flex items-center space-x-2">
          <button onClick={() => setIsCollabExpanded(!isCollabExpanded)} className="p-2 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200" title="Ver Colaboradores"><Users size={18} /></button>
          <button onClick={() => setIsDetailsExpanded(!isDetailsExpanded)} className="p-2 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200" title="Ver Más Detalles">{isDetailsExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}</button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-700 mt-4 pt-4 border-t">
        <p><strong>Prioridad:</strong> <span className="font-semibold text-slate-900">{project?.prioridad}</span></p>
        <p><strong>ID Aranda:</strong> <span className="font-semibold text-slate-900">{project?.idAranda}</span></p>
        <p><strong>Planificado:</strong> {formatDate(project?.fechaInicial)} - {formatDate(project?.fechaFinal)}</p>
        <p><strong>Real:</strong> {formatDate(project?.fechaInicialReal)} - {formatDate(project?.fechaFinalReal)}</p>
      </div>
      
      {/* --- CAMBIO 1: CONTENIDO DE LA SECCIÓN DE COLABORADORES --- */}
      <Collapsible isOpen={isCollabExpanded}>
        <div className="mt-4 pt-4 border-t">
          <h4 className="font-bold text-slate-800 mb-2">Colaboradores Asignados</h4>
          {collaborators.length > 0 ? (
            <ul className="space-y-2 max-h-40 overflow-y-auto">
              {collaborators.map(collab => (
                <li key={collab.idFuncionario} className="flex justify-between items-center bg-slate-50 p-2 rounded-md">
                  <span className="text-sm text-slate-700">{collab.nombreCompleto}</span>
                  <span className="text-xs bg-slate-200 text-slate-600 px-2 py-1 rounded-full">{collab.rol}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-slate-500 italic">No hay colaboradores asignados a este proyecto.</p>
          )}
        </div>
      </Collapsible>
      
      {/* --- CAMBIO 2: CONTENIDO DE LA SECCIÓN DE DETALLES --- */}
      <Collapsible isOpen={isDetailsExpanded}>
        <div className="mt-4 pt-4 border-t grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 text-sm">
          <p className="text-slate-500"><strong>Unidad Solicitante:</strong> <span className="text-slate-700">{project?.unidadSolicitante}</span></p>
          <p className="text-slate-500"><strong>Tipo de Proyecto:</strong> <span className="text-slate-700">{project?.tipoProyecto}</span></p>
          <p className="text-slate-500"><strong>Categoría:</strong> <span className="text-slate-700">{project?.categoria}</span></p>
          <p className="text-slate-500"><strong>Relación:</strong> <span className="text-slate-700">{project?.relacion}</span></p>
          <p className="text-slate-500"><strong>Proyecto Relacionado:</strong> <span className="text-slate-700">{project?.relacionOtroProyecto}</span></p>
          <p className="text-slate-500"><strong>Tipo de Relación:</strong> <span className="text-slate-700">{project?.tipoRelacion}</span></p>
          <p className="text-slate-500 col-span-full"><strong>Alcance:</strong> <span className="text-slate-700">{project?.alcance}</span></p>
          <p className="text-slate-500"><strong>Inversión:</strong> <span className="text-slate-700 font-semibold">{formatCurrency(project?.inversion)}</span></p>
        </div>
      </Collapsible>
    </>
  );

  return (
    <ModalBase 
      isOpen={isOpen} 
      onClose={onClose} 
      title={isLoading || !project ? 'Cargando...' : project.descripcion}
    >
      {isLoading || !project ? renderLoading() : renderContent()}
    </ModalBase>
  );
};