import { Info } from 'lucide-react';

/**
 * Componente de campo de entrada de texto genérico.
 *
 * @param {string} label - El texto de la etiqueta del campo.
 * @param {string} name - El nombre del campo (para el HTML 'name' y 'id').
 * @param {string} type - El tipo de input (e.g., 'text', 'number', 'email').
 * @param {string} value - El valor actual del campo.
 * @param {function} onChange - La función que se llama al cambiar el valor.
 * @param {string} placeholder - El texto del marcador de posición.
 * @param {string} error - Mensaje de error a mostrar.
 * @param {boolean} required - Indica si el campo es obligatorio.
 */
export const InputField = ({ label, name, type = "text", value, onChange, placeholder, error, required }) => (
  <div>
    <label htmlFor={name} className="block text-sm font-medium text-slate-600 mb-1">
      {label} {required && <span className="text-red-500">*</span>}
    </label>
    <input
      type={type}
      id={name}
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className={`
        block w-full px-3 py-2 bg-white border 
        ${error ? 'border-red-500' : 'border-slate-300'} 
        rounded-md text-sm shadow-sm placeholder-slate-400
        focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500
        transition duration-200
      `}
    />
    {error && <p className="mt-1 text-xs text-red-600 flex items-center"><Info size={14} className="mr-1"/>{error}</p>}
  </div>
);
