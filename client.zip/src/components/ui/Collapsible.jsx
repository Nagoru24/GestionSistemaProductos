// src/ui/Collapsible.jsx
import React from 'react';

/**
 * Componente reutilizable para crear secciones colapsables con animación.
 * @param {boolean} isOpen - Controla si la sección está abierta o cerrada.
 * @param {React.ReactNode} children - El contenido a mostrar dentro de la sección.
 */
export function Collapsible({ isOpen, children }) {
  return (
    <div
      className={`
        grid overflow-hidden transition-all duration-300 ease-in-out
        ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}
      `}
    >
      {/* Este div evita que el contenido "salga" del contenedor durante la animación */}
      <div className="overflow-hidden">
        {children}
      </div>
    </div>
  );
}
