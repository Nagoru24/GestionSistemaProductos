// src/pages/AñadirColaboradoresPage.jsx

import React from 'react';
import { Layout } from '../components/Layout';
import { ProjectSummary } from '../components/ProjectSummary';
import { UserList } from '../components/UserList';
import { ConfirmationModal } from '../components/ui/ConfirmationModal';
import { useAddCollaborators } from '../hooks/useAddCollaborators';
import { Notifications } from '../components/ui/Notifications'; // 1. IMPORTAMOS

export const AñadirColaboradoresPage = () => {
  const {
    proyecto,
    usuarios,
    colaboradoresAsignados,
    proyectosPorFuncionario,
    fetchproyectosPorFuncionario,
    selectedUsers,
    toggleSelect,
    isModalOpen,
    isDeleteModalOpen,
    userToDelete,
    justificacion,
    setJustificacion,
    isLoading,
    // 'status' ya no es necesario aquí
    handleOpenModal,
    handleCloseModal,
    handleConfirmModal,
    handleOpenDeleteModal,
    handleCloseDeleteModal,
    handleConfirmDeleteModal,
  } = useAddCollaborators();

  const isApproved = proyecto?.aprobadoPorDirector === true || proyecto?.aprobadoPorDirector === 1;
  const isInactive = userToDelete?.estadoRegistro === 2;

  return (
    <Layout title="Añadir Colaborador">
      <Notifications /> {/* 2. AÑADIMOS EL COMPONENTE DE NOTIFICACIONES */}
      <div>
        {isLoading && <div className="text-center mt-10 text-gray-600">Cargando...</div>}
        
        {/* ESTE BLOQUE SE ELIMINA */}
        {/* {status.message && ( ... )} */}

        {!isLoading && proyecto && (
          <>
            <ProjectSummary
              project={proyecto}
              colaboradoresAsignados={colaboradoresAsignados}
              handleOpenDeleteModal={handleOpenDeleteModal}
            />
            <UserList
              usuarios={usuarios}
              colaboradoresAsignados={colaboradoresAsignados}
              proyectosPorFuncionario={proyectosPorFuncionario}
              fetchproyectosPorFuncionario={fetchproyectosPorFuncionario}
              selectedUsers={selectedUsers}
              toggleSelect={toggleSelect}
              openModal={handleOpenModal}
              isLoading={isLoading}
              gerenciaName={proyecto?.gerencia}
            />
            <ConfirmationModal
              isOpen={isModalOpen}
              onClose={handleCloseModal}
              onConfirm={handleConfirmModal}
              selectedUsers={selectedUsers}
              title="Confirmar Asignación"
              message="¿Estás seguro de que deseas asignar los colaboradores seleccionados al proyecto?"
            />
            <ConfirmationModal
              isOpen={isDeleteModalOpen}
              onClose={handleCloseDeleteModal}
              onConfirm={handleConfirmDeleteModal}
              selectedUsers={[userToDelete]}
              title={isInactive ? 'Confirmar Reactivación' : isApproved ? 'Confirmar Inactivación' : 'Confirmar Eliminación'}
              message={`¿Estás seguro de que deseas ${isInactive ? 'reactivar' : isApproved ? 'inactivar' : 'eliminar'} a ${userToDelete?.nombreCompleto} del proyecto?`}
              showJustification={isInactive || isApproved}
              justificacion={justificacion}
              setJustificacion={setJustificacion}
            />
          </>
        )}
         {!isLoading && !proyecto && (
            <div className="p-8 bg-slate-50 rounded-xl shadow-lg text-center text-red-500">
                No se pudo cargar el proyecto o no tienes permiso para verlo.
            </div>
         )}
      </div>
    </Layout>
  );
};
