import { Layout } from '../components/Layout.jsx';

export const PantallaPrincipalPage = () => {
  return (
    <Layout title="Pantalla Principal">
      <div className="text-center">
        <h1>¡Bienvenido a la aplicación!</h1>
        <p>Selecciona una opción del menú lateral.</p>
      </div>
    </Layout>
  );
};