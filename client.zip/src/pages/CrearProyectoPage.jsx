import { Layout } from '../components/Layout';
import { CreateProject } from '../components/CreateProject.jsx';
import { Notifications } from '../components/ui/Notifications';


export const CrearProyectoPage = () => {
  return (
    <Layout
      title="Crear Proyecto"
    >
      <Notifications />
      <CreateProject />
    </Layout>
  );
};