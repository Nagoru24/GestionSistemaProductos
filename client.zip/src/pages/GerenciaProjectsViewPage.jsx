// src/pages/GerenciaProjectsViewPage.jsx
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useGerenciaProjects } from '../hooks/useGerenciaProjects';
import { useProjectActions } from '../hooks/useProjectActions';
import * as gerenciaService from '../services/gerencia.service';
import { Layout } from '../components/Layout';
import { ProjectCard } from '../components/ProjectCard';
import { ActionModal } from '../components/ui/ActionModal';
import { ProjectDetailsModal } from '../components/ui/ProjectDetailsModal';
import { ConfirmationModal } from '../components/ui/ConfirmationModal';
import { EditProjectModal } from '../components/ui/EditProjectModal';
import { Notifications } from '../components/ui/Notifications'; // <-- 1. IMPORTA EL COMPONENTE

const KanbanColumn = ({ title, projects, ...props }) => (
  <div className="bg-slate-100 rounded-lg p-3 flex-1 min-w-[280px] flex flex-col overflow-hidden">
    <h2 className="text-lg font-bold text-slate-700 mb-2 px-1 sticky top-0 bg-slate-100 py-2 shrink-0">{title} ({projects.length})</h2>
    <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
      {projects.map(project => <ProjectCard key={project.ID_PROYECTO} project={project} {...props} />)}
    </div>
  </div>
);

export const GerenciaProjectsViewPage = () => {
  const navigate = useNavigate(); 
  const { codDir, codDepto } = useParams();
  
  const { proyectos, gerenciaNombre, isLoading, error, refetchProjects } = useGerenciaProjects({ codDir, codDepto });
  
  const { isActionLoading, ...actions } = useProjectActions(refetchProjects);

  const [modalState, setModalState] = useState({ isOpen: false, actionType: null, project: null });
  const [detailsModal, setDetailsModal] = useState({ isOpen: false, project: null, collaborators: [], isLoading: false });
  const [deleteModal, setDeleteModal] = useState({ isOpen: false, project: null });
  const [editModal, setEditModal] = useState({ isOpen: false, project: null });

  const handleOpenEditModal = async (project) => {
    setEditModal({ isOpen: true, project: null }); 
    try {
      const { proyecto: proyectoCompleto } = await gerenciaService.getProyectoCompletoPorId(project.ID_PROYECTO);
      setEditModal({ isOpen: true, project: proyectoCompleto });
    } catch (err) {
      console.error("Error al cargar datos para editar:", err);
      setEditModal({ isOpen: false, project: null });
    }
  };
  const handleCloseEditModal = () => setEditModal({ isOpen: false, project: null });
  const handleConfirmEditModal = (formData) => {
    const projectToEdit = editModal.project;
    if (!projectToEdit) return;
    if (projectToEdit.COD_ESTATUS === 2) {
      actions.editarPlanificacion(projectToEdit.ID_PROYECTO, formData);
    } else if (projectToEdit.COD_ESTATUS === 3 || projectToEdit.COD_ESTATUS === 4) {
      actions.actualizarAvance(projectToEdit.ID_PROYECTO, formData);
    }
    handleCloseEditModal();
  };
  const handleNavigateToAddCollaborators = (projectId) => navigate(`/añadir-colaboradores/${projectId}`);
  const handleOpenModal = (project, actionType) => setModalState({ isOpen: true, project, actionType });
  const handleCloseModal = () => setModalState({ isOpen: false, project: null, actionType: null });
  const handleOpenDeleteModal = (project) => setDeleteModal({ isOpen: true, project });
  const handleCloseDeleteModal = () => setDeleteModal({ isOpen: false, project: null });
  const handleConfirmDelete = () => {
    if (deleteModal.project) actions.eliminar(deleteModal.project.ID_PROYECTO);
    handleCloseDeleteModal();
  };
  const handleConfirmModal = (formData) => {
    const { project, actionType } = modalState;
    if (!project) return;
    switch (actionType) {
      case 'aprobar': actions.aprobar(project.ID_PROYECTO, { justificacion: formData.justificacion }); break;
      case 'pausar': actions.pausar(project.ID_PROYECTO, { justificacion: formData.justificacion }); break;
      case 'reactivar': actions.reactivar(project.ID_PROYECTO); break;
      case 'completar': actions.completar(project.ID_PROYECTO); break;
    }
    handleCloseModal();
  };
  const handleOpenDetailsModal = async (projectId) => {
    setDetailsModal({ isOpen: true, project: null, collaborators: [], isLoading: true });
    try {
      const { proyecto, colaboradores } = await gerenciaService.getProyectoCompletoPorId(projectId);
      setDetailsModal({ isOpen: true, project: proyecto, collaborators: colaboradores, isLoading: false });
    } catch (err) {
      console.error("Error al cargar detalles completos:", err);
      setDetailsModal({ isOpen: false, project: null, collaborators: [], isLoading: false });
    }
  };
  const handleCloseDetailsModal = () => setDetailsModal({ isOpen: false, project: null, collaborators: [], isLoading: false });


  if (isLoading || isActionLoading) return <Layout title="Cargando..."><div className="text-center p-8">Cargando proyectos...</div></Layout>;
  if (error) return <Layout title="Error"><div className="text-center p-8 text-red-500">{error}</div></Layout>;

  const porIniciar = proyectos.filter(p => p.COD_ESTATUS === 2);
  const enProceso = proyectos.filter(p => p.COD_ESTATUS === 3 || p.COD_ESTATUS === 4);
  const enPausa = proyectos.filter(p => p.COD_ESTATUS === 5);
  const completados = proyectos.filter(p => p.COD_ESTATUS === 1);

  return (
    <Layout title={gerenciaNombre}>
      <Notifications />

      <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-10rem)]">
        <KanbanColumn title="Por Iniciar" projects={porIniciar} onOpenModal={handleOpenModal} onOpenDetailsModal={handleOpenDetailsModal} onNavigate={handleNavigateToAddCollaborators} onOpenDeleteModal={handleOpenDeleteModal} onOpenEditModal={handleOpenEditModal} />
        <KanbanColumn title="En Proceso" projects={enProceso} onOpenModal={handleOpenModal} onOpenDetailsModal={handleOpenDetailsModal} onNavigate={handleNavigateToAddCollaborators} onOpenDeleteModal={handleOpenDeleteModal} onOpenEditModal={handleOpenEditModal} />
        <KanbanColumn title="En Pausa" projects={enPausa} onOpenModal={handleOpenModal} onOpenDetailsModal={handleOpenDetailsModal} onNavigate={handleNavigateToAddCollaborators} onOpenDeleteModal={handleOpenDeleteModal} onOpenEditModal={handleOpenEditModal} />
        <KanbanColumn title="Completados" projects={completados} onOpenModal={handleOpenModal} onOpenDetailsModal={handleOpenDetailsModal} onNavigate={handleNavigateToAddCollaborators} onOpenDeleteModal={handleOpenDeleteModal} onOpenEditModal={handleOpenEditModal} />
      </div>

      <ActionModal isOpen={modalState.isOpen} onClose={handleCloseModal} onConfirm={handleConfirmModal} actionType={modalState.actionType} projectTitle={modalState.project?.DESC_PROYECTO || ''} />
      <ProjectDetailsModal isOpen={detailsModal.isOpen} onClose={handleCloseDetailsModal} project={detailsModal.project} collaborators={detailsModal.collaborators} isLoading={detailsModal.isLoading} />
      <ConfirmationModal isOpen={deleteModal.isOpen} onClose={handleCloseDeleteModal} onConfirm={handleConfirmDelete} title="Confirmar Eliminación" message={`¿Estás seguro de que deseas eliminar o inactivar el proyecto "${deleteModal.project?.DESC_PROYECTO}"?`} selectedUsers={[]} />
      <EditProjectModal isOpen={editModal.isOpen} onClose={handleCloseEditModal} onConfirm={handleConfirmEditModal} project={editModal.project} />
    </Layout>
  );
};
