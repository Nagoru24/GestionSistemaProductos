// src/hooks/useProjectActions.js
import { useState } from 'react';
import toast from 'react-hot-toast'; 
import * as gerenciaService from '../services/gerencia.service.js';

export const useProjectActions = (onActionSuccess) => {
  const [isActionLoading, setIsActionLoading] = useState(false);


  const performAction = async (action, successMessage, ...args) => {
    setIsActionLoading(true);
    try {
      await action(...args);
      toast.success(successMessage); 
      if (onActionSuccess) {
        onActionSuccess();
      }
    } catch (error) {
      console.error("Error en la acción del proyecto:", error);
      const errorMessage = error.response?.data?.message || 'Ocurrió un error inesperado.';
      toast.error(errorMessage); 
    } finally {
      setIsActionLoading(false);
    }
  };

  const aprobar = (idProyecto, data) => {
    performAction(gerenciaService.aprobarProyecto, '¡Proyecto aprobado con éxito!', idProyecto, data);
  };

  const pausar = (idProyecto, data) => {
    performAction(gerenciaService.pausarProyecto, 'Proyecto pausado correctamente.', idProyecto, data);
  };
  
  const reactivar = (idProyecto) => {
    performAction(gerenciaService.reactivarProyecto, 'Proyecto reactivado.', idProyecto);
  };

  const completar = (idProyecto) => {
    performAction(gerenciaService.completarProyecto, '¡Proyecto completado!', idProyecto);
  };

  const eliminar = (idProyecto) => {
    performAction(gerenciaService.eliminarProyecto, 'El proyecto ha sido eliminado/inactivado.', idProyecto);
  };

  const editarPlanificacion = (idProyecto, data) => {
    performAction(gerenciaService.editarProyectoPlanificado, 'Planificación del proyecto actualizada.', idProyecto, data);
  };

  return { isActionLoading, aprobar, pausar, reactivar, completar, eliminar, editarPlanificacion };
};
