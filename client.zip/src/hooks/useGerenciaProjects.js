// src/hooks/useGerenciaProjects.js
import { useState, useEffect, useCallback } from 'react';
import * as gerenciaService from '../services/gerencia.service.js';
import { useAuth } from './useAuth';

/**
 * Hook para gestionar la obtención de proyectos de una gerencia.
 * Encapsula la lógica de fetching, estados de carga, errores y el nombre de la gerencia.
 * @param {{ codDir: string, codDepto: string }} params - Los códigos de la gerencia a consultar.
 */
export const useGerenciaProjects = ({ codDir, codDepto }) => {
  const { user } = useAuth(); // Obtenemos el usuario para la lógica del nombre
  const [proyectos, setProyectos] = useState([]);
  const [gerenciaNombre, setGerenciaNombre] = useState('Proyectos');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchProjects = useCallback(async () => {
    // Evita ejecuciones si los parámetros no están listos
    if (!codDir || !codDepto) return;

    setIsLoading(true);
    setError(null);

    try {
      const data = await gerenciaService.getProyectosPorGerencia({ codDir, codDepto });
      setProyectos(data);

      // --- Lógica para determinar el nombre de la Gerencia ---
      if (data.length > 0 && data[0].DESC_DEPARTAMENTO) {
        setGerenciaNombre(data[0].DESC_DEPARTAMENTO);
      } else if (user.rol === 'Gerente' || user.rol === 'Colaborador') {
        setGerenciaNombre(user.descDepartamento);
      } else {
        // Fallback para PM/Director si la gerencia no tiene proyectos
        const allGerencias = await gerenciaService.getGerencias();
        const currentGerencia = allGerencias.find(g => 
          g.COD_DIR.toString() === codDir && g.COD_DEPTO.toString() === codDepto
        );
        if (currentGerencia) {
          setGerenciaNombre(currentGerencia.DESC_DEPARTAMENTO);
        } else {
          setGerenciaNombre('Gerencia no encontrada');
        }
      }
    } catch (err) {
      console.error("Error al cargar proyectos de la gerencia:", err);
      setError("No se pudieron cargar los proyectos. Intente más tarde.");
    } finally {
      setIsLoading(false);
    }
  }, [codDir, codDepto, user]);

  // Ejecuta la carga de datos cuando los parámetros cambian
  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  // Exponemos los estados y una función para recargar los datos manualmente si es necesario
  return { proyectos, gerenciaNombre, isLoading, error, refetchProjects: fetchProjects };
};