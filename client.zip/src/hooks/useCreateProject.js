// src/hooks/useCreateProject.js

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast'; // Se importa toast para las notificaciones
import { useAuth } from './useAuth.js';
import { projectService } from '../services/project.service.js';

export const useCreateProject = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [gerencias, setGerencias] = useState([]);
  const [unidadesSolicitantes, setUnidadesSolicitantes] = useState([]);
  const [tiposProyecto, setTiposProyecto] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [prioridades, setPrioridades] = useState([]);
  const [relaciones, setRelaciones] = useState([]);
  const [relatedProyectos, setRelatedProyectos] = useState([]);
  const [formData, setFormData] = useState({
    gerencia: null,
    unidadSolicitante: null,
    idAranda: '',
    tipoProyecto: '',
    categoria: '',
    relacion: '',
    relacionOtroProyecto: '',
    tipoRelacion: '',
    descripcion: '',
    alcance: '',
    prioridad: '',
    inversion: '',
    fechaInicial: null,
    fechaFinal: null,
  });
  const [errors, setErrors] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showRelatedProjectSection, setShowRelatedProjectSection] = useState(false);
  const [relatedProjectGerencia, setRelatedProjectGerencia] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Se elimina el estado 'status'

  // Fetch initial form data
  useEffect(() => {
    const fetchAllData = async () => {
      setIsLoading(true);
      try {
        const response = await projectService.fetchFormData();
        const { gerencias, unidadesSolicitantes, tiposProyecto, prioridades, relaciones } = response.data;
        setGerencias(gerencias || []);
        setUnidadesSolicitantes(unidadesSolicitantes || []);
        setTiposProyecto(tiposProyecto || []);
        setPrioridades(prioridades || []);
        setRelaciones(relaciones || []);
      } catch (error) {
        console.error('Error al obtener datos iniciales:', error);
        // Se usa toast para mostrar el error
        toast.error('No se pudieron cargar los datos iniciales.');
      } finally {
        setIsLoading(false);
      }
    };
    fetchAllData();
  }, []);

  // Preselect gerencia for Gerente role
  useEffect(() => {
    if (user && user.rol === 'Gerente' && gerencias.length > 0) {
      const preselectedGerencia = gerencias.find(g => g.COD_DIR === user.codDir && g.COD_DEPTO === user.codDepto);
      if (preselectedGerencia) {
        setFormData(prev => ({ ...prev, gerencia: preselectedGerencia }));
      }
    }
  }, [user, gerencias]);

  // Fetch categories based on selected gerencia
  useEffect(() => {
    const fetchCategories = async (gerenciaData) => {
      try {
        const { COD_DIR, COD_DEPTO } = gerenciaData;
        const response = await projectService.fetchCategories(COD_DIR, COD_DEPTO);
        setCategorias(response.data.categorias || []);
      } catch (error) {
        console.error("Error al obtener categorías:", error);
        setCategorias([]);
      }
    };
    if (formData.gerencia) {
      fetchCategories(formData.gerencia);
    } else {
      setCategorias([]);
    }
  }, [formData.gerencia]);

  // Fetch related projects
  useEffect(() => {
    if (showRelatedProjectSection && relatedProjectGerencia) {
      const fetchRelatedProjects = async () => {
        try {
          const { COD_DIR, COD_DEPTO } = relatedProjectGerencia;
          const response = await projectService.fetchRelatedProjects(COD_DIR, COD_DEPTO);
          setRelatedProyectos(response.data.proyectosRelacionados || []);
        } catch (error) {
          console.error("Error al obtener proyectos relacionados:", error);
          setRelatedProyectos([]);
        }
      };
      fetchRelatedProjects();
    } else {
      setRelatedProyectos([]);
    }
  }, [showRelatedProjectSection, relatedProjectGerencia]);

  // Handlers (sin cambios)
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    validateField(name, value);
  };

  const handleGerenciaChange = (e) => {
    const selectedDesc = e.target.value;
    const selectedGerencia = gerencias.find(g => g.DESC_DEPARTAMENTO === selectedDesc);
    setFormData((prev) => ({ ...prev, gerencia: selectedGerencia, unidadSolicitante: null, categoria: '' }));
    validateField('gerencia', selectedDesc);
  };

  const handleUnidadSolicitanteChange = (e) => {
    const selectedDesc = e.target.value;
    const selectedUnidad = unidadesSolicitantes.find(u => u.DESC_DIR === selectedDesc);
    setFormData((prev) => ({ ...prev, unidadSolicitante: selectedUnidad }));
    validateField('unidadSolicitante', selectedDesc);
  };

  const handleRelatedGerenciaChange = (e) => {
    const selectedDesc = e.target.value;
    const selectedGerencia = gerencias.find(g => g.DESC_DEPARTAMENTO === selectedDesc);
    setRelatedProjectGerencia(selectedGerencia);
    setFormData((prev) => ({ ...prev, relacionOtroProyecto: '', tipoRelacion: '' }));
    validateField('relatedProjectGerencia', selectedDesc);
  };

  const handleToggleRelatedSection = (e) => {
    const wantsToRelate = e.target.value === 'Sí';
    setShowRelatedProjectSection(wantsToRelate);
    if (!wantsToRelate) {
      setRelatedProjectGerencia(null);
      setFormData((prev) => ({ ...prev, relacionOtroProyecto: '', tipoRelacion: '' }));
      setErrors((prev) => ({ ...prev, relatedProjectGerencia: '', relacionOtroProyecto: '', tipoRelacion: '' }));
    }
  };

  const handleDateChange = (name) => (date) => {
    setFormData((prev) => ({ ...prev, [name]: date }));
    validateField(name, date);
  };

  const handleTextAreaChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    validateField(name, value);
  };

  // Validation (sin cambios)
  const validateField = (name, value) => {
    const newErrors = { ...errors };
    newErrors[name] = '';
    switch (name) {
      case 'gerencia':
        if (!value && user?.rol !== 'Gerente') newErrors[name] = 'Campo obligatorio';
        break;
      case 'unidadSolicitante':
      case 'tipoProyecto':
      case 'categoria':
      case 'relacion':
      case 'prioridad':
      case 'fechaInicial':
        if (!value) newErrors[name] = 'Campo obligatorio';
        break;
      case 'descripcion':
        if (!value) newErrors[name] = 'Campo obligatorio';
        else if (value.length > 255) newErrors[name] = 'Máximo 255 caracteres';
        break;
      case 'alcance':
        if (!value) newErrors[name] = 'Campo obligatorio';
        else if (value.length < 10) newErrors[name] = 'Mínimo 10 caracteres';
        else if (value.length > 600) newErrors[name] = 'Máximo 600 caracteres';
        break;
      case 'fechaFinal':
        if (!value) newErrors[name] = 'Campo obligatorio';
        else if (formData.fechaInicial && new Date(value) <= new Date(formData.fechaInicial))
          newErrors[name] = 'Debe ser posterior a la fecha inicial';
        break;
      case 'tipoRelacion':
        if (formData.relacionOtroProyecto && !value) newErrors[name] = 'Campo obligatorio';
        break;
      case 'relatedProjectGerencia':
        if (showRelatedProjectSection && !value) newErrors[name] = 'Seleccione una gerencia';
        break;
      default:
        break;
    }
    setErrors(newErrors);
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.gerencia && user?.rol !== 'Gerente') newErrors.gerencia = 'Campo obligatorio';
    if (!formData.unidadSolicitante) newErrors.unidadSolicitante = 'Campo obligatorio';
    if (!formData.tipoProyecto) newErrors.tipoProyecto = 'Campo obligatorio';
    if (!formData.categoria) newErrors.categoria = 'Campo obligatorio';
    if (!formData.relacion) newErrors.relacion = 'Campo obligatorio';
    if (!formData.prioridad) newErrors.prioridad = 'Campo obligatorio';
    if (!formData.fechaInicial) newErrors.fechaInicial = 'Campo obligatorio';
    if (!formData.fechaFinal) newErrors.fechaFinal = 'Campo obligatorio';
    if (!formData.descripcion) newErrors.descripcion = 'Campo obligatorio';
    else if (formData.descripcion.length > 255) newErrors.descripcion = 'Máximo 255 caracteres';
    if (!formData.alcance) newErrors.alcance = 'Campo obligatorio';
    else if (formData.alcance.length < 10) newErrors.alcance = 'Mínimo 10 caracteres';
    else if (formData.alcance.length > 600) newErrors.alcance = 'Máximo 600 caracteres';
    if (formData.fechaInicial && formData.fechaFinal && new Date(formData.fechaFinal) <= new Date(formData.fechaInicial))
      newErrors.fechaFinal = 'Debe ser posterior a la fecha inicial';
    if (showRelatedProjectSection) {
      if (!relatedProjectGerencia) newErrors.relatedProjectGerencia = 'Campo obligatorio';
      if (!formData.relacionOtroProyecto) newErrors.relacionOtroProyecto = 'Campo obligatorio';
      if (formData.relacionOtroProyecto && !formData.tipoRelacion) newErrors.tipoRelacion = 'Campo obligatorio';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      setIsModalOpen(true);
    } else {
      // Se usa toast para el error de validación
      toast.error('Por favor, corrige los errores en el formulario.');
    }
  };

  const createAndNavigate = async (navigateToCollaborators = false) => {
    setIsModalOpen(false);
    setIsSubmitting(true);

    const selectedTipo = tiposProyecto.find(t => t.DESC_TIPO === formData.tipoProyecto);
    const selectedCategoria = categorias.find(c => c.DESC_CATEGORIA === formData.categoria);
    const selectedRelacion = relaciones.find(r => r.DESC_RELACION === formData.relacion);
    const selectedPrioridad = prioridades.find(p => p.DESC_PRIORIDAD === formData.prioridad);
    const selectedProyectoRelacionado = relatedProyectos.find(p => p.DESC_PROYECTO === formData.relacionOtroProyecto);

    const payload = {
      rol: user?.rol,
      idFuncionario: user?.idFuncionario,
      codDir: formData.gerencia?.COD_DIR || user?.codDir,
      codDepto: formData.gerencia?.COD_DEPTO || user?.codDepto,
      idAranda: formData.idAranda || null,
      unidadSolicitante: formData.unidadSolicitante?.COD_DIR,
      codCategoria: selectedCategoria?.COD_CATEGORIA,
      codRelacion: selectedRelacion?.COD_RELACION,
      codTipo: selectedTipo?.COD_TIPO,
      codPrioridad: selectedPrioridad?.COD_PRIORIDAD,
      descProyecto: formData.descripcion,
      alcanceProyecto: formData.alcance,
      fechaInicialPlanificada: formData.fechaInicial,
      fechaFinalPlanificada: formData.fechaFinal,
      montoInversion: parseFloat(formData.inversion) || 0,
      usuarioCreacion: user?.usuario,
      idProyectoRelacionado: showRelatedProjectSection ? selectedProyectoRelacionado?.ID_PROYECTO : null,
      tipoRelacion: formData.tipoRelacion || null,
      codEstatus: 2,
    };

    // Se usa toast.promise para manejar los estados de la petición
    await toast.promise(
      projectService.createProject(payload),
      {
        loading: 'Creando proyecto...',
        success: (response) => {
          const projectId = response.data.ID_PROYECTO_OUT;
          if (!projectId) {
            throw new Error('No se recibió un ID para el proyecto creado.');
          }
          if (navigateToCollaborators) {
            navigate(`/añadir-colaboradores/${projectId}`);
          } else {
            const { codDir, codDepto } = payload;
            navigate(`/gerencia/${codDir}/${codDepto}`);
          }
          return `¡Proyecto "${payload.descProyecto}" creado con éxito!`;
        },
        error: (err) => {
          console.error("Error al crear proyecto:", err);
          return err.response?.data?.error || 'Error al crear el proyecto.';
        }
      }
    );

    setIsSubmitting(false);
  };

  const handleConfirm = () => createAndNavigate(false);
  const handleConfirmAndAddCollaborators = () => createAndNavigate(true);

  const handleClearForm = () => {
    setFormData({
      gerencia: null,
      unidadSolicitante: null,
      idAranda: '',
      tipoProyecto: '',
      categoria: '',
      relacion: '',
      relacionOtroProyecto: '',
      tipoRelacion: '',
      descripcion: '',
      alcance: '',
      prioridad: '',
      inversion: '',
      fechaInicial: null,
      fechaFinal: null,
    });
    setErrors({});
    setShowRelatedProjectSection(false);
    setRelatedProjectGerencia(null);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  return {
    user,
    isLoading,
    formData,
    errors,
    isSubmitting,
    isModalOpen,
    showRelatedProjectSection,
    relatedProjectGerencia,
    gerencias,
    unidadesSolicitantes,
    tiposProyecto,
    categorias,
    prioridades,
    relaciones,
    relatedProyectos,
    handleChange,
    handleGerenciaChange,
    handleUnidadSolicitanteChange,
    handleRelatedGerenciaChange,
    handleToggleRelatedSection,
    handleDateChange,
    handleTextAreaChange,
    handleSubmit,
    handleConfirm,
    handleConfirmAndAddCollaborators,
    handleCloseModal,
    handleClearForm, // Se exporta la función para que pueda ser utilizada
  };
};
