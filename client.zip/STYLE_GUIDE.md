GUÍA DE ESTILOS DEL PROYECTO

📐 Resolución Base
- Pantalla de diseño: 1366 x 768 px (Laptop)

🔤 Tipografía
- Fuente principal: Roboto
- Estilos recomendados: Regular (400), Medium (500), Bold (700)
- Tamaños sugeridos:
  - Títulos: 32px - 36px
  - Subtítulos: 16px - 18px
  - Texto general: 14px
  - Notas o texto auxiliar: 10px
 

🧩 Componentes UI

📁 Sidebar
- Fondo del Sidebar      #003F63   
- Iconos del Sidebar     #FFFFFF   
- Texto del Sidebar      #FFFFFF   
- Divider del Sidebar    #FFFFFF    
- Interacción: Opciones desplegables para secciones como Gerencia y Bitácora
- Padding interno: 8px
- Ancho sugerido: 202px

📁 Navbar




