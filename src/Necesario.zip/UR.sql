SELECT * FROM T_DIM_FUNCIONARIO
SELECT *FROM T_REL_FUNCIONARIO
SELECT * FROM T_FACT_PROYECTO ORDER BY ID_PROYECTO DESC
SELECT * FROM T_DIM_RELACION

SELECT * FROM T_DIM_CATEGORIA
SELECT * FROM T_DIM_TIPO_PROYECTO

SELECT * FROM T_DIM_ESTADO_REGISTRO
SELECT * FROM T_DIM_ESTATUS_PROYECTO
SELECT * FROM T_DIM_CARTERA

SELECT * FROM T_DIM_ROL

SELECT * FROM T_REL_PROYECTO_PROYECTO ORDER BY ID_PROYECTO_BASE DESC

SELECT * FROM T_REL_FUNCIONARIO

DELETE FROM T_REL_PROYECTO_PROYECTO
WHERE ID_PROYECTO_BASE = 73 AND ESTADO_REGISTRO = 2;

TRUNCATE TABLE T_REL_PROYECTO_PROYECTO;

SELECT * FROM T_REL_FUNCIONARIO

SELECT * FROM T_DIM_ESTATUS_PROYECTO
SELECT * FROM T_DIM_AUDITORIA

ALTER TABLE T_FACT_PROYECTO
DROP COLUMN FECHA_ENTREGA_ASIGNADA;

-- Creaci�n de la tabla para almacenar d�as feriados
CREATE TABLE T_DIM_FERIADOS (
    FECHA DATE PRIMARY KEY,
    DESCRIPCION VARCHAR(100) NOT NULL
);
GO


SELECT ID_PROYECTO, APROBADO_POR_DIRECTOR, DESC_PROYECTO, ALCANCE_PROYECTO
FROM T_FACT_PROYECTO WHERE APROBADO_POR_DIRECTOR = 1


UPDATE T_FACT_PROYECTO
SET APROBADO_POR_DIRECTOR = 1
WHERE ID_PROYECTO = 22


-- Insertamos algunos feriados de Panam� para 2025 como ejemplo
-- Deber�s completar esta lista con todos los feriados oficiales
INSERT INTO T_DIM_FERIADOS (FECHA, DESCRIPCION) VALUES
('2025-01-01', 'A�o Nuevo'),
('2025-01-09', 'D�a de los M�rtires'),
('2025-03-03', 'Lunes de Carnaval'),
('2025-03-04', 'Martes de Carnaval'),
('2025-04-18', 'Viernes Santo'),
('2025-05-01', 'D�a del Trabajo'),
('2025-11-03', 'Separaci�n de Panam� de Colombia'),
('2025-11-05', 'D�a de Col�n'),
('2025-11-10', 'Primer Grito de Independencia de La Villa de Los Santos'),
('2025-11-28', 'Independencia de Panam� de Espa�a'),
('2025-12-08', 'D�a de la Madre'),
('2025-12-25', 'Navidad');
GO

-- Ejecuta esto en tu gestor de base de datos
EXEC SP_APROBAR_PROYECTO
    @ID_PROYECTO = 24, -- Usa un ID de proyecto v�lido que est� en estado "Por Iniciar"
    @FECHA_ENTREGA_ASIGNADA = '2025-12-31',
    @USUARIO_MODIFICACION = 'debug_user',
    @JUSTIFICACION = 'Prueba de depuraci�n directa.';









DECLARE @ID_GERENTE_PRUEBA INT = 289;

-- Coloca aqu� el a�o (periodo) de la cartera que quieres eliminar.
DECLARE @PERIODO_PRUEBA INT = 2025;
-- ------------------------------------------------------------------------------------


-- El resto del script se ejecuta autom�ticamente, no necesitas modificarlo.

PRINT 'Iniciando limpieza de carteras de prueba...';

-- Tabla temporal para guardar los IDs de los proyectos a eliminar
DECLARE @ProyectosAEliminar TABLE (ID_PROYECTO INT);
DECLARE @CarterasAEliminar TABLE (ID_CARTERA INT);

-- Identificar las carteras a eliminar
INSERT INTO @CarterasAEliminar (ID_CARTERA)
SELECT ID_CARTERA
FROM T_DIM_CARTERA
WHERE ID_GERENTE_CREADOR = @ID_GERENTE_PRUEBA
  AND PERIODO = @PERIODO_PRUEBA
  AND ESTADO_CARTERA = 'Por Aprobar';

-- Identificar los proyectos asociados a esas carteras
INSERT INTO @ProyectosAEliminar (ID_PROYECTO)
SELECT ID_PROYECTO
FROM T_FACT_PROYECTO
WHERE ID_CARTERA IN (SELECT ID_CARTERA FROM @CarterasAEliminar);

-- Iniciar una transacci�n para asegurar que todo se elimine correctamente o nada
BEGIN TRANSACTION;

BEGIN TRY
    -- 1. Eliminar relaciones entre proyectos (si existen)
    DELETE FROM T_REL_PROYECTO_PROYECTO
    WHERE ID_PROYECTO_BASE IN (SELECT ID_PROYECTO FROM @ProyectosAEliminar)
       OR ID_PROYECTO_RELACIONADO IN (SELECT ID_PROYECTO FROM @ProyectosAEliminar);
    PRINT CONVERT(VARCHAR, @@ROWCOUNT) + ' registros eliminados de T_REL_PROYECTO_PROYECTO.';

    -- 2. Eliminar asignaciones de colaboradores (si existen)
    DELETE FROM T_REL_FUNCIONARIO
    WHERE ID_PROYECTO IN (SELECT ID_PROYECTO FROM @ProyectosAEliminar);
    PRINT CONVERT(VARCHAR, @@ROWCOUNT) + ' registros eliminados de T_REL_FUNCIONARIO.';

    -- 3. Eliminar los proyectos de la cartera
    DELETE FROM T_FACT_PROYECTO
    WHERE ID_PROYECTO IN (SELECT ID_PROYECTO FROM @ProyectosAEliminar);
    PRINT CONVERT(VARCHAR, @@ROWCOUNT) + ' registros eliminados de T_FACT_PROYECTO.';

    -- 4. Eliminar la cartera principal
    DELETE FROM T_DIM_CARTERA
    WHERE ID_CARTERA IN (SELECT ID_CARTERA FROM @CarterasAEliminar);
    PRINT CONVERT(VARCHAR, @@ROWCOUNT) + ' registros eliminados de T_DIM_CARTERA.';

    COMMIT TRANSACTION;
    PRINT '----------------------------------------------------------------';
    PRINT '�Limpieza completada! Ya puedes crear una nueva cartera.';

END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    PRINT '----------------------------------------------------------------';
    PRINT 'Ocurri� un error. No se realizaron cambios en la base de datos.';
    -- Imprimir el error original para depuraci�n
    THROW;
END CATCH;
GO