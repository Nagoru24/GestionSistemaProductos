// src/pages/EditarCarteraPage.jsx
import React from 'react';
import { Layout } from '../components/Layout';

export const EditarCarteraPage = () => {
  return (
    <Layout title="Editar Cartera de Proyectos">
        <div className="mx-auto p-8 bg-slate-50 rounded-xl shadow-lg text-center">
            <h1 className="text-2xl font-bold text-azul">Página en Construcción</h1>
            <p className="text-slate-600 mt-2">
                Aquí podrás ver la cartera que creaste, editar los proyectos y aprobarla para su ejecución.
            </p>
        </div>
    </Layout>
  );
};
