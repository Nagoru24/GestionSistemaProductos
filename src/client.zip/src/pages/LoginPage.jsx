// src/pages/LoginPage.jsx

import React from 'react';
import { Login } from '../components/Login';
import { Notifications } from '../components/ui/Notifications'; // IMPORTAMOS

export const LoginPage = () => {
  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
      <Notifications /> {/* AÑADIMOS EL COMPONENTE */}
      <Login />
    </div>
  );
};
