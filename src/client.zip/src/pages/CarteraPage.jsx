// src/pages/CarteraPage.jsx
import { Layout } from '../components/Layout';
import { useCartera } from '../hooks/useCartera';
import { CarteraHeader } from '../components/carteraPage/CarteraHeader';
import { CarteraProjectList } from '../components/carteraPage/CarteraProjectList';
import { AddProjectToCarteraModal } from '../components/carteraPage/AddProjectToCarteraModal.jsx';
import { ApproveCarteraModal } from '../components/carteraPage/ApproveCarteraModal';
import { CarteraProjectDetailsModal } from '../components/carteraPage/CarteraProjectDetailsModal';
import { EditCarteraProjectModal } from '../components/carteraPage/EditCarteraProjectModal';
// --- INICIO DE LA SOLUCIÓN (Paso 1) ---
import { DeleteProjectModal } from '../components/carteraPage/DeleteProjectModal';
// --- FIN DE LA SOLUCIÓN (Paso 1) ---


export const CarteraPage = () => {
  const {
    cartera, proyectos, isLoading, error,
    isAddModalOpen, openAddModal, closeAddModal, handleAddProyecto,
    isEditModalOpen, projectToEdit, openEditModal, closeEditModal, handleEditProyecto,
    isApproveModalOpen, openApproveModal, closeApproveModal, handleApproveCartera,
    isDetailsModalOpen, isDetailsLoading, selectedProjectDetails, openDetailsModal, closeDetailsModal,
    isDetailsExpanded, isCollabExpanded, toggleDetailsExpansion, toggleCollabExpansion,
    formOptions, isFormLoading, fetchProyectosRelacionables,
    // --- INICIO DE LA SOLUCIÓN (Paso 2) ---
    isDeleteModalOpen, projectToDelete, openDeleteModal, closeDeleteModal, handleDeleteProyecto
    // --- FIN DE LA SOLUCIÓN (Paso 2) ---
  } = useCartera();

  return (
    <Layout title={cartera?.NOMBRE_CARTERA || 'Cartera de Proyectos'}>
      <div className="mx-auto">
        <CarteraHeader
          cartera={cartera}
          projectCount={proyectos.length}
          onAddProject={openAddModal}
          onApprove={openApproveModal}
          isLoading={isLoading}
        />
        <CarteraProjectList
          projects={proyectos}
          isLoading={isLoading}
          error={error}
          onEditProject={openEditModal}
          onOpenDetailsModal={openDetailsModal}
          // --- INICIO DE LA SOLUCIÓN (Paso 3) ---
          onDeleteProject={openDeleteModal} // <-- Aquí conectamos la función
          // --- FIN DE LA SOLUCIÓN (Paso 3) ---
        />
      </div>

      {/* --- Modales --- */}

      {isAddModalOpen && (
        <AddProjectToCarteraModal
          isOpen={isAddModalOpen}
          onClose={closeAddModal}
          onSubmit={handleAddProyecto}
          carteraId={cartera?.ID_CARTERA}
          formOptions={formOptions}
          isFormLoading={isFormLoading}
          fetchProyectosRelacionables={fetchProyectosRelacionables}
        />
      )}

      {isApproveModalOpen && (
        <ApproveCarteraModal
          isOpen={isApproveModalOpen}
          onClose={closeApproveModal}
          onConfirm={handleApproveCartera}
          projectCount={proyectos.length}
        />
      )}

      {isDetailsModalOpen && (
        <CarteraProjectDetailsModal
          isOpen={isDetailsModalOpen}
          onClose={closeDetailsModal}
          project={selectedProjectDetails?.proyecto}
          collaborators={selectedProjectDetails?.colaboradores}
          isLoading={isDetailsLoading}
          isDetailsExpanded={isDetailsExpanded}
          isCollabExpanded={isCollabExpanded}
          onToggleDetails={toggleDetailsExpansion}
          onToggleCollabs={toggleCollabExpansion}
        />
      )}
      
      {isEditModalOpen && (
        <EditCarteraProjectModal
          isOpen={isEditModalOpen}
          onClose={closeEditModal}
          onSubmit={handleEditProyecto}
          projectToEdit={projectToEdit}
          formOptions={formOptions}
          isFormLoading={isFormLoading}
          fetchProyectosRelacionables={fetchProyectosRelacionables}
        />
      )}

      {/* --- INICIO DE LA SOLUCIÓN (Paso 4) --- */}
      {isDeleteModalOpen && (
        <DeleteProjectModal
          isOpen={isDeleteModalOpen}
          onClose={closeDeleteModal}
          onConfirm={handleDeleteProyecto}
          project={projectToDelete}
        />
      )}
      {/* --- FIN DE LA SOLUCIÓN (Paso 4) --- */}
    </Layout>
  );
};

