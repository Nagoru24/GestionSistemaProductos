// src/hooks/useAddCollaborators.js
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import {
  getProyectoPorId,
  getColaboradoresPorDepartamento,
  getProyectosPorFuncionario,
  asignarColaboradores,
  getColaboradoresPorProyecto,
  eliminarColaborador,
} from '../services/collaborators.service.js';

export const useAddCollaborators = () => {
  const { idProyecto } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  const queryParams = new URLSearchParams(location.search);
  const fromSource = queryParams.get('from');

  const [proyecto, setProyecto] = useState(null);
  const [usuarios, setUsuarios] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [colaboradoresAsignados, setColaboradoresAsignados] = useState([]);
  const [proyectosPorFuncionario, setProyectosPorFuncionario] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);
  const [justificacion, setJustificacion] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  const fetchColaboradoresAsignados = useCallback(async () => {
    if (!idProyecto) return;
    try {
      const data = await getColaboradoresPorProyecto(idProyecto);
      setColaboradoresAsignados(data);
    } catch (err) {
      toast.error(err.message || 'Error al cargar colaboradores asignados.');
    }
  }, [idProyecto]);

  useEffect(() => {
    const fetchInitialData = async () => {
      setIsLoading(true);
      try {
        const projectData = await getProyectoPorId(idProyecto);
        setProyecto(projectData);

        if (projectData?.codDir && projectData?.codDepto) {
          const userData = await getColaboradoresPorDepartamento(projectData.codDir, projectData.codDepto);
          setUsuarios(userData);
        }
        await fetchColaboradoresAsignados();
      } catch (err) {
        toast.error(err.message || 'Error al cargar los datos del proyecto.');
      } finally {
        setIsLoading(false);
      }
    };
    fetchInitialData();
  }, [idProyecto, fetchColaboradoresAsignados]);

  const handleConfirmModal = async () => {
    handleCloseModal();
    const colaboradoresIds = selectedUsers.map((u) => u.idFuncionario);

    await toast.promise(
      asignarColaboradores(idProyecto, colaboradoresIds),
      {
        loading: 'Asignando colaboradores...',
        success: () => {
          fetchColaboradoresAsignados();
          setSelectedUsers([]);
          
          setTimeout(() => {
            if (fromSource === 'cartera') {
              navigate('/cartera-proyectos');
            } else if (proyecto?.codDir && proyecto?.codDepto) {
              navigate(`/gerencia/${proyecto.codDir}/${proyecto.codDepto}`);
            } else {
              navigate('/pantalla-principal');
            }
          }, 1500);

          return '¡Colaboradores asignados con éxito!';
        },
        error: (err) => err.message || 'Error al asignar colaboradores.'
      }
    );
  };

  const handleConfirmDeleteModal = async () => {
    const isApproved = proyecto?.aprobadoPorDirector === true || proyecto?.aprobadoPorDirector === 1;
    const isReactivate = userToDelete?.estadoRegistro === 2;
    const requiresJustification = isReactivate || isApproved;

    if (requiresJustification && (!justificacion.trim() || justificacion.trim().length < 10)) {
      return toast.error('La justificación es obligatoria y debe tener al menos 10 caracteres.');
    }

    handleCloseDeleteModal();

    await toast.promise(
      eliminarColaborador(idProyecto, userToDelete.idFuncionario, justificacion),
      {
        loading: 'Procesando...',
        // --- INICIO DE LA CORRECCIÓN ---
        success: (result) => { // 'result' es el objeto que devuelve la promesa
            fetchColaboradoresAsignados();
            // Devolvemos solo la propiedad .message del objeto, que es un string
            return result.message || 'Operación completada exitosamente.';
        },
        // --- FIN DE LA CORRECCIÓN ---
        error: (err) => err.message || 'Error al realizar la operación.'
      }
    );
  };

  // --- El resto del hook no necesita cambios ---
  const fetchproyectosPorFuncionario = async (idFuncionario) => {
    if (proyectosPorFuncionario[idFuncionario]) return;
    try {
      const proyectos = await getProyectosPorFuncionario(idFuncionario);
      setProyectosPorFuncionario((prev) => ({ ...prev, [idFuncionario]: proyectos }));
    } catch (err) {
      toast.error(err.message || 'Error al cargar los proyectos del funcionario.');
    }
  };
  const handleOpenModal = () => setIsModalOpen(true);
  const handleCloseModal = () => setIsModalOpen(false);
  const handleOpenDeleteModal = (user) => { setUserToDelete(user); setIsDeleteModalOpen(true); };
  const handleCloseDeleteModal = () => { setUserToDelete(null); setIsDeleteModalOpen(false); setJustificacion(''); };
  const toggleSelect = (user) => { setSelectedUsers((prev) => { const isSelected = prev.some((u) => u.idFuncionario === user.idFuncionario); if (isSelected) { return prev.filter((u) => u.idFuncionario !== user.idFuncionario); } return [...prev, user]; }); };

  return {
    proyecto, usuarios, colaboradoresAsignados, proyectosPorFuncionario, selectedUsers, isLoading, isModalOpen, isDeleteModalOpen, userToDelete, justificacion, setJustificacion, setSelectedUsers, fetchproyectosPorFuncionario, handleOpenModal, handleCloseModal, toggleSelect, handleConfirmModal, handleOpenDeleteModal, handleCloseDeleteModal, handleConfirmDeleteModal,
  };
};
