// src/hooks/useEditProject.js
import { useState, useEffect } from 'react';
import { projectService } from '../services/project.service';
import { getGerencias } from '../services/gerencia.service';

export const useEditProject = (project) => {
  const [formData, setFormData] = useState({});
  const [dropdownOptions, setDropdownOptions] = useState({
    gerencias: [],
    unidadesSolicitantes: [],
    tiposProyecto: [],
    categorias: [],
    prioridades: [],
    relaciones: [],
    relatedProyectosList: [],
  });
  const [relatedProjectGerencia, setRelatedProjectGerencia] = useState(null);
  const [showRelatedProjectSection, setShowRelatedProjectSection] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // EFECTO 1: Carga inicial de datos para los menús desplegables
  useEffect(() => {
    if (!project) return;
    setIsLoading(true);
    const loadDropdownData = async () => {
      try {
        const [formOpts, catOpts, gerenciasOpts] = await Promise.all([
          projectService.fetchFormData(),
          projectService.fetchCategories(project.codDir, project.codDepto),
          getGerencias()
        ]);
        setDropdownOptions({ 
          ...formOpts.data, 
          categorias: catOpts.data.categorias,
          gerencias: gerenciasOpts,
          relatedProyectosList: []
        });
      } catch (error) { 
        console.error("Error al cargar las opciones del formulario:", error); 
      }
    };
    loadDropdownData();
  }, [project]);

  // EFECTO 2: Llenado inicial del formulario con los datos del proyecto
  useEffect(() => {
    if (project && dropdownOptions.unidadesSolicitantes.length > 0) {
      const findValueById = (list, keyField, valueField, id) => list.find(item => item[keyField] === id)?.[valueField] || '';
      
      setFormData({
        descripcion: project.descripcion || '',
        alcance: project.alcance || '',
        idAranda: project.idAranda || '',
        inversion: project.inversion || '',
        fechaInicial: project.fechaInicial ? new Date(project.fechaInicial) : null,
        fechaFinal: project.fechaFinal ? new Date(project.fechaFinal) : null,
        unidadSolicitante: findValueById(dropdownOptions.unidadesSolicitantes, 'COD_DIR', 'DESC_DIR', project.unidadSolicitante),
        tipoProyecto: findValueById(dropdownOptions.tiposProyecto, 'COD_TIPO', 'DESC_TIPO', project.codTipo),
        prioridad: findValueById(dropdownOptions.prioridades, 'COD_PRIORIDAD', 'DESC_PRIORIDAD', project.codPrioridad),
        categoria: findValueById(dropdownOptions.categorias, 'COD_CATEGORIA', 'DESC_CATEGORIA', project.codCategoria),
        relacion: findValueById(dropdownOptions.relaciones, 'COD_RELACION', 'DESC_RELACION', project.codRelacion),
        idProyectoRelacionado: project.idProyectoRelacionado || '',
        tipoRelacion: project.tipoRelacion || '',
      });

      setShowRelatedProjectSection(!!project.idProyectoRelacionado);
      setIsLoading(false);
    }
    // --- ✨ CORRECCIÓN CLAVE: La dependencia ahora es más específica para evitar re-ejecuciones innecesarias ✨ ---
  }, [project, dropdownOptions.unidadesSolicitantes, dropdownOptions.tiposProyecto, dropdownOptions.prioridades, dropdownOptions.categorias, dropdownOptions.relaciones]);
  
  // EFECTO 3: Actualizar dinámicamente las categorías cuando cambia la "Unidad Solicitante"
  useEffect(() => {
    if (!project || !formData.unidadSolicitante || dropdownOptions.unidadesSolicitantes.length === 0) {
      return;
    }

    const selectedUnidad = dropdownOptions.unidadesSolicitantes.find(
      u => u.DESC_DIR === formData.unidadSolicitante
    );

    if (selectedUnidad) {
      if (selectedUnidad.COD_DIR !== project.unidadSolicitante) {
        projectService.fetchCategories(selectedUnidad.COD_DIR, selectedUnidad.COD_DEPTO)
          .then(catOpts => {
            setDropdownOptions(prev => ({
              ...prev,
              categorias: catOpts.data.categorias,
            }));
            setFormData(prev => ({
              ...prev,
              categoria: '',
            }));
          })
          .catch(error => {
            console.error("Error al actualizar las categorías:", error);
            setDropdownOptions(prev => ({ ...prev, categorias: [] }));
            setFormData(prev => ({ ...prev, categoria: '' }));
          });
      }
    }
  }, [formData.unidadSolicitante, dropdownOptions.unidadesSolicitantes, project]);

  // EFECTO 4: Cargar proyectos relacionados
  useEffect(() => {
    if (relatedProjectGerencia) {
      const { COD_DIR, COD_DEPTO } = relatedProjectGerencia;
      projectService.fetchRelatedProjects(COD_DIR, COD_DEPTO).then(response => {
        setDropdownOptions(prev => ({ ...prev, relatedProyectosList: response.data.proyectosRelacionados }));
      });
    } else {
      setDropdownOptions(prev => ({ ...prev, relatedProyectosList: [] }));
    }
  }, [relatedProjectGerencia]);

  // --- Handlers ---
  const handleChange = (e) => setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  const handleDateChange = (name) => (date) => setFormData(prev => ({ ...prev, [name]: date }));
  const handleToggleRelatedSection = (e) => {
    const show = e.target.value === 'Sí';
    setShowRelatedProjectSection(show);
    if (!show) {
      setRelatedProjectGerencia(null);
      setFormData(prev => ({ ...prev, idProyectoRelacionado: '', tipoRelacion: '' }));
    }
  };
  const handleRelatedGerenciaChange = (e) => {
    const selectedDesc = e.target.value;
    const selectedGerencia = dropdownOptions.gerencias.find(g => g.DESC_DEPARTAMENTO === selectedDesc);
    setRelatedProjectGerencia(selectedGerencia);
    setFormData(prev => ({ ...prev, idProyectoRelacionado: '', tipoRelacion: '' }));
  };
  
  return {
    isLoading,
    formData,
    dropdownOptions,
    showRelatedProjectSection,
    relatedProjectGerencia,
    handleChange,
    handleDateChange,
    handleToggleRelatedSection,
    handleRelatedGerenciaChange,
  };
};
