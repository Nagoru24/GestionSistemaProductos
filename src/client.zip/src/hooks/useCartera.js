// src/hooks/useCartera.js
import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from './useAuth';
import { carteraService } from '../services/cartera.service';
import { projectService } from '../services/project.service';
import { getProyectoCompletoPorId } from '../services/gerencia.service';

export const useCartera = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // --- ESTADO PRINCIPAL DE LA PÁGINA ---
  const [cartera, setCartera] = useState(null);
  const [proyectos, setProyectos] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // --- ESTADO PARA LOS MODALES ---
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isApproveModalOpen, setIsApproveModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  
  // --- ESTADO PARA LOS DATOS DE LOS MODALES ---
  const [projectToEdit, setProjectToEdit] = useState(null);
  const [projectToDelete, setProjectToDelete] = useState(null);
  const [selectedProjectDetails, setSelectedProjectDetails] = useState(null);
  const [isDetailsLoading, setIsDetailsLoading] = useState(false);
  
  // --- ESTADO PARA LA EXPANSIÓN DE DETALLES ---
  const [isDetailsExpanded, setIsDetailsExpanded] = useState(false);
  const [isCollabExpanded, setIsCollabExpanded] = useState(false);

  // --- ESTADO PARA OPCIONES DE FORMULARIOS ---
  const [formOptions, setFormOptions] = useState({
    unidadesSolicitantes: [],
    tiposProyecto: [],
    categorias: [],
    prioridades: [],
    gerencias: [],
    relaciones: [],
    proyectosRelacionables: [],
  });
  const [isFormLoading, setIsFormLoading] = useState(true);

  // --- CARGA DE DATOS INICIAL ---
  const fetchCarteraData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await carteraService.getCarteraActiva();
      setCartera(data.cartera);
      setProyectos(data.proyectos || []);
    } catch (err) {
      const errorMessage = err.response?.data?.error || "No se pudo cargar la cartera.";
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user) {
      fetchCarteraData();
    }
  }, [user, fetchCarteraData]);

  // --- INICIO DE LA SOLUCIÓN: Lógica para cargar opciones del formulario ---
  useEffect(() => {
    const loadFormOptions = async () => {
      if (!user) return;
      setIsFormLoading(true);
      try {
        const res = await projectService.fetchFormData();
        const { unidadesSolicitantes, tiposProyecto, prioridades, gerencias, relaciones } = res.data;
        const catRes = await projectService.fetchCategories(user.codDir, user.codDepto);

        setFormOptions(prev => ({
          ...prev,
          unidadesSolicitantes: unidadesSolicitantes || [],
          tiposProyecto: tiposProyecto || [],
          prioridades: prioridades || [],
          gerencias: gerencias || [],
          relaciones: relaciones || [],
          categorias: catRes.data.categorias || [],
        }));
      } catch {
        toast.error("No se pudieron cargar las opciones del formulario.");
      } finally {
        setIsFormLoading(false);
      }
    };
    loadFormOptions();
  }, [user]);

  const fetchProyectosRelacionables = useCallback(async (codDir, codDepto) => {
    if (!codDir || !codDepto) {
      setFormOptions(prev => ({ ...prev, proyectosRelacionables: [] }));
      return [];
    }
    try {
      const proyectos = await carteraService.getProyectosParaRelacionar(codDir, codDepto);
      const proyectosData = proyectos || [];
      setFormOptions(prev => ({ ...prev, proyectosRelacionables: proyectosData }));
      return proyectosData;
    } catch {
      toast.error("No se pudieron cargar los proyectos para relacionar.");
      setFormOptions(prev => ({ ...prev, proyectosRelacionables: [] }));
      return [];
    }
  }, []);
  // --- FIN DE LA SOLUCIÓN ---

  // --- MANEJADORES DE ACCIONES (CRUD) ---
  const handleAddProyecto = useCallback(async (nuevoProyectoData) => {
    await toast.promise(
      carteraService.addProyectoACartera(nuevoProyectoData),
      {
        loading: 'Añadiendo proyecto...',
        success: (proyectoAñadido) => {
          setProyectos(prev => [...prev, proyectoAñadido]);
          setIsAddModalOpen(false);
          return '¡Proyecto añadido a la cartera!';
        },
        error: (err) => err.response?.data?.error || 'No se pudo añadir el proyecto.',
      }
    );
  }, []);

  const handleEditProyecto = useCallback(async (idProyecto, datosEditados) => {
    await toast.promise(
      carteraService.editProyectoInCartera(idProyecto, datosEditados),
      {
        loading: 'Actualizando proyecto...',
        success: (proyectoActualizado) => {
          setProyectos(prev => prev.map(p => p.ID_PROYECTO === idProyecto ? { ...p, ...proyectoActualizado } : p));
          setIsEditModalOpen(false);
          setProjectToEdit(null);
          return '¡Proyecto actualizado con éxito!';
        },
        error: (err) => err.response?.data?.error || 'No se pudo actualizar el proyecto.',
      }
    );
  }, []);

  const handleApproveCartera = useCallback(async () => {
    if (!cartera?.ID_CARTERA) return;
    await toast.promise(
      carteraService.aprobarCartera(cartera.ID_CARTERA),
      {
        loading: 'Aprobando cartera...',
        success: () => {
          navigate(`/gerencia/${user.codDir}/${user.codDepto}`);
          return '¡Cartera aprobada con éxito!';
        },
        error: (err) => err.response?.data?.error || 'No se pudo aprobar la cartera.',
      }
    );
    setIsApproveModalOpen(false);
  }, [cartera, navigate, user]);

  const handleDeleteProyecto = useCallback(async () => {
    if (!projectToDelete) return;
    await toast.promise(
      carteraService.deleteProyectoFromCartera(projectToDelete.ID_PROYECTO),
      {
        loading: 'Eliminando proyecto...',
        success: () => {
          setProyectos(prev => prev.filter(p => p.ID_PROYECTO !== projectToDelete.ID_PROYECTO));
          setIsDeleteModalOpen(false);
          setProjectToDelete(null);
          return '¡Proyecto eliminado con éxito!';
        },
        error: (err) => {
          setIsDeleteModalOpen(false);
          setProjectToDelete(null);
          return err.response?.data?.error || 'No se pudo eliminar el proyecto.';
        }
      }
    );
  }, [projectToDelete]);

  // --- MANEJADORES PARA ABRIR Y CERRAR MODALES ---
  const openAddModal = useCallback(() => setIsAddModalOpen(true), []);
  const closeAddModal = useCallback(() => setIsAddModalOpen(false), []);

  const openEditModal = useCallback((proyecto) => { setProjectToEdit(proyecto); setIsEditModalOpen(true); }, []);
  const closeEditModal = useCallback(() => { setProjectToEdit(null); setIsEditModalOpen(false); }, []);
  
  const openDeleteModal = useCallback((proyecto) => { setProjectToDelete(proyecto); setIsDeleteModalOpen(true); }, []);
  const closeDeleteModal = useCallback(() => { setProjectToDelete(null); setIsDeleteModalOpen(false); }, []);

  const openApproveModal = useCallback(() => setIsApproveModalOpen(true), []);
  const closeApproveModal = useCallback(() => setIsApproveModalOpen(false), []);

  const openDetailsModal = useCallback(async (idProyecto) => {
    setIsDetailsModalOpen(true);
    setIsDetailsLoading(true);
    try {
      const details = await getProyectoCompletoPorId(idProyecto);
      setSelectedProjectDetails(details);
    } catch {
      toast.error("No se pudieron cargar los detalles del proyecto.");
      setIsDetailsModalOpen(false);
    } finally {
      setIsDetailsLoading(false);
    }
  }, []);
  
  const closeDetailsModal = useCallback(() => { setIsDetailsModalOpen(false); setSelectedProjectDetails(null); }, []);

  // --- MANEJADORES DE EXPANSIÓN ---
  const toggleDetailsExpansion = useCallback(() => setIsDetailsExpanded(prev => !prev), []);
  const toggleCollabExpansion = useCallback(() => setIsCollabExpanded(prev => !prev), []);

  return {
    cartera, 
    proyectos, 
    isLoading, 
    error,
    isAddModalOpen, openAddModal, closeAddModal, handleAddProyecto,
    isEditModalOpen, projectToEdit, openEditModal, closeEditModal, handleEditProyecto,
    isApproveModalOpen, openApproveModal, closeApproveModal, handleApproveCartera,
    isDetailsModalOpen, selectedProjectDetails, isDetailsLoading, openDetailsModal, closeDetailsModal,
    isDeleteModalOpen, projectToDelete, openDeleteModal, closeDeleteModal, handleDeleteProyecto,
    isDetailsExpanded, isCollabExpanded, toggleDetailsExpansion, toggleCollabExpansion,
    formOptions, 
    isFormLoading,
    refetch: fetchCarteraData,
    // --- INICIO DE LA SOLUCIÓN: Exportamos la nueva función ---
    fetchProyectosRelacionables,
    // --- FIN DE LA SOLUCIÓN ---
  };
};

