// src/context/AuthProvider.jsx

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";
import toast from 'react-hot-toast'; // 1. IMPORTAMOS TOAST
import { loginService } from "../services/auth.service";
import { AuthContext } from "./AuthContext";

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("token") || null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const storedToken = localStorage.getItem("token");
    if (storedToken) {
      try {
        const decodedUser = jwtDecode(storedToken);
        if (decodedUser.exp * 1000 > Date.now()) {
          setUser(decodedUser);
          setIsAuthenticated(true);
        } else {
          localStorage.removeItem("token");
        }
      } catch (error) {
        console.error("Token inválido:", error);
        localStorage.removeItem("token");
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (credentials) => {
    try {
      const data = await loginService.login(credentials);
      const { token } = data;

      localStorage.setItem("token", token);
      const decodedUser = jwtDecode(token);

      setUser(decodedUser);
      setToken(token);
      setIsAuthenticated(true);

      // 2. MOSTRAMOS EL MENSAJE DE BIENVENIDA
      // Asegúrate de que tu token JWT contenga el campo 'nombre'.
      toast.success(`¡Bienvenido, ${decodedUser.nombre || 'usuario'}!`);

      navigate("/pantalla-principal");
    } catch (error) {
      console.error("Error en el login:", error);
      // 3. MOSTRAMOS EL ERROR CON TOAST
      toast.error(error.message || "Usuario o contraseña incorrectos.");
      // Ya no es necesario lanzar el error, toast lo maneja.
      // throw error; 
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    setIsAuthenticated(false);
    localStorage.removeItem("token");
    
    // 4. MOSTRAMOS EL MENSAJE DE DESPEDIDA
    toast.success('Has cerrado sesión. ¡Vuelve pronto!');
    
    navigate("/login");
  };

  return (
    <AuthContext.Provider
      value={{ user, token, isAuthenticated, isLoading, login, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
};
