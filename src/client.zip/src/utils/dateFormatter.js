/**
 * Formatea una cadena de fecha (YYYY-MM-DD) a un formato localizado DD/MM/YYYY.
 * Esta función trata la fecha como UTC para evitar errores de desfase de zona horaria.
 * @param {string | null | undefined} dateString La fecha en formato ISO 8601 (o similar).
 * @returns {string} La fecha formateada o 'N/A' si la entrada no es válida.
 */
export const formatDate = (dateString) => {
  if (!dateString) return 'N/A';

  const date = new Date(dateString);
  
  // Obtenemos los componentes de la fecha en UTC para evitar el desfase
  const day = String(date.getUTCDate()).padStart(2, '0');
  const month = String(date.getUTCMonth() + 1).padStart(2, '0'); // Los meses son base 0
  const year = date.getUTCFullYear();

  // Verificamos si la fecha es válida
  if (isNaN(year) || isNaN(month) || isNaN(day)) {
    return 'N/A';
  }

  return `${day}/${month}/${year}`;
};
