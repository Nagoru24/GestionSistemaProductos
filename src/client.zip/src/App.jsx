// src/App.jsx

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { LoginPage } from './pages/LoginPage';
import { PantallaPrincipalPage } from './pages/PantallaPrincipalPage';
import { CrearProyectoPage } from './pages/CrearProyectoPage';
import { AñadirColaboradoresPage } from './pages/AñadirColaboradoresPage';
import { GerenciaProjectsViewPage } from './pages/GerenciaProjectsViewPage';
import { CarteraPage } from './pages/CarteraPage';

import { ProtectedRoute } from './components/ProtectedRoute';
import { AuthProvider } from './context/AuthProvider.jsx';

const AuthRedirect = () => {
  const token = localStorage.getItem('token');
  return token ? <Navigate to="/pantalla-principal" replace /> : <LoginPage />;
};

export const App = () => {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<AuthRedirect />} />

          {/* Rutas para todos los usuarios autenticados */}
          <Route element={<ProtectedRoute />}>
            <Route path="/" element={<PantallaPrincipalPage />} />
            <Route path="/pantalla-principal" element={<PantallaPrincipalPage />} />
            <Route path="/gerencia/:codDir/:codDepto" element={<GerenciaProjectsViewPage />}/>
          </Route>

          {/* 💡 ESTA ES LA MODIFICACIÓN CLAVE */}
          {/* Protege las rutas de gestión de proyectos para los roles Gerente y PM. */}
          <Route element={<ProtectedRoute allowedRoles={['PM', 'Gerente']} />}>
            {/* Se añade la restricción de roles a la ruta de crear proyectos */}
            <Route path="/crear-proyecto" element={<CrearProyectoPage />} />
            {/* Se añade la restricción de roles a la ruta de añadir colaboradores */}
            <Route path="/añadir-colaboradores/:idProyecto" element={<AñadirColaboradoresPage />} />
            {/* Se añade la restricción de roles a la ruta de cartera de proyectos */}
            <Route path="/cartera-proyectos" element={ <CarteraPage/>}/> 
          </Route>     

          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </AuthProvider>
    </Router>
  );
};