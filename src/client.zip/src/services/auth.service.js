// src/services/auth.service.js
import { api } from '../utils/api';

export const loginService = {
  login: async (credentials) => {
    try {
      const response = await api.post('/auth/login', credentials);
      return response.data;
    } catch (error) {
      throw new Error(error.response?.data?.error || 'Error en el inicio de sesión');
    }
  },
};