// src/services/cartera.service.js
import { api } from "../utils/api";

/**
 * Objeto que encapsula todos los servicios relacionados con la Cartera de Proyectos.
 */
export const carteraService = {
  /**
   * Obtiene la cartera activa del gerente para el periodo actual.
   * Si no existe, el backend la crea automáticamente.
   * @returns {Promise<object>} La respuesta de la API con { cartera, proyectos }.
   */
  getCarteraActiva: async () => {
    const response = await api.get('/api/cartera');
    return response.data;
  },

  /**
   * Añade un nuevo proyecto a una cartera existente.
   * @param {object} proyectoData - Los datos del nuevo proyecto a añadir.
   * @returns {Promise<object>} El nuevo proyecto que fue añadido a la cartera.
   */
  addProyectoACartera: async (proyectoData) => {
    const response = await api.post('/api/cartera/proyecto', proyectoData);
    return response.data;
  },

  /**
   * Edita un proyecto existente dentro de una cartera.
   * @param {number} idProyecto - El ID del proyecto a editar.
   * @param {object} proyectoData - Los nuevos datos del proyecto.
   * @returns {Promise<object>} El proyecto con la información actualizada.
   */
  editProyectoInCartera: async (idProyecto, proyectoData) => {
    const response = await api.put(`/api/cartera/proyecto/${idProyecto}`, proyectoData);
    return response.data;
  },

  /**
   * Aprueba una cartera completa, pasando todos sus proyectos a "En Proceso".
   * @param {number} idCartera - El ID de la cartera a aprobar.
   * @returns {Promise<object>} Un mensaje de confirmación del backend.
   */
  aprobarCartera: async (idCartera) => {
    const response = await api.put(`/api/cartera/${idCartera}/aprobar`);
    return response.data;
  },

  /**
   * Obtiene la lista de proyectos de una gerencia que pueden ser relacionados.
   * @param {number} codDir - El código de la dirección de la gerencia.
   * @param {number} codDepto - El código del departamento de la gerencia.
   * @returns {Promise<Array>} Una lista de proyectos con ID y descripción.
   */
  getProyectosParaRelacionar: async (codDir, codDepto) => {
    const response = await api.get(`/api/proyectos-relacionables/${codDir}/${codDepto}`);
    return response.data;
  },

  getProyectoCarteraById : async (idProyecto) => {
    const response = await api.get(`/api/cartera/proyecto/${idProyecto}`);
    return response.data;
  },

  /**
   * Elimina un proyecto de una cartera en estado "Por Aprobar".
   * @param {number} idProyecto - El ID del proyecto que se va a eliminar.
   * @returns {Promise<object>} Un mensaje de confirmación del backend.
   */
  deleteProyectoFromCartera: async (idProyecto) => {
    const response = await api.delete(`/api/cartera/proyecto/${idProyecto}`);
    return response.data;
  },


};


