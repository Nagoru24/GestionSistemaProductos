// src/services/project.service.js
import { api } from "../utils/api";

// Todas las funciones están dentro de este único objeto exportado
export const projectService = {
  fetchFormData: async () => {
    return await api.get('/proyectos/formulario-data');
  },
  
  fetchCategories: async (codDir, codDepto) => {
    return await api.get(`/proyectos/departamento-data/${codDir}/${codDepto}`);
  },
  
  fetchRelatedProjects: async (codDir, codDepto) => {
    return await api.get(`/proyectos/departamento-data/${codDir}/${codDepto}`);
  },
  
  createProject: async (payload) => {
    const response = await api.post("/proyectos/crear", payload);
    
    if (!response.data?.ID_PROYECTO_OUT) {
      console.error('Response received:', response.data);
      throw new Error('No project ID returned from server');
    }
    return response;
  },

  // --- FUNCIÓN NUEVA AÑADIDA AQUÍ ---
  // La añadimos como una propiedad más del objeto projectService.
  getGerencias: async () => {
    // Usamos la ruta que definimos en el backend, ej: /gerencias
    const response = await api.get('/gerencias'); 
    return response.data; // Devolvemos solo los datos de la respuesta
  }
};