// src/services/gerencia.service.js
import { api } from "../utils/api";

// Cada función se exporta directamente para mantener el estilo modular.

export const getGerencias = async () => {
  const response = await api.get('/departamentos');
  return response.data;
};

export const getProyectosPorGerencia = async ({ codDir, codDepto }) => {
  const response = await api.get(`/gerencias/${codDir}/${codDepto}/proyectos`);
  return response.data;
};

export const getProyectoCompletoPorId = async (idProyecto) => {
  const response = await api.get(`/proyectos/${idProyecto}/detalles`);
  return response.data;
};

export const aprobarProyecto = async (idProyecto, data) => {
  const response = await api.patch(`/proyectos/${idProyecto}/aprobar`, data);
  return response.data;
};

export const pausarProyecto = async (idProyecto, data) => {
  const response = await api.patch(`/proyectos/${idProyecto}/pausar`, data);
  return response.data;
};

export const reactivarProyecto = async (idProyecto) => {
  const response = await api.patch(`/proyectos/${idProyecto}/reactivar`);
  return response.data;
};

export const completarProyecto = async (idProyecto) => {
  const response = await api.patch(`/proyectos/${idProyecto}/completar`);
  return response.data;
};

export const eliminarProyecto = async (idProyecto) => {
  const response = await api.delete(`/proyectos/${idProyecto}/eliminar`);
  return response.data;
};

export const editarProyectoPlanificado = async (idProyecto, data) => {
  const response = await api.patch(`/proyectos/${idProyecto}/planificacion`, data);
  return response.data;
};