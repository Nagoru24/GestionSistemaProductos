// src/components/ProjectCard.jsx
import React from 'react';
import { useAuth } from '../hooks/useAuth';
import {
  Play,
  Pause,
  CheckCircle,
  Edit,
  Eye,
  ThumbsUp,
  Trash2,
  UserPlus,
} from 'lucide-react';

export const ProjectCard = ({ project, onOpenModal, onOpenDetailsModal, onNavigate, onOpenDeleteModal, onOpenEditModal }) => {
  const { user } = useAuth();

  const handleActionClick = (e, handlerFn) => {
    e.stopPropagation();
    handlerFn();
  };

  const renderActions = () => {
    if (!onOpenModal) return null;
    if (user.rol === 'Colaborador') {
      return (
        <button onClick={(e) => handleActionClick(e, () => onOpenDetailsModal(project.ID_PROYECTO))} className="p-2 text-slate-500 hover:bg-slate-200 rounded-full" title="Ver Detalles">
          <Eye size={18} />
        </button>
      );
    }
    let actions = [];
    const inactivarAction = { icon: <Trash2 size={18} />, title: "Inactivar", color: "text-red-600 hover:bg-red-100", action: () => onOpenDeleteModal(project, 'inactivar') };
    switch (project.COD_ESTATUS) {
      case 2:
        actions = [
          { icon: <ThumbsUp size={18} />, title: "Aprobar", color: "text-green-600 hover:bg-green-100", action: () => onOpenModal(project, 'aprobar') },
          { icon: <Edit size={18} />, title: "Editar", color: "text-blue-600 hover:bg-blue-100", action: () => onOpenEditModal(project, 'editar') },
          { icon: <Trash2 size={18} />, title: "Eliminar", color: "text-red-600 hover:bg-red-100", action: () => onOpenDeleteModal(project, 'eliminar') },
          { icon: <UserPlus size={18} />, title: "Añadir Colaboradores", color: "text-indigo-600 hover:bg-indigo-100", action: () => onNavigate(project.ID_PROYECTO) },
        ];
        break;
      case 3:
      case 4:
        actions = [
          { icon: <Pause size={18} />, title: "Pausar", color: "text-yellow-600 hover:bg-yellow-100", action: () => onOpenModal(project, 'pausar') },
          { icon: <CheckCircle size={18} />, title: "Completar", color: "text-green-600 hover:bg-green-100", action: () => onOpenModal(project, 'completar') },
          { icon: <Edit size={18} />, title: "Editar Avance", color: "text-blue-600 hover:bg-blue-100", action: () => onOpenEditModal(project, 'editar') },
        ];
        break;
      case 5:
        actions = [ { icon: <Play size={18} />, title: "Reactivar", color: "text-blue-600 hover:bg-blue-100", action: () => onOpenModal(project, 'reactivar') }, inactivarAction ];
        break;
      case 1:
        actions = [ inactivarAction ];
        break;
      default:
        actions = [];
        break;
    }
    return actions.map(btn => (
      <button key={btn.title} onClick={(e) => handleActionClick(e, btn.action)} className={`p-2 rounded-full ${btn.color}`} title={btn.title}>
        {btn.icon}
      </button>
    ));
  };


  return (
    <div 
      className="bg-white rounded-lg shadow p-4 border-l-4 border-azul transition-shadow hover:shadow-md cursor-pointer"
      onClick={() => onOpenDetailsModal(project.ID_PROYECTO)}
    >
      <div className="flex justify-between items-start">
        <h3 className="font-bold text-slate-800 text-base mb-2 break-words pr-2">{project.DESC_PROYECTO}</h3>
        <div className="flex items-center space-x-1 shrink-0">{renderActions()}</div>
      </div>
      <p className="text-sm text-slate-600 line-clamp-2 mb-4">{project.ALCANCE_PROYECTO || 'Sin alcance definido.'}</p>
      {project.COD_ESTATUS !== 2 && (
        <div className="space-y-2 mb-3">
          <div>
            <div className="flex justify-between text-xs text-slate-500 mb-1"><span>Alcanzado</span><span>{project.AVANCE_ALCANZADO || 0}%</span></div>
            <div className="w-full bg-slate-200 rounded-full h-2"><div className="bg-blue-600 h-2 rounded-full" style={{ width: `${project.AVANCE_ALCANZADO || 0}%` }}></div></div>
          </div>
          <div>
            <div className="flex justify-between text-xs text-slate-500 mb-1"><span>Esperado</span><span>{project.AVANCE_ESPERADO || 0}%</span></div>
            <div className="w-full bg-slate-200 rounded-full h-2"><div className="bg-slate-400 h-2 rounded-full" style={{ width: `${project.AVANCE_ESPERADO || 0}%` }}></div></div>
          </div>
        </div>
      )}
      
      <div className="border-t pt-3 flex justify-between items-center text-sm text-slate-500">
        <span><strong className="text-slate-700">{project.NUM_COLABORADORES || 0}</strong> Colaboradores</span>
        
        {project.FECHA_FINAL_PLANIFICADA && (
          <span>
            Entrega: <strong>{new Date(project.FECHA_FINAL_PLANIFICADA).toLocaleDateString('es-PA', { timeZone: 'UTC' })}</strong>
          </span>
        )}
      </div>
    </div>
  );
};
