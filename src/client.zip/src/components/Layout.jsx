// src/components/Layout.jsx

import React, { useState, useEffect } from 'react';
import { useMediaQuery } from 'react-responsive';
import { SidebarContainer } from './SidebarContainer';
import { HeaderContainer } from './HeaderContainer';
import { useAuth } from '../hooks/useAuth.js';
import { Notifications } from './ui/Notifications'; // <-- AÑADE ESTA LÍNEA

// --- NUEVO: FUNCIÓN PARA LEER EL ESTADO INICIAL ---
// Esta función se ejecuta solo una vez al cargar el componente.
const getInitialSidebarState = () => {
  try {
    const savedState = window.localStorage.getItem('sidebarCollapsed');
    // Si hay un valor guardado en localStorage, lo usamos.
    if (savedState !== null) {
      return JSON.parse(savedState); // Convertimos el string de vuelta a booleano
    }
  } catch (error) {
    console.error("No se pudo leer el estado del sidebar desde localStorage", error);
  }
  // Si no hay nada guardado, decidimos en base al tamaño de la pantalla.
  return window.innerWidth <= 1024;
};


export const Layout = ({ children, title }) => {
  const { user, logout } = useAuth();

  // El estado ahora se inicializa con la función que lee desde localStorage.
  const [isCollapsed, setIsCollapsed] = useState(getInitialSidebarState);
  
  const isSmallScreen = useMediaQuery({ query: '(max-width: 1024px)' });

  // --- NUEVO: EFECTO PARA GUARDAR EL ESTADO ---
  // Este useEffect se ejecuta cada vez que el valor de 'isCollapsed' cambia.
  useEffect(() => {
    try {
      window.localStorage.setItem('sidebarCollapsed', JSON.stringify(isCollapsed));
    } catch (error) {
      console.error("No se pudo guardar el estado del sidebar en localStorage", error);
    }
  }, [isCollapsed]);

  // Este efecto sigue siendo útil para forzar el colapso si el usuario redimensiona la ventana.
  useEffect(() => {
    if (isSmallScreen) {
      setIsCollapsed(true);
    }
  }, [isSmallScreen]);

  return (
    <div className="min-h-screen bg-fondo-pagina">
       <Notifications />
       
      <SidebarContainer 
        isCollapsed={isCollapsed}
        setIsCollapsed={setIsCollapsed}
      />

      <div className={`
        relative transition-[margin-left] duration-300 ease-in-out
        ${isCollapsed ? 'ml-20' : 'ml-[260px]'}
      `}>
        <HeaderContainer
          isSidebarCollapsed={isCollapsed}
          title={title}
          userName={user?.usuario || 'Cargando...'}
          userRole={user?.rol || ''}
          onLogout={logout}
        />
        
        <main className="pt-19 p-5">
          {children}
        </main>
      </div>
    </div>
  );
};
