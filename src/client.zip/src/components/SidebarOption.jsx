// src/components/SidebarOption.jsx

import { NavLink } from 'react-router-dom';

// FIX: Se añade la prop 'onNavigate'
export const SidebarOption = ({ Icon, description, to, isCollapsed, onNavigate }) => {

  const getLinkClasses = ({ isActive }) => {
    const baseClasses = `
      flex items-center rounded-lg
      text-base font-medium text-white/80
      transition-colors duration-50
      select-none overflow-hidden
      hover:bg-white/10 hover:text-white
    `;
    
    const layoutClasses = isCollapsed
      ? 'w-full h-14 justify-center' 
      : 'px-4 py-4';

    const activeClasses = 'bg-white/10 text-white';

    return isActive 
      ? `${baseClasses} ${layoutClasses} ${activeClasses}`
      : `${baseClasses} ${layoutClasses}`;
  };

  return (
    <NavLink to={to} className={getLinkClasses} title={isCollapsed ? description : undefined} onClick={onNavigate}>
      {Icon && <Icon className="w-6 h-6 flex-shrink-0" />}
      
      <span className={`
        whitespace-nowrap 
        transition-[width,opacity,margin-left] duration-300 ease-in-out
        ${isCollapsed ? 'w-0 opacity-0 ml-0' : 'w-auto opacity-100 ml-4'}
      `}>
        {description}
      </span>
    </NavLink>
  );
};
