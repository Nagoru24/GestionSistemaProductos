import React from 'react';
import { Edit3, X } from 'lucide-react';

/**
 * Un contenedor que muestra un valor estático o un campo de formulario editable.
 */
export const EditableField = ({ label, isEditing, onEdit, children, displayValue, className = '' }) => {
  return (
    <div className={`group relative border border-slate-200 rounded-lg p-3 transition-colors hover:bg-slate-50 ${isEditing ? 'bg-slate-50 ring-2 ring-indigo-200' : ''} ${className}`}>
      <div className="flex items-start justify-between">
        <div className="w-full pr-8">
          <label className="block text-xs font-semibold text-slate-500 mb-1 uppercase tracking-wider">
            {label}
          </label>
          {isEditing ? (
            <div className="mt-2">
              {children}
            </div>
          ) : (
            <p className="text-sm text-slate-800 break-words min-h-[38px] flex items-center">
              {displayValue || <span className="text-slate-400">No especificado</span>}
            </p>
          )}
        </div>
        <button
          type="button"
          onClick={onEdit}
          className="absolute top-3 right-3 p-2 text-slate-400 hover:text-azul hover:bg-slate-200 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          aria-label={`Editar ${label}`}
        >
          {isEditing ? <X size={16} /> : <Edit3 size={16} />}
        </button>
      </div>
    </div>
  );
};

