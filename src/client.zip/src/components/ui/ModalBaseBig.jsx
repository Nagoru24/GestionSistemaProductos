import React from 'react';
import { X } from 'lucide-react';

export const ModalBaseBig = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) {
    return null;
  }

  const handleModalContentClick = (e) => {
    e.stopPropagation();
  };

  return (
    <div
      className="fixed inset-0 backdrop-blur-sm flex items-center justify-center z-50 select-none p-4"
    >
      {/* Contenedor del modal rediseñado: más grande y responsivo */}
      <div
        className="bg-white rounded-xl shadow-2xl w-11/12 max-w-7xl flex flex-col max-h-[90vh]"
        onClick={handleModalContentClick}
      >
        {/* Cabecera del Modal */}
        <div className="flex justify-between items-center p-6 border-b border-slate-200 flex-shrink-0">
          <h2 className="text-2xl font-bold text-azul">{title || ''}</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-500 hover:bg-slate-200 hover:text-azul transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            aria-label="Cerrar modal"
          >
            <X size={23} />
          </button>
        </div>
        
        {/* El contenido ahora se renderiza directamente, el formulario manejará el scroll */}
        {children}

      </div>
    </div>
  );
};

