import React from 'react';
import { X } from 'lucide-react';

export const ModalBaseDetails = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) {
    return null;
  }

  // Previene que el clic dentro del modal lo cierre.
  const handleModalContentClick = (e) => {
    e.stopPropagation();
  };

  return (
    // Fondo oscuro semi-transparente con efecto blur
    <div
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <div
        className="bg-gray-50 rounded-xl shadow-2xl w-full max-w-6xl flex flex-col max-h-[90vh]"
        onClick={handleModalContentClick}
      >
        {/* Encabezado del Modal */}
        <header className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-800">{title || 'Detalles'}</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-gray-500 hover:bg-gray-200 hover:text-gray-900 transition-colors"
            aria-label="Cerrar modal"
          >
            <X size={24} />
          </button>
        </header>
        
        {/* Contenido principal con scroll */}
        <main className="overflow-y-auto custom-scrollbar">
          {children}
        </main>
      </div>
    </div>
  );
};