// src/components/ui/SelectField.jsx
import { Info } from 'lucide-react';

// Añadimos 'useKeyAsValue' a la lista de props de TU componente original.
export const SelectField = ({ label, name, value, onChange, options, error, required, disabled, useKeyAsValue = false }) => (
  <div>
    <label htmlFor={name} className="block text-sm font-medium text-slate-600 mb-1">
      {label} {required && <span className="text-red-500">*</span>}
    </label>
    <select
      id={name}
      name={name}
      value={value}
      onChange={onChange}
      disabled={disabled}
      // Se utiliza tu cadena de clases original para que el diseño sea el correcto.
      className={`
        block w-full px-3 py-2 bg-white border 
        ${error ? 'border-red-500' : 'border-slate-300'} 
        rounded-md text-sm shadow-sm placeholder-slate-400
        focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500
        transition duration-200
        disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed
      `}
    >
      <option value="" disabled>Seleccione una opción</option>
      {options.map((option) => (
        // Esta es la única lógica nueva: si useKeyAsValue es true, el valor del <option> será la key (el ID).
        <option key={option.key} value={useKeyAsValue ? option.key : option.value}>
          {option.value}
        </option>
      ))}
    </select>
    {error && <p className="mt-1 text-xs text-red-600 flex items-center"><Info size={14} className="mr-1"/>{error}</p>}
  </div>
);