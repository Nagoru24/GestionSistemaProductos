import React from "react";

export const Modal = ({
  isOpen,
  onClose,
  onConfirm,
  onConfirmAndAddCollaborators,
  formData,
  showRelatedProjectSection,
  relatedProjectGerencia,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white p-8 rounded-xl shadow-2xl w-[70vw] max-w-5xl">
        <h2 className="text-2xl font-semibold text-azul mb-4 text-center">
          Confirmar Creación de Proyecto
        </h2>
        <p className="mb-6 text-azul">
          ¿Está seguro de crear el siguiente proyecto?
        </p>
        <div className="grid grid-cols-2 gap-x-4 gap-y-4 text-azul">
          <p>
            <strong>Gerencia:</strong> {formData.gerencia?.DESC_DEPARTAMENTO || ""}
          </p>
          <p>
            <strong>Unidad Solicitante:</strong> {formData.unidadSolicitante?.DESC_DIR || ""}
          </p>
          <p>
            <strong>ID Aranda:</strong> {formData.idAranda || ""}
          </p>
          <p>
            <strong>Tipo de Proyecto:</strong> {formData.tipoProyecto || ""}
          </p>
          <p>
            <strong>Categoría:</strong> {formData.categoria || ""}
          </p>
          <p>
            <strong>Relación:</strong> {formData.relacion || ""}
          </p>
          {showRelatedProjectSection && (
            <>
              <p>
                <strong>Gerencia Relacionada:</strong> {relatedProjectGerencia?.DESC_DEPARTAMENTO || ""}
              </p>
              <p>
                <strong>Proyecto Relacionado:</strong> {formData.relacionOtroProyecto || ""}
              </p>
              <p>
                <strong>Tipo de Relación:</strong> {formData.tipoRelacion || ""}
              </p>
            </>
          )}
          <p>
            <strong>Descripción:</strong> {formData.descripcion || ""}
          </p>
          <p>
            <strong>Alcance:</strong> {formData.alcance || ""}
          </p>
          <p>
            <strong>Prioridad:</strong> {formData.prioridad || ""}
          </p>
          <p>
            <strong>Monto de Inversión: $</strong> {formData.inversion || ""}
          </p>
          <p>
            <strong>Fecha Inicial:</strong>{" "}
            {formData.fechaInicial
              ? formData.fechaInicial.toLocaleDateString()
              : "No especificada"}
          </p>
          <p>
            <strong>Fecha Final:</strong>{" "}
            {formData.fechaFinal
              ? formData.fechaFinal.toLocaleDateString()
              : "No especificada"}
          </p>
        </div>
        <div className="flex justify-end mt-8 space-x-5">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-[#A1A5A6] text-white rounded hover:bg-[#8E9293] transition-colors cursor-pointer"
          >
            Cancelar
          </button>
          <button
            onClick={onConfirm}
            className="px-6 py-2 bg-azul text-white rounded hover:bg-indigo-950 transition-colors cursor-pointer "
          >
            Crear
          </button>
          <button
            onClick={onConfirmAndAddCollaborators}
            className="px-6 py-2 bg-azul text-white rounded hover:bg-indigo-950 transition-colors cursor-pointer"
          >
            Crear y Añadir Colaboradores
          </button>
        </div>
      </div>
    </div>
  );
};