import React from 'react';
import DatePicker from 'react-datepicker';
import { Calendar, Info } from 'lucide-react';
import 'react-datepicker/dist/react-datepicker.css';

/**
 * Componente de campo de selección de fecha.
 *
 * @param {string} label - El texto de la etiqueta del campo.
 * @param {Date} value - El valor de la fecha actual (se espera un objeto Date en UTC).
 * @param {function} onChange - La función que se llama al cambiar la fecha.
 * @param {string} error - Mensaje de error a mostrar.
 * @param {boolean} required - Indica si el campo es obligatorio.
 */
export const DatePickerField = ({ label, value, onChange, error, required }) => {
  
  // --- CORRECCIÓN DE ZONA HORARIA ---
  // react-datepicker interpreta las fechas en la zona horaria local del navegador.
  // Nuestro estado maneja fechas en UTC (ej. 2025-09-01T00:00:00.000Z).
  // Para un usuario en Panamá (UTC-5), esto se interpreta como el día anterior (31/08/2025).
  // Esta función crea una nueva fecha en la zona horaria local del usuario,
  // pero usando los componentes (día, mes, año) de la fecha UTC.
  // Esto neutraliza el efecto de la zona horaria para que el DatePicker muestre el día correcto.
  const getLocalDateForPicker = (utcDate) => {
    if (!utcDate) return null;
    return new Date(utcDate.getUTCFullYear(), utcDate.getUTCMonth(), utcDate.getUTCDate());
  };
  // --- FIN DE LA CORRECCIÓN ---

  return (
    <div>
      <label className="block text-sm font-medium text-slate-600 mb-1">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <div className="relative">
        <DatePicker
          selected={getLocalDateForPicker(value)} // Usamos la fecha ajustada
          onChange={onChange}
          dateFormat="dd/MM/yyyy"
          className={`
            block w-full pl-10 pr-3 py-2 bg-white border 
            ${error ? 'border-red-500' : 'border-slate-300'} 
            rounded-md text-sm shadow-sm
            focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500
            transition duration-200 cursor-pointer
          `}
          placeholderText="Seleccione una fecha"
        />
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Calendar className="h-5 w-5 text-slate-400" />
        </div>
      </div>
      {error && <p className="mt-1 text-xs text-red-600 flex items-center"><Info size={14} className="mr-1"/>{error}</p>}
    </div>
  );
};

