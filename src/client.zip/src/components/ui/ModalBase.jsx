import React from 'react';
import { X } from 'lucide-react'; // Usaremos un ícono para el botón de cerrar

/**
 * Componente base reutilizable para todos los modales de la aplicación.
 * Proporciona el contenedor, el fondo y la lógica de cierre.
 *
 * @param {boolean} isOpen - Controla si el modal está visible.
 * @param {function} onClose - Función que se llama para cerrar el modal.
 * @param {string} [title] - Título opcional que se muestra en la cabecera del modal.
 * @param {React.ReactNode} children - El contenido específico del modal.
 */
export const ModalBase = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) {
    return null;
  }

  // Detiene la propagación para que al hacer clic dentro del modal no se cierre.
  const handleModalContentClick = (e) => {
    e.stopPropagation();
  };

  return (
    // Contenedor principal con el fondo y el efecto de desenfoque.
    // Se ha eliminado el evento onClick para evitar que se cierre desde aquí.
    <div
      className="fixed inset-0 backdrop-blur-sm flex items-center justify-center z-50 p-4 select-none"
    >
      {/* El panel del modal con el estilo que elegiste. */}
      <div
        className="bg-white p-8 rounded-xl shadow-2xl w-[70vw] max-w-5xl relative "
        onClick={handleModalContentClick}
      >
        {/* Cabecera opcional con título y botón de cierre */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-azul">{title || ''}</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-500 hover:bg-slate-200 hover:text-azul transition-colors cursor-pointer"
            aria-label="Cerrar modal"
          >
            <X size={24} />
          </button>
        </div>

        {/* Aquí se renderizará el contenido específico de cada modal */}
        <div>
          {children}
        </div>
      </div>
    </div>
  );
};