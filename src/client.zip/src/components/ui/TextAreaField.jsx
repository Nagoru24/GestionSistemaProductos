import { Info } from 'lucide-react';

/**
 * Componente de campo de texto de área (textarea).
 *
 * @param {string} label - El texto de la etiqueta del campo.
 * @param {string} name - El nombre del campo (para el HTML 'name' y 'id').
 * @param {string} value - El valor actual del campo.
 * @param {function} onChange - La función que se llama al cambiar el valor.
 * @param {number} maxLength - El número máximo de caracteres permitidos.
 * @param {string} error - Mensaje de error a mostrar.
 * @param {boolean} required - Indica si el campo es obligatorio.
 */

export const TextAreaField = ({ label, name, value = '', onChange, maxLength, error, required, className }) => {
  const currentLength = typeof value === 'string' ? value.length : 0;

  return (
    <div className={className}>
      <label htmlFor={name} className="block text-sm font-medium text-slate-600 mb-1">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <textarea
        id={name}
        name={name}
        value={value}
        onChange={onChange}
        maxLength={maxLength}
        rows={4}
        className={`
          block w-full px-3 py-2 bg-white border 
          ${error ? 'border-red-500' : 'border-slate-300'} 
          rounded-md text-sm shadow-sm placeholder-slate-400
          focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500
          transition duration-200
        `}
      />
      <div className="flex justify-between items-center mt-1">
        {error ? (
          <p className="text-xs text-red-600 flex items-center"><Info size={14} className="mr-1"/>{error}</p>
        ) : (
          <span />
        )}
        {maxLength && (
          <p className="text-xs text-slate-500">
            {currentLength} / {maxLength}
          </p>
        )}
      </div>
    </div>
  );
};
