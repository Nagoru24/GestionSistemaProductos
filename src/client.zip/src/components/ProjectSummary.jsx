import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Users } from 'lucide-react';
import { Collapsible } from './ui/Collapsible';
// --- INICIO DE LA CORRECCIÓN ---
// 1. Se importa la función de formato de fecha centralizada.
import { formatDate } from '../utils/dateFormatter';
// --- FIN DE LA CORRECCIÓN ---

export const ProjectSummary = ({ project, colaboradoresAsignados, handleOpenDeleteModal }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isColaboradoresOpen, setIsColaboradoresOpen] = useState(false);

  // 2. Se elimina la función local 'formatDate' que causaba el error.

  const isApproved = project?.aprobadoPorDirector === true || project?.aprobadoPorDirector === 1;

  return (
    <div className="p-8 bg-slate-50 rounded-xl shadow-lg select-none">
      {/* Sección Superior del Resumen */}
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <h2 className="text-xl font-bold text-azul mb-1">
            {project?.descripcion || 'Implementación de Nuevo Proyecto'}
          </h2>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsColaboradoresOpen(!isColaboradoresOpen)}
            className="cursor-pointer flex items-center justify-center p-2 rounded-full bg-blue-100 text-azul hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors duration-200"
            title={isColaboradoresOpen ? 'Ocultar colaboradores' : 'Ver colaboradores asignados'}
          >
            <Users className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="cursor-pointer flex items-center justify-center p-2 rounded-full bg-blue-100 text-azul hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors duration-200"
            aria-expanded={isExpanded}
            aria-controls={`project-details-${project?.idAranda || 'unique'}`}
            title={isExpanded ? 'Ocultar detalles' : 'Expandir detalles'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Información Clave del Proyecto */}
      <div className="flex flex-wrap items-center gap-x-6 text-sm text-azul mt-4 pt-4 border-t border-gray-200">
        <p><strong>Gerencia:</strong> {project?.gerencia || 'Sin gerencia'}</p>
        <p>
          {/* 3. Ahora estas llamadas usan la función correcta y mostrarán la fecha sin desfase. */}
          <strong>Fechas Planificadas:</strong> {formatDate(project?.fechaInicial)} - {formatDate(project?.fechaFinal)}
        </p>
        <p>
          <strong>Fechas Reales:</strong> {formatDate(project?.fechaInicialReal)} - {formatDate(project?.fechaFinalReal)}
        </p>
        <p>
          <strong>Prioridad:</strong>
          {project?.prioridad ? (
            <span
              className={`ml-1 px-2 py-0.5 text-white text-xs font-semibold rounded-full`}
              style={{
                backgroundColor:
                  project.prioridad === 'Alta' ? '#FF0000' :
                  project.prioridad === 'Media' ? '#E8E200' :
                  project.prioridad === 'Baja' ? '#04CE03' : '#D1D5DB',
              }}
            >
              {project.prioridad}
            </span>
          ) : (
            <span className="ml-1 text-gray-700">Sin prioridad</span>
          )}
        </p>
        <p>
          <strong>Estado de Aprobación:</strong>
          {project?.aprobadoPorDirector !== undefined ? (
            <span
              className={`ml-1 px-2 py-0.5 text-white text-xs font-semibold rounded-full`}
              style={{
                backgroundColor: isApproved ? '#04CE03' : '#FF0000',
              }}
            >
              {isApproved ? 'Aprobado' : 'No Aprobado'}
            </span>
          ) : (
            <span className="ml-1 text-gray-700">Sin estado</span>
          )}
        </p>
        <p>
          <strong>Inversión: $</strong>{project?.inversion || 'Sin inversión'}
        </p>
      </div>

      {/* Colaboradores Asignados */}
      <Collapsible isOpen={isColaboradoresOpen}>
        <div className="mt-6 pt-6 border-t border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Colaboradores Asignados</h3>
          {colaboradoresAsignados.length === 0 ? (
            <p className="text-sm text-gray-700">No hay colaboradores asignados.</p>
          ) : (
            <ul className="space-y-2 text-sm text-gray-700">
              {colaboradoresAsignados.map((colaborador) => (
                <li
                  key={colaborador.idFuncionario}
                  className={`flex items-center justify-between bg-white border border-gray-200 rounded-lg p-2 ${
                    colaborador.estadoRegistro === 'I' || colaborador.estadoRegistro === 2 ? 'opacity-50 line-through' : ''
                  }`}
                  title={colaborador.estadoRegistro === 'I' || colaborador.estadoRegistro === 2 ? colaborador.justificacion || 'Sin justificación' : ''}
                >
                  <span>{colaborador.nombreCompleto} ({colaborador.rol})</span>

                  {(colaborador.estadoRegistro === 'A' || colaborador.estadoRegistro === 1) && (
                      <button
                      onClick={() => handleOpenDeleteModal(colaborador)}
                      className="p-1 text-red-600 hover:text-red-800 focus:outline-none cursor-pointer"
                      title={
                        isApproved
                          ? 'Inactivar (requiere justificación)'
                          : 'Eliminar'
                      }
                    >
                      {isApproved ? 'Inactivar' : 'Eliminar'}
                    </button>
                  )}


                  {(colaborador.estadoRegistro === 'I' || colaborador.estadoRegistro === 2) && (
                    <button
                      onClick={() => handleOpenDeleteModal(colaborador)}
                      className="p-1 text-blue-600 hover:text-blue-800 cursor-pointer"
                      title="Reactivar (requiere justificación)"
                    >
                      <span className='font-semibold'>Reactivar</span>
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      </Collapsible>

      {/* Detalles Expandibles */}
      <Collapsible isOpen={isExpanded}>
        <div
          id={`project-details-${project?.idAranda || 'unique'}`}
          className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6 pt-6 border-t border-gray-200"
        >
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Detalles del Proyecto</h3>
            <div className="space-y-2 text-sm text-gray-700">
              <p><strong>Unidad Solicitante:</strong> {project?.unidadSolicitante || 'No especificada'}</p>
              <p><strong>ID Aranda:</strong> {project?.idAranda || 'No especificado'}</p>
              <p><strong>Tipo de Proyecto:</strong> {project?.tipoProyecto || 'No especificado'}</p>
              <p><strong>Categoría:</strong> {project?.categoria || 'No especificada'}</p>
              <p><strong>Relación:</strong> {project?.relacion || 'No especificada'}</p>
              {project?.relacionOtroProyecto && (
                <p>
                  <strong>Relacionado con:</strong> {project.relacionOtroProyecto} ({project.tipoRelacion || 'Sin tipo'})
                </p>
              )}
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-3">Descripción y Alcance</h3>
            <div className="space-y-4 text-sm text-gray-700">
              <div>
                <h4 className="font-semibold text-gray-800 mb-1">Descripción</h4>
                <p>{project?.descripcion || 'Sin descripción detallada.'}</p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-1">Alcance</h4>
                <p>{project?.alcance || 'Sin alcance definido.'}</p>
              </div>
            </div>
          </div>
        </div>
      </Collapsible>
    </div>
  );
};
