import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { ModalBaseBig } from '../ui/ModalBaseBig';
import { InputField } from '../ui/InputField';
import { TextAreaField } from '../ui/TextAreaField';
import { SelectField } from '../ui/SelectField';
import { DatePickerField } from '../ui/DatePickerField';
import { EditableField } from '../ui/EditableFiled';
import { carteraService } from '../../services/cartera.service.js';
import { formatDate } from '../../utils/dateFormatter.js';

const parseDate = (dateString) => {
    if (!dateString) return null;
    const utcDateString = `${dateString.split('T')[0]}T00:00:00.000Z`;
    const date = new Date(utcDateString);
    return isNaN(date.getTime()) ? null : date;
};

const getDisplayValue = (options, value, keyField, valueField) => {
    if (value === null || value === undefined) return '';
    const option = options.find(opt => opt[keyField]?.toString() === value.toString());
    return option ? option[valueField] : '';
};

const initialFormState = {
    descripcion: '', alcance: '', fechaInicial: null, fechaFinal: null, inversion: '',
    idAranda: '', codRelacion: '', unidadSolicitante: '', codCategoria: '', codTipo: '',
    codPrioridad: '', relacionar: 'No', gerenciaRelacionada: '', idProyectoRelacionado: '',
    tipoRelacion: '',
};

export const EditCarteraProjectModal = ({ 
    isOpen, onClose, onSubmit, projectToEdit, formOptions,
    isFormLoading, fetchProyectosRelacionables
}) => {
  const [formData, setFormData] = useState(initialFormState);
  const [isProjectLoading, setIsProjectLoading] = useState(true);
  const [editingFields, setEditingFields] = useState({});
  const [proyectosParaRelacionar, setProyectosParaRelacionar] = useState([]);

  const loadProjectDetails = useCallback(async () => {
    if (!isOpen || !projectToEdit || isFormLoading) return;
    setIsProjectLoading(true);
    setEditingFields({});
    try {
      const projectData = await carteraService.getProyectoCarteraById(projectToEdit.ID_PROYECTO);
      const gerenciaRelacionadaId = projectData.COD_DEPTO_RELACIONADO || projectData.COD_DEPTO;
      
      if (gerenciaRelacionadaId) {
        const gerencia = formOptions.gerencias.find(g => g.COD_DEPTO === gerenciaRelacionadaId);
        if (gerencia) {
          const proyectos = await fetchProyectosRelacionables(gerencia.COD_DIR, gerencia.COD_DEPTO);
          setProyectosParaRelacionar(proyectos);
        }
      }

      setFormData({
          descripcion: projectData.DESC_PROYECTO || '',
          alcance: projectData.ALCANCE_PROYECTO || '',
          fechaInicial: parseDate(projectData.FECHA_INICIAL_PLANIFICADA),
          fechaFinal: parseDate(projectData.FECHA_FINAL_PLANIFICADA),
          inversion: projectData.MONTO_INVERSION || '', idAranda: projectData.ID_ARANDA || '',
          codRelacion: projectData.COD_RELACION || '', unidadSolicitante: projectData.UNIT_SOLICITANTE || '',
          codCategoria: projectData.COD_CATEGORIA || '', codTipo: projectData.COD_TIPO || '',
          codPrioridad: projectData.COD_PRIORIDAD || '', relacionar: projectData.ID_PROYECTO_RELACIONADO ? 'Sí' : 'No',
          gerenciaRelacionada: gerenciaRelacionadaId || '', idProyectoRelacionado: projectData.ID_PROYECTO_RELACIONADO || '',
          tipoRelacion: projectData.TIPO_RELACION || '',
      });
    } catch (error) {
      toast.error(error.response?.data?.error || "No se pudieron cargar los datos para editar.");
      onClose();
    } finally {
      setIsProjectLoading(false);
    }
  }, [isOpen, projectToEdit, isFormLoading, formOptions.gerencias, fetchProyectosRelacionables, onClose]);

  useEffect(() => { loadProjectDetails(); }, [loadProjectDetails]);
  
  useEffect(() => {
    const updateRelacionables = async () => {
        if (formData.gerenciaRelacionada) {
            const gerencia = formOptions.gerencias.find(g => g.COD_DEPTO === formData.gerenciaRelacionada);
            if (gerencia) {
                const proyectos = await fetchProyectosRelacionables(gerencia.COD_DIR, gerencia.COD_DEPTO);
                setProyectosParaRelacionar(proyectos);
            }
        } else {
            setProyectosParaRelacionar([]);
        }
    };
    updateRelacionables();
  }, [formData.gerenciaRelacionada, formOptions.gerencias, fetchProyectosRelacionables]);

  const toggleEdit = (fieldName) => setEditingFields(prev => ({ ...prev, [fieldName]: !prev[fieldName] }));
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    let parsedValue = value;
    if (name === 'gerenciaRelacionada' || name === 'idProyectoRelacionado' || name === 'codCategoria' || name === 'codTipo' || name === 'codPrioridad' || name === 'codRelacion' || name === 'unidadSolicitante') {
      parsedValue = value ? parseInt(value, 10) : '';  // Parsear a número si no es vacío
    }
    if (name === 'gerenciaRelacionada') {
      setFormData(prev => ({ ...prev, [name]: parsedValue, idProyectoRelacionado: '' }));
    } else {
      setFormData(prev => ({ ...prev, [name]: parsedValue }));
    }
  };

  const handleDateChange = (name) => (date) => setFormData(prev => ({ ...prev, [name]: date }));

  const handleSubmit = (e) => {
    e.preventDefault();
    const payload = { ...formData,
      idProyectoRelacionado: formData.relacionar === 'Sí' ? formData.idProyectoRelacionado : null,
      tipoRelacion: formData.relacionar === 'Sí' ? formData.tipoRelacion : null,
    };
    onSubmit(projectToEdit.ID_PROYECTO, payload);
  };

  const isLoading = isProjectLoading || isFormLoading;

  return (
    <ModalBaseBig isOpen={isOpen} onClose={onClose} title={`Editando: ${projectToEdit.DESC_PROYECTO}`}>
      <form onSubmit={handleSubmit} className="flex flex-col flex-grow min-h-0">
        <div className="p-6 flex-grow overflow-y-auto">
          {isLoading ? (<p className="text-center p-8">Cargando datos del proyecto...</p>) : (
            <div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                <div className="flex flex-col gap-y-4">
                  <EditableField label="Descripción" isEditing={editingFields.descripcion} onEdit={() => toggleEdit('descripcion')} displayValue={formData.descripcion}>
                    <TextAreaField name="descripcion" value={formData.descripcion} onChange={handleChange} required />
                  </EditableField>
                  <EditableField label="Alcance" isEditing={editingFields.alcance} onEdit={() => toggleEdit('alcance')} displayValue={formData.alcance}>
                    <TextAreaField name="alcance" value={formData.alcance} onChange={handleChange} required />
                  </EditableField>
                </div>
                <div className="flex flex-col gap-y-4">
                  <EditableField label="ID Aranda" isEditing={editingFields.idAranda} onEdit={() => toggleEdit('idAranda')} displayValue={formData.idAranda}>
                    <InputField name="idAranda" value={formData.idAranda} onChange={handleChange} />
                  </EditableField>
                  <EditableField label="Inversión" isEditing={editingFields.inversion} onEdit={() => toggleEdit('inversion')} displayValue={formData.inversion ? `$${parseFloat(formData.inversion).toFixed(2)}` : ''}>
                      <InputField name="inversion" type="number" value={formData.inversion} onChange={handleChange} placeholder="15000.00" step="0.01" />
                  </EditableField>
                </div>
                <div className="flex flex-col gap-y-4">
                  <EditableField label="Fecha Inicial" isEditing={editingFields.fechaInicial} onEdit={() => toggleEdit('fechaInicial')} displayValue={formatDate(formData.fechaInicial)}>
                      <DatePickerField value={formData.fechaInicial} onChange={handleDateChange('fechaInicial')} required />
                  </EditableField>
                  <EditableField label="Fecha Final" isEditing={editingFields.fechaFinal} onEdit={() => toggleEdit('fechaFinal')} displayValue={formatDate(formData.fechaFinal)}>
                      <DatePickerField value={formData.fechaFinal} onChange={handleDateChange('fechaFinal')} required />
                  </EditableField>
                </div>
              </div>

              <div className="border-t border-slate-200 my-6"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
                <EditableField label="Unidad Solicitante" isEditing={editingFields.unidadSolicitante} onEdit={() => toggleEdit('unidadSolicitante')} displayValue={getDisplayValue(formOptions.unidadesSolicitantes, formData.unidadSolicitante, 'COD_DIR', 'DESC_DIR')}>
                    <SelectField name="unidadSolicitante" value={formData.unidadSolicitante} onChange={handleChange} options={formOptions.unidadesSolicitantes.map(o => ({ key: o.COD_DIR, value: o.DESC_DIR }))} required useKeyAsValue />
                </EditableField>
                <EditableField label="Categoría" isEditing={editingFields.codCategoria} onEdit={() => toggleEdit('codCategoria')} displayValue={getDisplayValue(formOptions.categorias, formData.codCategoria, 'COD_CATEGORIA', 'DESC_CATEGORIA')}>
                    <SelectField name="codCategoria" value={formData.codCategoria} onChange={handleChange} options={formOptions.categorias.map(o => ({ key: o.COD_CATEGORIA, value: o.DESC_CATEGORIA }))} required useKeyAsValue />
                </EditableField>
                <EditableField label="Tipo de Proyecto" isEditing={editingFields.codTipo} onEdit={() => toggleEdit('codTipo')} displayValue={getDisplayValue(formOptions.tiposProyecto, formData.codTipo, 'COD_TIPO', 'DESC_TIPO')}>
                    <SelectField name="codTipo" value={formData.codTipo} onChange={handleChange} options={formOptions.tiposProyecto.map(o => ({ key: o.COD_TIPO, value: o.DESC_TIPO }))} required useKeyAsValue />
                </EditableField>
                <EditableField label="Prioridad" isEditing={editingFields.codPrioridad} onEdit={() => toggleEdit('codPrioridad')} displayValue={getDisplayValue(formOptions.prioridades, formData.codPrioridad, 'COD_PRIORIDAD', 'DESC_PRIORIDAD')}>
                    <SelectField name="codPrioridad" value={formData.codPrioridad} onChange={handleChange} options={formOptions.prioridades.map(o => ({ key: o.COD_PRIORIDAD, value: o.DESC_PRIORIDAD }))} required useKeyAsValue />
                </EditableField>
              </div>

              <div className="border-t border-slate-200 my-6"></div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                <EditableField label="Relación (Objetivo)" isEditing={editingFields.codRelacion} onEdit={() => toggleEdit('codRelacion')} displayValue={getDisplayValue(formOptions.relaciones, formData.codRelacion, 'COD_RELACION', 'DESC_RELACION')}>
                  <SelectField name="codRelacion" value={formData.codRelacion} onChange={handleChange} options={formOptions.relaciones.map(o => ({ key: o.COD_RELACION, value: o.DESC_RELACION }))} required useKeyAsValue />
                </EditableField>
              </div>
              
              <div className="border-t border-slate-200 my-6"></div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                <EditableField label="¿Relacionar con otro proyecto?" isEditing={editingFields.relacionar} onEdit={() => toggleEdit('relacionar')} displayValue={formData.relacionar}>
                    <SelectField name="relacionar" value={formData.relacionar} onChange={handleChange} options={[{key: 'No', value: 'No'}, {key: 'Sí', value: 'Sí'}]} />
                </EditableField>
                {formData.relacionar === 'Sí' && ( <>
                    <EditableField label="Gerencia del Proyecto a Relacionar" isEditing={editingFields.gerenciaRelacionada} onEdit={() => toggleEdit('gerenciaRelacionada')} displayValue={getDisplayValue(formOptions.gerencias, formData.gerenciaRelacionada, 'COD_DEPTO', 'DESC_DEPARTAMENTO')}>
                        <SelectField name="gerenciaRelacionada" value={formData.gerenciaRelacionada} onChange={handleChange} options={formOptions.gerencias.map(g => ({ key: g.COD_DEPTO, value: g.DESC_DEPARTAMENTO }))} useKeyAsValue />
                    </EditableField>
                    <EditableField label="Proyecto a Relacionar" isEditing={editingFields.idProyectoRelacionado} onEdit={() => toggleEdit('idProyectoRelacionado')} displayValue={getDisplayValue(proyectosParaRelacionar, formData.idProyectoRelacionado, 'ID_PROYECTO', 'DESC_PROYECTO')}>
                        <SelectField name="idProyectoRelacionado" value={formData.idProyectoRelacionado} onChange={handleChange} options={proyectosParaRelacionar.map(p => ({ key: p.ID_PROYECTO, value: p.DESC_PROYECTO }))} disabled={!formData.gerenciaRelacionada} required useKeyAsValue />
                    </EditableField>
                    <EditableField label="Tipo de Relación" isEditing={editingFields.tipoRelacion} onEdit={() => toggleEdit('tipoRelacion')} displayValue={formData.tipoRelacion}>
                        <SelectField name="tipoRelacion" value={formData.tipoRelacion} onChange={handleChange} options={['Continuación', 'Complementario', 'Dependencia'].map(v => ({ key: v, value: v }))} required />
                    </EditableField>
                </>)}
              </div>
            </div>
          )}
        </div>
        <div className="bg-slate-50 px-6 py-4 flex flex-row-reverse border-t border-slate-200 flex-shrink-0">
          <button type="submit" className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-azul text-base font-medium text-white hover:bg-indigo-900 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm" disabled={isLoading}>
            {isLoading ? 'Guardando...' : 'Guardar Cambios'}
          </button>
          <button type="button" onClick={onClose} className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:w-auto sm:text-sm">
            Cancelar
          </button>
        </div>
      </form>
    </ModalBaseBig>
  );
};

