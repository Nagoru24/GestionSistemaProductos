// src/components/carteraPage/ApproveCarteraModal.jsx
import { ModalBase } from '../ui/ModalBase';
import { CheckCircle } from 'lucide-react';

/**
 * Modal de confirmación para la aprobación de la cartera de proyectos.
 * @param {boolean} isOpen - Controla si el modal está visible.
 * @param {function} onClose - Función para cerrar el modal.
 * @param {function} onConfirm - Función que se ejecuta al confirmar la aprobación.
 * @param {number} projectCount - El número de proyectos en la cartera para mostrar en el mensaje.
 */
export const ApproveCarteraModal = ({ isOpen, onClose, onConfirm, projectCount }) => {
  return (
    <ModalBase isOpen={isOpen} onClose={onClose} title="Aprobar Cartera de Proyectos">
        <div>
            <div className="flex justify-center mb-4 ">
                <div className="flex-shrink-0 flex items-center justify-center h-16 w-16 rounded-full bg-emerald-100">
                    <CheckCircle className="h-10 w-10 text-emerald-600" />
                </div>
            </div>
            <div className="text-center">
                <p className="text-xl text-slate-600 mb-4">
                    ¿Estás seguro de que deseas aprobar esta cartera?
                </p>
                <p className="text-lg text-slate-500">
                    Los <strong>{projectCount} proyectos</strong> pasarán a estado "En Proceso" y se fijará su fecha de inicio real. Esta acción no se puede deshacer.
                </p>
            </div>
        </div>
        <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse mt-6 -mx-8 -mb-8 rounded-b-xl">
            <button
              type="button"
              className="cursor-pointer w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-emerald-600 text-base font-medium text-white hover:bg-emerald-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
              onClick={onConfirm}
            >
              Sí, Aprobar Cartera
            </button>
            <button
              type="button"
              className="cursor-pointer mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:w-auto sm:text-sm"
              onClick={onClose}
            >
              Cancelar
            </button>
        </div>
    </ModalBase>
  );
};
