import React from 'react';
import { ModalBase } from '../ui/ModalBase';
import { AlertTriangle } from 'lucide-react';

// --- INICIO DE LA SOLUCIÓN: Componente Button definido localmente ---

// Un diccionario para mapear variantes a clases de Tailwind CSS
const buttonStyles = {
  secondary: 'bg-slate-200 text-slate-800 hover:bg-slate-300',
  danger: 'bg-red-600 text-white hover:bg-red-700',
};

/**
 * Componente de botón local para usar dentro de este modal.
 * @param {React.ReactNode} children - El texto o ícono del botón.
 * @param {function} onClick - La función a ejecutar al hacer clic.
 * @param {'secondary' | 'danger'} variant - La variante visual del botón.
 */
const Button = ({ children, onClick, variant = 'secondary' }) => {
  const style = buttonStyles[variant] || buttonStyles.secondary;
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-md font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${style}`}
    >
      {children}
    </button>
  );
};
// --- FIN DE LA SOLUCIÓN ---


/**
 * Modal para confirmar la eliminación de un proyecto.
 * @param {boolean} isOpen - Controla si el modal está visible.
 * @param {function} onClose - Función para cerrar el modal.
 * @param {function} onConfirm - Función que se ejecuta al confirmar la eliminación.
 * @param {object} project - El proyecto que se va a eliminar.
 */
export const DeleteProjectModal = ({ isOpen, onClose, onConfirm, project }) => {
  if (!isOpen || !project) return null;

  return (
    <ModalBase isOpen={isOpen} onClose={onClose} title="Confirmar Eliminación">
      <div className="text-center">
        <div className="flex justify-center mb-4">
          <AlertTriangle className="text-red-500" size={48} />
        </div>
        <p className="text-lg text-slate-700 mb-2">
          ¿Estás seguro de que quieres eliminar el proyecto?
        </p>
        <p className="font-bold text-slate-800 text-xl mb-6">
          "{project.DESC_PROYECTO}"
        </p>
        <p className="text-sm text-red-600 bg-red-100 p-3 rounded-md">
          Esta acción no se puede deshacer. Se eliminarán también todas sus relaciones y colaboradores asignados.
        </p>
      </div>

      <div className="flex justify-end space-x-4 mt-8">
        <Button variant="secondary" onClick={onClose}>
          Cancelar
        </Button>
        <Button variant="danger" onClick={onConfirm}>
          Sí, eliminar proyecto
        </Button>
      </div>
    </ModalBase>
  );
};

