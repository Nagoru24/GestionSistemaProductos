// src/components/carteraPage/AddProjectToCarteraModal.jsx
import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { ModalBaseBig } from '../ui/ModalBaseBig';
import { InputField } from '../ui/InputField';
import { TextAreaField } from '../ui/TextAreaField';
import { SelectField } from '../ui/SelectField';
import { DatePickerField } from '../ui/DatePickerField';
// Se elimina la importación del hook 'useCarteraForm'

const initialFormData = {
  descripcion: '',
  alcance: '',
  fechaInicial: null,
  fechaFinal: null,
  inversion: '',
  unidadSolicitante: '',
  codCategoria: '',
  codTipo: '',
  codPrioridad: '',
  idAranda: '',
  codRelacion: '',
  relacionar: 'No',
  gerenciaRelacionada: '',
  relacionOtroProyecto: '', 
  tipoRelacion: '',
};

// --- SOLUCIÓN: El componente ahora recibe todo lo que necesita por props ---
export const AddProjectToCarteraModal = ({ 
  isOpen, 
  onClose, 
  onSubmit, 
  carteraId,
  formOptions, // Recibe las opciones de los dropdowns
  isFormLoading, // Recibe el estado de carga
  fetchProyectosRelacionables // Recibe la función para cargar proyectos
}) => {
  const [formData, setFormData] = useState(initialFormData);

  // Este efecto se encarga de cargar los proyectos relacionables cuando se selecciona una gerencia
  useEffect(() => {
    if (formData.gerenciaRelacionada) {
      const gerencia = formOptions.gerencias.find(g => g.DESC_DEPARTAMENTO === formData.gerenciaRelacionada);
      if (gerencia) {
        fetchProyectosRelacionables(gerencia.COD_DIR, gerencia.COD_DEPTO);
      }
    } else {
      if (formData.relacionOtroProyecto) {
        setFormData(prev => ({ ...prev, relacionOtroProyecto: '' }));
      }
    }
  }, [formData.gerenciaRelacionada, formOptions.gerencias, fetchProyectosRelacionables, formData.relacionOtroProyecto]);


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleDateChange = (name) => (date) => {
    setFormData((prev) => ({ ...prev, [name]: date }));
  };

  const handleClearForm = () => {
    setFormData(initialFormData);
    toast.success("Formulario limpiado.");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // La lógica para transformar los datos del formulario a un payload para la API no cambia
    const selectedProyectoRelacionado = formOptions.proyectosRelacionables.find(
        p => p.DESC_PROYECTO === formData.relacionOtroProyecto
    );
    const idRelacionadoFinal = selectedProyectoRelacionado ? selectedProyectoRelacionado.ID_PROYECTO : null;

    const payload = {
      idCartera: carteraId,
      descripcion: formData.descripcion,
      alcance: formData.alcance,
      fechaInicial: formData.fechaInicial,
      fechaFinal: formData.fechaFinal,
      inversion: parseFloat(formData.inversion) || 0,
      unidadSolicitante: formOptions.unidadesSolicitantes.find(u => u.DESC_DIR === formData.unidadSolicitante)?.COD_DIR,
      codTipo: formOptions.tiposProyecto.find(t => t.DESC_TIPO === formData.codTipo)?.COD_TIPO,
      codCategoria: formOptions.categorias.find(c => c.DESC_CATEGORIA === formData.codCategoria)?.COD_CATEGORIA,
      codPrioridad: formOptions.prioridades.find(p => p.DESC_PRIORIDAD === formData.codPrioridad)?.COD_PRIORIDAD,
      idAranda: formData.idAranda || null,
      codRelacion: formOptions.relaciones.find(r => r.DESC_RELACION === formData.codRelacion)?.COD_RELACION,
      idProyectoRelacionado: formData.relacionar === 'Sí' ? idRelacionadoFinal : null,
      tipoRelacion: formData.relacionar === 'Sí' ? formData.tipoRelacion : null,
    };

    onSubmit(payload);
  };

  return (
    <ModalBaseBig isOpen={isOpen} onClose={onClose} title="Añadir Nuevo Proyecto a la Cartera">
      <form onSubmit={handleSubmit}>
        <div className="p-6 max-h-[70vh] overflow-y-auto ">
          {isFormLoading ? <p className="text-center p-8">Cargando formulario...</p> : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-3">
              <div className="lg:col-span-3">
                <TextAreaField label="Descripción del Proyecto (Máx. 30)" name="descripcion" value={formData.descripcion} onChange={handleChange} required maxLength={30} />
              </div>
              <div className="lg:col-span-3">
                <TextAreaField label="Alcance del Proyecto (Mín. 10)" name="alcance" value={formData.alcance} onChange={handleChange} required />
              </div>
              <InputField label="ID Aranda (Opcional)" name="idAranda" value={formData.idAranda} onChange={handleChange} />
              <SelectField label="Relación" name="codRelacion" value={formData.codRelacion} onChange={handleChange} options={formOptions.relaciones.map(o => ({ key: o.COD_RELACION, value: o.DESC_RELACION }))} required />
              <SelectField label="Unidad Solicitante" name="unidadSolicitante" value={formData.unidadSolicitante} onChange={handleChange} options={formOptions.unidadesSolicitantes.map(o => ({ key: o.COD_DIR, value: o.DESC_DIR }))} required />
              <SelectField label="Categoría" name="codCategoria" value={formData.codCategoria} onChange={handleChange} options={formOptions.categorias.map(o => ({ key: o.COD_CATEGORIA, value: o.DESC_CATEGORIA }))} required />
              <SelectField label="Tipo de Proyecto" name="codTipo" value={formData.codTipo} onChange={handleChange} options={formOptions.tiposProyecto.map(o => ({ key: o.COD_TIPO, value: o.DESC_TIPO }))} required />
              <SelectField label="Prioridad" name="codPrioridad" value={formData.codPrioridad} onChange={handleChange} options={formOptions.prioridades.map(o => ({ key: o.COD_PRIORIDAD, value: o.DESC_PRIORIDAD }))} required />
              <InputField label="Inversión (Opcional)" name="inversion" type="number" value={formData.inversion} onChange={handleChange} placeholder="15000.00" step="0.01" />
              <DatePickerField label="Fecha Inicial Planificada" value={formData.fechaInicial} onChange={handleDateChange('fechaInicial')} required />
              <DatePickerField label="Fecha Final Planificada" value={formData.fechaFinal} onChange={handleDateChange('fechaFinal')} required />
              <div className="lg:col-span-3 border-t pt-4 mt-2">
                 <SelectField label="¿Relacionar con otro proyecto?" name="relacionar" value={formData.relacionar} onChange={handleChange} options={[{key: 'No', value: 'No'}, {key: 'Sí', 'value': 'Sí'}]} />
              </div>
              {formData.relacionar === 'Sí' && (
                <>
                  <SelectField label="Gerencia del Proyecto a Relacionar" name="gerenciaRelacionada" value={formData.gerenciaRelacionada} onChange={handleChange} options={formOptions.gerencias.map(g => ({ key: g.DESC_DEPARTAMENTO, value: g.DESC_DEPARTAMENTO }))} required />
                  <SelectField 
                    label="Proyecto a Relacionar" 
                    name="relacionOtroProyecto" 
                    value={formData.relacionOtroProyecto} 
                    onChange={handleChange} 
                    options={formOptions.proyectosRelacionables.map(p => ({ key: p.ID_PROYECTO, value: p.DESC_PROYECTO }))} 
                    disabled={!formData.gerenciaRelacionada} 
                    required 
                  />
                  <SelectField label="Tipo de Relación" name="tipoRelacion" value={formData.tipoRelacion} onChange={handleChange} options={['Continuación', 'Complementario', 'Dependencia'].map(v => ({ key: v, value: v }))} required />
                </>
              )}
            </div>
          )}
        </div>
        <div className="bg-gray-50 px-6 py-2 flex flex-row-reverse cursor-pointer">
          <button type="submit" className="cursor-pointer w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-5 py-2 bg-azul text-base font-medium text-white hover:bg-indigo-900 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm" disabled={isFormLoading}>
            {isFormLoading ? 'Cargando...' : 'Añadir Proyecto'}
          </button>
          <button type="button" onClick={handleClearForm} className="cursor-pointer mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:w-auto sm:text-sm">
            Limpiar
          </button>
        </div>
      </form>
    </ModalBaseBig>
  );
};
