import React from 'react';
import { useNavigate } from 'react-router-dom';
// --- INICIO DE LA SOLUCIÓN ---
import { Pencil, UserPlus, Calendar, Users, Trash2 } from 'lucide-react';
// --- FIN DE LA SOLUCIÓN ---
import { formatDate } from '../../utils/dateFormatter';

/**
 * Tarjeta que muestra un resumen de un proyecto dentro de la lista de la cartera.
 * @param {object} project - El objeto del proyecto a mostrar.
 * @param {function} onEdit - Función para abrir el modal de edición.
 * @param {function} onDelete - Función para abrir el modal de eliminación.
 * @param {function} onOpenDetails - Función para abrir el modal de detalles.
 */
export const CarteraProjectCard = ({ project, onEdit, onDelete, onOpenDetails }) => {
  const navigate = useNavigate();

  const handleAddCollaborators = (e) => {
    e.stopPropagation();
    navigate(`/añadir-colaboradores/${project.ID_PROYECTO}?from=cartera`);
  };
  
  const handleEditClick = (e) => {
    e.stopPropagation();
    onEdit(project);
  }

  // --- INICIO DE LA SOLUCIÓN ---
  const handleDeleteClick = (e) => {
    e.stopPropagation(); // Evita que se abra el modal de detalles
    onDelete(project);
  }
  // --- FIN DE LA SOLUCIÓN ---

  return (
    <div 
      className="bg-white rounded-lg shadow p-4 border-l-4 border-indigo-500 transition-shadow hover:shadow-xl cursor-pointer flex flex-col justify-between"
      onClick={() => onOpenDetails(project.ID_PROYECTO)}
    >
      <div>
        <div className="flex justify-between items-start">
          <h3 className="font-bold text-slate-800 text-base mb-2 break-words pr-2">
            {project.DESC_PROYECTO}
          </h3>
          <div className="flex items-center space-x-1 shrink-0">
            <button onClick={handleEditClick} className="p-2 text-slate-500 hover:bg-slate-200 rounded-full transition-colors" title="Editar Proyecto">
              <Pencil size={18} />
            </button>
            <button onClick={handleAddCollaborators} className="p-2 text-slate-500 hover:bg-slate-200 rounded-full transition-colors" title="Añadir Colaboradores">
              <UserPlus size={18} />
            </button>
            {/* --- INICIO DE LA SOLUCIÓN --- */}
            <button onClick={handleDeleteClick} className="p-2 text-red-500 hover:bg-red-100 rounded-full transition-colors" title="Eliminar Proyecto">
              <Trash2 size={18} />
            </button>
            {/* --- FIN DE LA SOLUCIÓN --- */}
          </div>
        </div>
        <p className="text-sm text-slate-600 line-clamp-3 mb-4">
          {project.ALCANCE_PROYECTO || 'Sin alcance definido.'}
        </p>
      </div>
      
      <div className="border-t pt-3 flex justify-between items-center text-sm text-slate-500">
        <div className="flex items-center" title="Colaboradores asignados">
            <Users size={14} className="mr-2 text-slate-400" />
            <strong className="text-slate-700">{project.NUM_COLABORADORES || 0}</strong>
        </div>
        <div className="flex items-center" title="Plazo del proyecto">
          <Calendar size={14} className="mr-2" />
          <strong>{formatDate(project.FECHA_INICIAL_PLANIFICADA)}</strong>
          <span className="mx-1">-</span>
          <strong>{formatDate(project.FECHA_FINAL_PLANIFICADA)}</strong>
        </div>
      </div>
    </div>
  );
};
