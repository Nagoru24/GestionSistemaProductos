// src/components/carteraPage/CarteraHeader.jsx
import { HiOutlinePlus, HiOutlineCheckCircle } from 'react-icons/hi';

/**
 * Componente que muestra la cabecera de la página de la cartera.
 * Incluye el título, el número de proyectos y los botones de acción principales.
 * @param {object} cartera - El objeto de la cartera activa.
 * @param {number} projectCount - El número de proyectos en la cartera.
 * @param {function} onAddProject - Función para abrir el modal de añadir proyecto.
 * @param {function} onApprove - Función para abrir el modal de aprobación.
 * @param {boolean} isLoading - Estado de carga para deshabilitar los botones.
 */
export const CarteraHeader = ({ cartera, projectCount, onAddProject, onApprove, isLoading }) => {
  return (
    <div className="mb-8 p-6 bg-slate-50 rounded-xl shadow-lg">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          {isLoading ? (
            <div className="h-8 bg-slate-200 rounded w-3/4 animate-pulse"></div>
          ) : (
            <h1 className="text-3xl font-bold text-azul">
              {cartera?.NOMBRE_CARTERA || 'Cargando Cartera...'}
            </h1>
          )}
          <p className="text-slate-500 mt-1">
            {projectCount} {projectCount === 1 ? 'proyecto en planificación' : 'proyectos en planificación'}.
          </p>
        </div>
        <div className="flex space-x-4 mt-4 md:mt-0">
          <button
            onClick={onAddProject}
            disabled={isLoading || !cartera}
            className="cursor-pointer flex items-center px-4 py-2 rounded-md text-sm font-medium text-white bg-azul hover:bg-indigo-900 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 shadow-sm disabled:bg-slate-400 disabled:cursor-not-allowed"
          >
            <HiOutlinePlus className="w-5 h-5 mr-2" />
            Añadir Proyecto
          </button>
          <button
            onClick={onApprove}
            disabled={isLoading || !cartera || projectCount === 0}
            className="cursor-pointer flex items-center px-4 py-2 rounded-md text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 shadow-sm disabled:bg-slate-400 disabled:cursor-not-allowed"
          >
            <HiOutlineCheckCircle className="w-5 h-5 mr-2" />
            Aprobar Cartera
          </button>
        </div>
      </div>
    </div>
  );
};
