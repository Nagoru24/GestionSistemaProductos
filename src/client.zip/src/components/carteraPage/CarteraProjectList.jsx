// src/components/carteraPage/CarteraProjectList.jsx
import { CarteraProjectCard } from './CarteraProjectCard';
import { HiOutlineInbox } from 'react-icons/hi';

/**
 * Componente que renderiza la lista completa de proyectos de la cartera.
 * @param {Array} projects - El array de proyectos a mostrar.
 * @param {boolean} isLoading - Estado de carga.
 * @param {string|null} error - Mensaje de error, si existe.
 * @param {function} onEditProject - Función para abrir el modal de edición.
 * @param {function} onOpenDetailsModal - Función para abrir el modal de detalles.
 * @param {function} onDeleteProject - Función para abrir el modal de eliminación.
 */
export const CarteraProjectList = ({ 
  projects, 
  isLoading, 
  error, 
  onEditProject, 
  onOpenDetailsModal, 
  // --- INICIO DE LA SOLUCIÓN (Paso 1) ---
  onDeleteProject 
  // --- FIN DE LA SOLUCIÓN (Paso 1) ---
}) => {
  // Muestra esqueletos de carga mientras se obtienen los datos
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-white p-5 rounded-lg shadow animate-pulse">
            <div className="h-6 bg-slate-200 rounded w-3/4 mb-2"></div>
            <div className="h-4 bg-slate-200 rounded w-1/2 mb-4"></div>
            <div className="space-y-2">
              <div className="h-4 bg-slate-200 rounded"></div>
              <div className="h-4 bg-slate-200 rounded w-5/6"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  // Muestra un mensaje de error si la carga falla
  if (error) {
    return <div className="text-center text-red-500 bg-red-100 p-4 rounded-lg">{error}</div>;
  }

  // Muestra un mensaje si no hay proyectos en la cartera
  if (projects.length === 0) {
    return (
      <div className="text-center py-16 px-6 border-2 border-dashed border-slate-300 rounded-lg">
        <HiOutlineInbox className="mx-auto h-12 w-12 text-slate-400" />
        <h3 className="mt-2 text-lg font-medium text-slate-900">Cartera Vacía</h3>
        <p className="mt-1 text-sm text-slate-500">
          Aún no has añadido proyectos. Haz clic en "Añadir Proyecto" para empezar.
        </p>
      </div>
    );
  }

  // Renderiza la lista de tarjetas de proyecto
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {projects.map((project) => (
        <CarteraProjectCard
          key={project.ID_PROYECTO}
          project={project}
          onEdit={() => onEditProject(project)}
          onOpenDetails={() => onOpenDetailsModal(project.ID_PROYECTO)}
          // --- INICIO DE LA SOLUCIÓN (Paso 2) ---
          // Aquí pasamos la función onDeleteProject, que recibimos como prop,
          // a la prop 'onDelete' de la tarjeta.
          onDelete={() => onDeleteProject(project)}
          // --- FIN DE LA SOLUCIÓN (Paso 2) ---
        />
      ))}
    </div>
  );
};

