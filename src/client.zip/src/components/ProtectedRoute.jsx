// src/components/ProtectedRoute.jsx

import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.js';

export const ProtectedRoute = ({ allowedRoles }) => {
  // Cambia 'isAuthLoading' por 'isLoading' para que coincida con el AuthProvider.
  const { user, token, isLoading } = useAuth(); //

  // Verifica que isLoading sea falso antes de ejecutar la lógica de redirección.
  if (isLoading) { //
    return <div>Verificando sesión...</div>;
  }

  // Si el usuario no tiene token, lo redirigimos a la página de login.
  if (!token) { //
    return <Navigate to="/login" replace />;
  }

  // Si se especifican roles y el rol del usuario no está incluido, redirige.
  // Esta lógica solo se ejecuta después de que el token se ha validado y el usuario ha sido cargado.
  if (!user || (allowedRoles && !allowedRoles.includes(user.rol))) {
    return <Navigate to="/pantalla-principal" replace />;
  }

  // Si todo está correcto, permite el acceso a la ruta.
  return <Outlet />;
};