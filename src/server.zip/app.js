import Fastify from 'fastify';
// Importamos el plugin de CORS para Fastify
import cors from '@fastify/cors';
import mssqlPlugin from './src/plugins/mssql-connector.js';
import sqlConfig from './src/config/db.config.js';

import { proyectosRoutes } from './src/routes/proyectos.routes.js';
import { colaboradoresRoutes } from './src/routes/colaboradores.routes.js';
import { gerenciasRoutes} from './src/routes/gerencias.routes.js';
import { carterasRoutes } from './src/routes/carteras.routes.js';

import { authRoutes } from './src/routes/auth.routes.js';
import authenticatePlugin from './src/plugins/authenticate.js';
import jwt from '@fastify/jwt';

import authorizeRolesPlugin from './src/plugins/authorizeRoles.js';


// -------------------- INSTANCIA DE FASTIFY -----------------------------
const fastify = Fastify({ logger: true });


(async () => {
  try {
    // -------------------- REGISTRAR EL PLUGIN DE CORS ----------------------
    // ¡Aquí es donde debes registrar el plugin!
    await fastify.register(cors, {
          origin: true, // Permite cualquier origen, ideal para desarrollo.
          methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'], 
    });

    // -------------------- REGISTRAR EL PLUGIN DE MSSQL -----------------------------
    await fastify.register(mssqlPlugin, sqlConfig);

    // Registrar el plugin JWT para firmar y verificar tokens.
    await fastify.register(jwt, {
      secret: process.env.JWT_SECRET, // Asegúrate de tener esta variable en tu .env
    });

    // ----- Acepta un array de roles permitidos y devuelve un hook preHandler -------------
    await fastify.register(authorizeRolesPlugin);

    // Registrar nuestro decorador de autenticación para proteger rutas.
    await fastify.register(authenticatePlugin);

    // ¡NUEVO! Registrar nuestro decorador de autorización.
    await fastify.register(import('./src/plugins/authorize.js'));

    // -------------------- REGISTRAR LAS RUTAS DE AUTENTICACIÓN -----------------------------
    await fastify.register(authRoutes, { prefix: '/auth' });

    // -------------------- REGISTRAR LAS RUTAS DE PROYECTOS -----------------------------
    await fastify.register(proyectosRoutes);

    // -------------------- REGISTRAR LAS RUTAS DE COLABORADORES -----------------------------
    // ¡Aquí está la corrección! Pasas la función directamente.
    await fastify.register(colaboradoresRoutes);

     // -------------------- REGISTRAR LAS RUTAS DE GERENCIAS -----------------------------
    await fastify.register(gerenciasRoutes);

    // ----- RUTAS PARA CREACIÓN DE CARTERAS -----------
    await fastify.register(carterasRoutes, { prefix: '/api' });


    // -------------------- INICIAR SERVIDOR -----------------------------
    await fastify.listen({ port: 3000 });
    console.log('Servidor corriendo en http://localhost:3000');
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
})();