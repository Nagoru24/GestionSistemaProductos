import {
  getAllDepartamentos,
  getProyectosPorGerencia,
  aprobarProyecto,
  pausarProyecto,
  reactivarProyecto,
  completarProyecto,
  getProyectoCompletoPorId,
  eliminarProyecto,
  editarProyectoPlanificado,
} from '../services/gerencias.service.js';

// Obtener la lista de todas las gerencias para el menú
export const getDepartamentosHandler = async (request, reply) => {
    try {
        const departamentos = await getAllDepartamentos(request.server);
        reply.send(departamentos);
    } catch (error) {
        request.log.error(error, "Error en getDepartamentosHandler");
        reply.status(500).send({ message: "Error del servidor al obtener departamentos" });
    }
};

// Obtener los proyectos para el tablero Kanban
export const getProyectosPorGerenciaHandler = async (request, reply) => {
    try {
        const { user } = request;
        const params = request.params;
        
        const codDirAConsultar = (user.rol === 'Gerente' || user.rol === 'Colaborador') ? user.codDir : params.codDir;
        const codDeptoAConsultar = (user.rol === 'Gerente' || user.rol === 'Colaborador') ? user.codDepto : params.codDepto;

        const proyectos = await getProyectosPorGerencia(request.server, { 
            codDir: codDirAConsultar, 
            codDepto: codDeptoAConsultar 
        });
        
        reply.send(proyectos);
    } catch (error) {
        request.log.error(error, "Error en getProyectosPorGerenciaHandler");
        reply.status(500).send({ message: "Error al obtener proyectos de la gerencia" });
    }
};

// --- MANEJADORES DE ACCIONES ---
export const aprobarProyectoHandler = async (request, reply) => {
    try {
        const { idProyecto } = request.params;
        const { justificacion } = request.body; // <-- Se elimina 'fechaEntrega'
        
        // Se elimina la validación de la fecha, solo se valida la justificación
        if (!justificacion) {
            return reply.status(400).send({ message: "La justificación es requerida." });
        }
        
        const resultado = await aprobarProyecto(request.server, {
            idProyecto,
            // fechaEntrega, // <-- LÍNEA ELIMINADA
            justificacion,
            usuario: request.user
        });
        reply.send(resultado);
    } catch (error) {
        request.log.error(error, "Error en aprobarProyectoHandler");
        // Se añade un manejo de error más específico para el frontend
        const errorMessage = error.originalError?.message || "Error al aprobar el proyecto";
        reply.status(500).send({ message: errorMessage });
    }
};

export const pausarProyectoHandler = async (request, reply) => {
    try {
        const { idProyecto } = request.params;
        const { justificacion } = request.body;
        if (!justificacion) {
            return reply.status(400).send({ message: "La justificación es requerida para pausar." });
        }
        const resultado = await pausarProyecto(request.server, {
            idProyecto,
            justificacion,
            usuario: request.user
        });
        reply.send(resultado);
    } catch (error) {
        request.log.error(error, "Error en pausarProyectoHandler");
        reply.status(500).send({ message: "Error al pausar el proyecto" });
    }
};

export const reactivarProyectoHandler = async (request, reply) => {
    try {
        const { idProyecto } = request.params;
        const resultado = await reactivarProyecto(request.server, {
            idProyecto,
            usuario: request.user
        });
        reply.send(resultado);
    } catch (error) {
        request.log.error(error, "Error en reactivarProyectoHandler");
        reply.status(500).send({ message: "Error al reactivar el proyecto" });
    }
};

export const completarProyectoHandler = async (request, reply) => {
    try {
        const { idProyecto } = request.params;
        const resultado = await completarProyecto(request.server, {
            idProyecto,
            usuario: request.user
        });
        reply.send(resultado);
    } catch (error) {
        request.log.error(error, "Error en completarProyectoHandler");
        reply.status(500).send({ message: "Error al completar el proyecto" });
    }
};

export const eliminarProyectoHandler = async (request, reply) => {
    try {
        const { idProyecto } = request.params;
        const resultado = await eliminarProyecto(request.server, {
            idProyecto,
            usuario: request.user
        });
        reply.send(resultado);
    } catch (error) {
        request.log.error(error, "Error en eliminarProyectoHandler");
        reply.status(500).send({ message: "Error al eliminar el proyecto" });
    }
};



// --- MANEJADOR PARA EL MODAL DE DETALLES ---
export const getProyectoCompletoPorIdHandler = async (request, reply) => {
  const { idProyecto } = request.params;
  try {
    const data = await getProyectoCompletoPorId(request.server, idProyecto);
    if (!data.proyecto) {
      return reply.code(404).send({ error: 'Proyecto no encontrado.' });
    }
    return reply.code(200).send(data);
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({ error: 'Error al obtener los detalles completos del proyecto.' });
  }
};

export const editarProyectoPlanificadoHandler = async (request, reply) => {
    try {
        const { idProyecto } = request.params;
        
        // Llamamos a nuestro servicio con los datos necesarios
        const resultado = await editarProyectoPlanificado(request.server, {
            idProyecto,
            data: request.body,
            usuario: request.user
        });
        
        reply.send(resultado);

    } catch (error) {
        request.log.error(error, "Error en editarProyectoPlanificadoHandler");

        // Manejo de errores específicos del SP
        if (error.number === 50001 || error.number === 50002) {
            return reply.status(400).send({ message: error.message });
        }
        
        // Error genérico del servidor
        reply.status(500).send({ message: "Error del servidor al editar el proyecto." });
    }
};