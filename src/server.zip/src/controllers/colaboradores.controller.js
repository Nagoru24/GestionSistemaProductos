// src/controllers/colaboradores.controller.js

import {
  getColaboradoresPorDepartamento as getUsuariosService,
  getProyectoPorId as getProyectoService,
  getProyectosPorFuncionario as getProyectosService,
  asignarColaboradores as asignarService,
  getColaboradoresPorProyecto as getColaboradoresService,
  eliminarColaborador as eliminarColaboradorService,
} from '../services/colaboradores.service.js';

// --- MODIFICACIÓN: Se elimina el middleware obsoleto 'authorizeGerente' ---

// Obtener usuarios por departamento
export const getColaboradoresPorDepartamento = async (request, reply) => {
  const { codDir, codDepto } = request.query;
  try {
    if (!codDir || !codDepto) {
      return reply.code(400).send({ error: 'Faltan parámetros codDir o codDepto.' });
    }
    const usuarios = await getUsuariosService(request.server, codDir, codDepto);
    return reply.code(200).send(usuarios);
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({ error: error.message || 'Error al obtener usuarios por departamento.' });
  }
};

// Obtener proyecto por ID
export const getProyectoPorId = async (request, reply) => {
  const { idProyecto } = request.params;
  try {
    const proyecto = await getProyectoService(request.server, idProyecto);
    // La autorización ya fue manejada por el plugin 'authorize', aquí solo verificamos si existe.
    if (!proyecto) {
      return reply.code(404).send({ error: 'Proyecto no encontrado.' });
    }
    return reply.code(200).send(proyecto);
  } catch (error) {
    request.log.error(error);
    // El plugin 'authorize' ya maneja los errores 403 y 404, esto es un fallback.
    return reply.code(500).send({ error: 'Error al obtener el proyecto.' });
  }
};

// Obtener proyectos por funcionario (ajustado para recibir id por params)
export const getProyectosPorFuncionario = async (request, reply) => {
  const { idFuncionario } = request.params;
  try {
    const proyectos = await getProyectosService(request.server, idFuncionario);
    return reply.code(200).send(proyectos);
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({ error: 'Error al obtener proyectos por funcionario.' });
  }
};

export const asignarColaboradores = async (request, reply) => {
  const { user } = request;
  const { idProyecto } = request.params;

  // --- CORRECCIÓN DEFINITIVA ---
  // Esta línea asegura que siempre obtengamos un array.
  // Si el frontend envía { "colaboradores": [...] }, tomará la propiedad.
  // Si el frontend envía solo [...], tomará el cuerpo entero de la petición.
  const colaboradores = request.body.colaboradores || request.body;

  if (!idProyecto || !colaboradores || !Array.isArray(colaboradores) || colaboradores.length === 0) {
    return reply.code(400).send({ error: 'Faltan idProyecto o la lista de colaboradores es inválida.' });
  }

  try {
    const result = await asignarService(
      request.server,
      idProyecto,
      user.usuario,
      colaboradores
    );
    return reply.code(200).send(result);
  } catch (error) {
    request.log.error(error);
    if (error.number >= 50000) {
      return reply.code(400).send({ error: error.message });
    }
    return reply.code(500).send({ error: 'Error al asignar colaboradores.' });
  }
};

// Obtener colaboradores asignados a un proyecto
export const getColaboradoresPorProyecto = async (request, reply) => {
  const { idProyecto } = request.params;
  try {
    const colaboradores = await getColaboradoresService(request.server, idProyecto);
    return reply.code(200).send(colaboradores);
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({ error: 'Error al obtener colaboradores asignados.' });
  }
};

// Eliminar, Activar o Inactivar un colaborador de un proyecto
export const eliminarColaborador = async (request, reply) => {
  const { user } = request; // Usuario real del token
  const { idProyecto } = request.params;
  const { idFuncionario, justificacion } = request.body;

  // --- MODIFICACIÓN: La justificación no siempre es obligatoria ---
  // El SP se encargará de validarla cuando sea necesario (ej. al inactivar).
  if (!idProyecto || !idFuncionario) {
    return reply.code(400).send({ error: 'Faltan idProyecto o idFuncionario.' });
  }

  try {
    const result = await eliminarColaboradorService(
      request.server,
      idProyecto,
      idFuncionario,
      user.usuario,
      justificacion || '' // Se envía un string vacío si es null/undefined
    );
    return reply.code(200).send(result);
  } catch (error) {
    request.log.error(error);
    if (error.number >= 50000) {
      return reply.code(400).send({ error: error.message });
    }
    return reply.code(500).send({ error: 'Error al procesar la operación.' });
  }
};