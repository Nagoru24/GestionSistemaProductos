// src/controllers/carteras.controller.js
import {
  getOrCreateCartera,
  addProyectoToCartera,
  aprobarCartera,
  getProyectosParaRelacionar,
  editProyectoInCartera, // <-- Se importa la nueva función de edición
  getProyectoCarteraById,
  deleteProyectoFromCartera,
} from '../services/carteras.service.js';

/**
 * Handler para obtener la cartera activa de un gerente.
 */
export const getCarteraActivaHandler = async (request, reply) => {
  try {
    const user = request.user;
    const resultado = await getOrCreateCartera(request.server, user.id, user.usuario);
    reply.send(resultado);
  } catch (err) {
    request.log.error(err, 'Error al obtener o crear la cartera');
    reply.status(500).send({ error: 'Error interno del servidor al procesar la cartera.' });
  }
};

/**
 * Handler para añadir un nuevo proyecto a la cartera activa.
 */
export const addProyectoHandler = async (request, reply) => {
  try {
    const user = request.user;
    const body = request.body;

    // --- INICIO DE LA SOLUCIÓN ---
    // 1. Log para depuración: Muestra exactamente lo que envía el frontend.
    request.log.info({ bodyRecibido: body }, 'Datos recibidos del frontend para añadir proyecto');

    // 2. Mapeo explícito: Creamos un objeto limpio y garantizamos que las propiedades
    //    tengan los nombres que el servicio espera, sin importar cómo lleguen.
    const projectData = {
      // Datos de la cartera y usuario
      idCartera: body.idCartera,
      idGerente: user.id,
      usuarioCreacion: user.usuario,
      
      // Datos del formulario
      descripcion: body.descripcion,
      alcance: body.alcance,
      idAranda: body.idAranda,
      codRelacion: body.codRelacion,
      unidadSolicitante: body.unidadSolicitante,
      codCategoria: body.codCategoria,
      codTipo: body.codTipo,
      codPrioridad: body.codPrioridad,
      inversion: body.inversion,
      fechaInicial: body.fechaInicial,
      fechaFinal: body.fechaFinal,
      
      // Datos clave de la relación
      idProyectoRelacionado: body.idProyectoRelacionado,
      tipoRelacion: body.tipoRelacion,
    };
    // --- FIN DE LA SOLUCIÓN ---

    if (!projectData.idCartera || !projectData.descripcion) {
      return reply.status(400).send({ error: 'Faltan datos esenciales como idCartera o descripción.' });
    }

    const nuevoProyecto = await addProyectoToCartera(request.server, projectData);
    reply.status(201).send(nuevoProyecto);

  } catch (err) {
    request.log.error(err, 'Error al añadir proyecto a la cartera');
    if (err.number >= 50000) {
      return reply.status(400).send({ error: err.message });
    }
    reply.status(500).send({ error: 'Error interno del servidor al añadir el proyecto.' });
  }
};

/**
 * Handler para editar un proyecto existente en una cartera.
 */
export const editProyectoHandler = async (request, reply) => {
  try {
    const user = request.user;
    const { idProyecto } = request.params;
    const body = request.body;

    // --- INICIO DE LA DEPURACIÓN ---
    // 1. Log para ver los datos CRUDOS que llegan del frontend.
    request.log.info({ bodyRecibido: body }, 'PASO 1: Datos crudos recibidos en el controlador');
    // --- FIN DE LA DEPURACIÓN ---

    const projectData = {
      usuarioModificacion: user.usuario,
      
      descripcion: body.descripcion,
      alcance: body.alcance,
      idAranda: body.idAranda || null,
      fechaInicial: body.fechaInicial,
      fechaFinal: body.fechaFinal,
      inversion: parseFloat(body.inversion) || 0,
      
      unidadSolicitante: parseInt(body.unidadSolicitante, 10) || null,
      codCategoria: parseInt(body.codCategoria, 10) || null,
      codTipo: parseInt(body.codTipo, 10) || null,
      codPrioridad: parseInt(body.codPrioridad, 10) || null,
      codRelacion: parseInt(body.codRelacion, 10) || null,
      
      idProyectoRelacionado: parseInt(body.idProyectoRelacionado, 10) || null,
      tipoRelacion: body.tipoRelacion,
    };

    // --- INICIO DE LA DEPURACIÓN ---
    // 2. Log para ver los datos DESPUÉS de ser procesados y justo ANTES de enviarlos al servicio.
    request.log.info({ payloadEnviado: projectData }, 'PASO 2: Payload procesado que se envía al servicio');
    // --- FIN DE LA DEPURACIÓN ---

    const proyectoActualizado = await editProyectoInCartera(request.server, idProyecto, projectData);
    reply.send(proyectoActualizado);

  } catch (err) {
    // --- INICIO DE LA DEPURACIÓN ---
    // 3. Log MEJORADO para capturar el error con más detalle.
    request.log.error({ 
        error: err, 
        message: err.message, 
        stack: err.stack 
    }, 'Error al editar el proyecto en la cartera');
    // --- FIN DE LA DEPURACIÓN ---
    
    if (err.number >= 50000) {
      return reply.status(400).send({ error: err.message });
    }
    reply.status(500).send({ error: 'Error interno del servidor al editar el proyecto.' });
  }
};

/**
 * Handler para obtener los proyectos de una gerencia que pueden ser relacionados.
 */
export const getProyectosParaRelacionarHandler = async (request, reply) => {
  try {
    const { codDir, codDepto } = request.params;
    const proyectos = await getProyectosParaRelacionar(request.server, codDir, codDepto);
    reply.send(proyectos);
  } catch (err) {
    request.log.error(err, 'Error al obtener proyectos para relacionar');
    reply.status(500).send({ error: 'Error interno del servidor al buscar proyectos.' });
  }
};

export const getProyectoByIdHandler = async (request, reply) => {
  try {
    const { idProyecto } = request.params;
    const proyecto = await getProyectoCarteraById(request.server, idProyecto);
    reply.send(proyecto);
  } catch (err) {
    request.log.error(err, 'Error al obtener los detalles del proyecto');
    if (err.number >= 50000) {
      return reply.status(404).send({ error: err.message });
    }
    reply.status(500).send({ error: 'Error interno del servidor al buscar el proyecto.' });
  }
};

/**
 * Handler para aprobar una cartera.
 */
export const aprobarCarteraHandler = async (request, reply) => {
  try {
    const user = request.user;
    const { idCartera } = request.params;

    const resultado = await aprobarCartera(request.server, idCartera, user.usuario);
    reply.send(resultado);
  } catch (err) {
    request.log.error(err, 'Error al aprobar la cartera');
    if (err.number >= 50000) {
      return reply.status(400).send({ error: err.message });
    }
    reply.status(500).send({ error: 'Error interno del servidor al aprobar la cartera.' });
  }
};

// src/controllers/carteras.controller.js

export const deleteProyectoHandler = async (request, reply) => {
  try {
    const { idProyecto } = request.params;
    const user = request.user; // Contiene user.id y user.usuario

    // Se pasan el ID del proyecto, el ID del gerente (user.id) y el nombre de usuario (user.usuario)
    await deleteProyectoFromCartera(request.server, idProyecto, user.id, user.usuario);
    
    // Si la eliminación es exitosa, se responde con un mensaje.
    reply.send({ message: 'Proyecto eliminado exitosamente.' });

  } catch (err) {
    request.log.error(err, 'Error al eliminar el proyecto de la cartera');
    
    // Errores de negocio personalizados desde el SP (ej. no encontrado, sin permiso)
    if (err.number >= 50000) {
      return reply.status(400).send({ error: err.message });
    }
    
    // Errores inesperados
    reply.status(500).send({ error: 'Error interno del servidor al eliminar el proyecto.' });
  }
};