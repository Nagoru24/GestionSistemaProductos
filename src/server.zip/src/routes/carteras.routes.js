// src/routes/carteras.routes.js
import {
  getCarteraActivaHandler,
  addProyectoHandler,
  editProyectoHandler,
  aprobarCarteraHandler,
  getProyectosParaRelacionarHandler,
  getProyectoByIdHandler,
  // --- NUEVO ---
  deleteProyectoHandler,
} from '../controllers/carteras.controller.js';

export const carterasRoutes = async (fastify, options) => {
  
  const gerenteOpts = {
    preHandler: [fastify.authenticate, fastify.authorizeRoles(['Gerente', 'PM'])],
  };

  const directorGerenteOpts = {
    preHandler: [fastify.authenticate, fastify.authorizeRoles(['Director', 'Gerente', 'PM'])]
  };

  // GET /api/cartera -> Obtiene la cartera activa del gerente.
  fastify.get('/cartera', gerenteOpts, getCarteraActivaHandler);

  // POST /api/cartera/proyecto -> Añade un nuevo proyecto a la cartera.
  fastify.post('/cartera/proyecto', gerenteOpts, addProyectoHandler);

  // PUT /api/cartera/proyecto/:idProyecto -> Edita un proyecto existente en la cartera.
  fastify.put('/cartera/proyecto/:idProyecto', gerenteOpts, editProyectoHandler);

  // GET /api/cartera/proyecto/:idProyecto -> Obtiene los detalles de un proyecto para editar.
  fastify.get('/cartera/proyecto/:idProyecto', gerenteOpts, getProyectoByIdHandler);

  // --- NUEVO ---
  // DELETE /api/cartera/proyecto/:idProyecto -> Elimina un proyecto de la cartera.
  fastify.delete('/cartera/proyecto/:idProyecto', gerenteOpts, deleteProyectoHandler);
  // --- FIN ---

  // PUT /api/cartera/:idCartera/aprobar -> Aprueba la cartera.
  fastify.put('/cartera/:idCartera/aprobar', directorGerenteOpts, aprobarCarteraHandler);

  // GET /api/proyectos-relacionables/:codDir/:codDepto -> Obtiene proyectos para el dropdown.
  fastify.get('/proyectos-relacionables/:codDir/:codDepto', gerenteOpts, getProyectosParaRelacionarHandler);
};
