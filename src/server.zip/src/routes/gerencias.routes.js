// src/routes/gerencias.routes.js
import {
  getDepartamentosHandler,
  getProyectosPorGerenciaHandler,
  aprobarProyectoHandler,
  pausarProyectoHandler,
  reactivarProyectoHandler,
  completarProyectoHandler,
  getProyectoCompletoPorIdHandler,
  eliminarProyectoHandler,
  editarProyectoPlanificadoHandler,
} from '../controllers/gerencias.controller.js';

export const gerenciasRoutes = async (fastify, options) => {
  
  // AÑADIMOS UN preHandler A TODAS LAS RUTAS QUE NECESITAN AUTENTICACIÓN
  
  fastify.get('/departamentos', {
    preHandler: [fastify.authenticate], // <-- RUTA PROTEGIDA
    handler: getDepartamentosHandler,
  });

  fastify.get('/gerencias/:codDir/:codDepto/proyectos', {
    preHandler: [fastify.authenticate], // <-- RUTA PROTEGIDA (ESTA ES LA QUE FALLABA)
    handler: getProyectosPorGerenciaHandler,
  });

  fastify.get('/proyectos/:idProyecto/detalles', {
    preHandler: [fastify.authenticate], // <-- RUTA PROTEGIDA
    handler: getProyectoCompletoPorIdHandler,
  });

  // --- RUTAS DE ACCIONES DEL KANBAN ---

  fastify.patch('/proyectos/:idProyecto/aprobar', {
    preHandler: [fastify.authenticate], // <-- RUTA PROTEGIDA
    handler: aprobarProyectoHandler,
  });

  fastify.patch('/proyectos/:idProyecto/pausar', {
    preHandler: [fastify.authenticate], // <-- RUTA PROTEGIDA
    handler: pausarProyectoHandler,
  });

  fastify.patch('/proyectos/:idProyecto/reactivar', {
    preHandler: [fastify.authenticate], // <-- RUTA PROTEGIDA
    handler: reactivarProyectoHandler,
  });

  fastify.patch('/proyectos/:idProyecto/completar', {
    preHandler: [fastify.authenticate], // <-- RUTA PROTEGIDA
    handler: completarProyectoHandler,
  });

  // Dentro de la función gerenciasRoutes...
  fastify.delete('/proyectos/:idProyecto/eliminar', {
      preHandler: [fastify.authenticate], // RUTA PROTEGIDA
      handler: eliminarProyectoHandler,
  });

  fastify.patch('/proyectos/:idProyecto/planificacion', {
    preHandler: [fastify.authenticate],
    handler: editarProyectoPlanificadoHandler,
  });

};