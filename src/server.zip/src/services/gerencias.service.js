import sql from 'mssql';

// Función para obtener la lista de todas las gerencias (para el menú del PM/Director)
export const getAllDepartamentos = async (fastify) => {
    const pool = fastify.mssql;
    const result = await pool.request().execute('SP_GET_DEPARTAMENTOS');
    return result.recordset;
};

// Función para obtener los proyectos que se mostrarán en el tablero Kanban
export const getProyectosPorGerencia = async (fastify, { codDir, codDepto }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('COD_DIR', sql.Int, codDir);
    request.input('COD_DEPTO', sql.Int, codDepto);
    const result = await request.execute('SP_GET_PROYECTOS_POR_GERENCIA');
    return result.recordset;
};

// --- ACCIONES DEL KANBAN ---

export const aprobarProyecto = async (fastify, { idProyecto, justificacion, usuario }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('ID_PROYECTO', sql.Int, idProyecto);
    request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuario.usuario);
    request.input('JUSTIFICACION', sql.VarChar(200), justificacion);

    // --- CAMBIO: AÑADIMOS TRY...CATCH PARA VER EL ERROR DE SQL ---
    try {
        await request.execute('SP_APROBAR_PROYECTO');
        return { message: 'Proyecto aprobado correctamente' };
    } catch (error) {
        // Esto imprimirá el error detallado de la base de datos en tu consola del backend
        console.error("Error detallado de SQL Server:", error);
        
        // Lanzamos el error para que el controlador lo maneje como antes
        throw error;
    }
};


export const pausarProyecto = async (fastify, { idProyecto, justificacion, usuario }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('ID_PROYECTO', sql.Int, idProyecto);
    request.input('JUSTIFICACION', sql.VarChar(500), justificacion);
    request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuario.usuario);
    await request.execute('SP_PAUSAR_PROYECTO');
    return { message: 'Proyecto pausado correctamente' };
};

export const reactivarProyecto = async (fastify, { idProyecto, usuario }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('ID_PROYECTO', sql.Int, idProyecto);
    request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuario.usuario);
    await request.execute('SP_REACTIVAR_PROYECTO');
    return { message: 'Proyecto reactivado correctamente' };
};

export const completarProyecto = async (fastify, { idProyecto, usuario }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('ID_PROYECTO', sql.Int, idProyecto);
    request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuario.usuario);
    await request.execute('SP_COMPLETAR_PROYECTO');
    return { message: 'Proyecto completado correctamente' };
};

export const eliminarProyecto = async (fastify, { idProyecto, usuario }) => {
    const pool = fastify.mssql;
    const request = pool.request();
    request.input('ID_PROYECTO', sql.Int, idProyecto);
    request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuario.usuario);
    await request.execute('SP_ELIMINAR_PROYECTO');
    return { message: 'Operación de eliminación completada.' };
};


// --- FUNCIÓN PARA EL MODAL DE DETALLES ---
export const getProyectoCompletoPorId = async (fastify, idProyecto) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('ID_PROYECTO', sql.Int, idProyecto);
  const result = await request.execute('SP_GET_PROYECTO_COMPLETO_POR_ID');
  
  const proyecto = result.recordsets[0][0];
  const colaboradores = result.recordsets[1];

  return { proyecto, colaboradores };
};


export const editarProyectoPlanificado = async (fastify, { idProyecto, data, usuario }) => {
    const pool = fastify.mssql;
    const request = pool.request();

    // Vinculamos los parámetros con sus tipos de dato de SQL
    request.input('ID_PROYECTO', sql.Int, idProyecto);
    request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuario.usuario);
    
    // --- ✨ CORRECCIÓN: Añadimos los nuevos parámetros para la gerencia ---
    request.input('COD_DIR', sql.Int, data.codDir);
    request.input('COD_DEPTO', sql.Int, data.codDepto);
    
    // Vinculamos todos los campos del formulario desde el objeto 'data'
    request.input('ID_ARANDA', sql.VarChar(50), data.idAranda);
    request.input('UNIDAD_SOLICITANTE', sql.Int, data.unidadSolicitante);
    request.input('COD_CATEGORIA', sql.Int, data.codCategoria);
    request.input('COD_RELACION', sql.Int, data.codRelacion);
    request.input('COD_TIPO', sql.Int, data.codTipo);
    request.input('COD_PRIORIDAD', sql.Int, data.codPrioridad);
    request.input('DESC_PROYECTO', sql.VarChar(255), data.descripcion);
    request.input('ALCANCE_PROYECTO', sql.VarChar(600), data.alcance);
    request.input('FECHA_INICIAL_PLANIFICADA', sql.Date, data.fechaInicial);
    request.input('FECHA_FINAL_PLANIFICADA', sql.Date, data.fechaFinal);
    request.input('MONTO_INVERSION', sql.Decimal(18, 2), data.inversion);

    request.input('ID_PROYECTO_RELACIONADO', sql.Int, data.idProyectoRelacionado);
    request.input('TIPO_RELACION', sql.VarChar(50), data.tipoRelacion);

    // Ejecutamos el Stored Procedure
    await request.execute('SP_EDITAR_PROYECTO_PLANIFICADO');
    
    return { message: 'Proyecto actualizado en planificación.' };
};