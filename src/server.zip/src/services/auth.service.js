import sql from 'mssql';

/**
 * Valida las credenciales del usuario contra la base de datos.
 * @param {import('fastify').FastifyInstance} fastify - La instancia del servidor Fastify.
 * @param {string} usuario_nt - El nombre de usuario NT.
 * @param {string} contrasena - La contraseña para la simulación.
 * @returns {Promise<object|null>} El objeto del usuario si es válido, o null si no lo es.
 */
export const validateUserCredentials = async (fastify, usuario_nt, contrasena) => {
  const pool = fastify.mssql; // Obtenemos el pool desde fastify
  try {
    const request = pool.request();
    request.input('USUARIO_NT', sql.VarChar, usuario_nt);
    request.input('CONTRASENA', sql.VarChar, contrasena);

    const result = await request.execute('SP_LOGIN');

    return result.recordset.length > 0 ? result.recordset[0] : null;
  } catch (error) {
    fastify.log.error(error, 'Error en el servicio de autenticación');
    throw new Error('Error al validar credenciales en la base de datos.');
  }
};