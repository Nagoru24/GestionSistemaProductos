import sql from 'mssql';

// Obtener colaboradores asignados a un proyecto
export const getColaboradoresPorProyecto = async (fastify, idProyecto) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('ID_PROYECTO', sql.Int, idProyecto);
  const result = await request.execute('SP_GET_COLABORADORES_POR_PROYECTO');
  return result.recordset;
};

// Eliminar o inactivar un colaborador de un proyecto
export const eliminarColaborador = async (fastify, idProyecto, idFuncionario, usuarioModificacion, justificacion) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('ID_PROYECTO', sql.Int, idProyecto);
  request.input('ID_FUNCIONARIO', sql.Int, idFuncionario);
  request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuarioModificacion);
  request.input('JUSTIFICACION', sql.VarChar(500), justificacion);
  const result = await request.execute('SP_ELIMINAR_COLABORADOR');
  return { success: true, message: result.recordset[0]?.Mensaje || 
    (result.returnValue === 0 ? 'Operación completada exitosamente' : 'Error en la operación') };
};

// Modificar asignarColaboradores para manejar errores de duplicados
export const asignarColaboradores = async (fastify, idProyecto, usuarioAsignacion, colaboradores) => {
  const pool = fastify.mssql;
  const request = pool.request();
  const xmlColaboradores = `<ids>${colaboradores.map(id => `<id>${id}</id>`).join('')}</ids>`;
  request.input('ID_PROYECTO', sql.Int, idProyecto);
  request.input('USUARIO_ASIGNACION', sql.VarChar(100), usuarioAsignacion);
  request.input('COLABORADORES', sql.Xml, xmlColaboradores);
  try {
    const result = await request.execute('SP_ASIGNAR_COLABORADORES');
    return { success: true, message: 'Colaboradores asignados exitosamente' };
  } catch (error) {
    if (error.number === 50003) {
      throw new Error('Uno o más colaboradores ya están asignados al proyecto.');
    }
    throw error;
  }
};

// Servicios existentes (sin cambios)
export const getColaboradoresPorDepartamento = async (fastify, codDir, codDepto) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('COD_DIR', sql.Int, codDir);
  request.input('COD_DEPTO', sql.Int, codDepto);
  const result = await request.execute('SP_GET_COLABORADORES_POR_DEPARTAMENTO');
  return result.recordset;
};

export const getProyectoPorId = async (fastify, idProyecto) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('ID_PROYECTO', sql.Int, idProyecto);
  const result = await request.execute('SP_GET_PROYECTO_POR_ID');
  return result.recordset[0];
};

export const getProyectosPorFuncionario = async (fastify, idFuncionario) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('ID_FUNCIONARIO', sql.Int, idFuncionario);
  const result = await request.execute('SP_GET_PROYECTOS_POR_FUNCIONARIO');
  return result.recordset;
};