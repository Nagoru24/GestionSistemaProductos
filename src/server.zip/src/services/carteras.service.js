// src/services/carteras.service.js
import sql from 'mssql';

/**
 * Llama al SP para obtener la cartera "Por Aprobar" de un gerente o crearla si no existe.
 */
export const getOrCreateCartera = async (fastify, idGerente, usuarioCreacion) => {
  const pool = fastify.mssql;
  const request = pool.request();
  const periodo = new Date().getFullYear();

  request.input('ID_GERENTE', sql.Int, idGerente);
  request.input('PERIODO', sql.Int, periodo);
  request.input('USUARIO_CREACION', sql.VarChar(100), usuarioCreacion);

  const result = await request.execute('SP_GET_OR_CREATE_CARTERA');
  
  const cartera = result.recordsets[0]?.[0] || null;
  const proyectos = result.recordsets[1] || [];

  if (!cartera) {
    throw new Error('No se pudo obtener o crear la cartera.');
  }

  return { cartera, proyectos };
};

/**
 * Llama al SP para añadir un nuevo proyecto a una cartera existente.
 * @param {object} fastify - Instancia de Fastify.
 * @param {object} projectData - Datos del proyecto a añadir.
 * @returns {Promise<object>} - El proyecto recién creado.
 */
export const addProyectoToCartera = async (fastify, projectData) => {
  const pool = fastify.mssql;
  const request = pool.request();

  // Desestructuramos para asegurar que usamos las variables correctas
  const {
    idCartera, idGerente, usuarioCreacion, idAranda, descripcion, alcance,
    fechaInicial, fechaFinal, inversion, unidadSolicitante, codCategoria,
    codTipo, codPrioridad, codRelacion, idProyectoRelacionado, tipoRelacion
  } = projectData;

  request.input('ID_CARTERA', sql.Int, idCartera);
  request.input('ID_GERENTE', sql.Int, idGerente);
  request.input('USUARIO_CREACION', sql.VarChar(100), usuarioCreacion);
  request.input('ID_ARANDA', sql.VarChar(50), idAranda);
  request.input('DESC_PROYECTO', sql.VarChar(255), descripcion);
  request.input('ALCANCE_PROYECTO', sql.VarChar(600), alcance);
  request.input('FECHA_INICIAL_PLANIFICADA', sql.Date, fechaInicial);
  request.input('FECHA_FINAL_PLANIFICADA', sql.Date, fechaFinal);
  request.input('MONTO_INVERSION', sql.Decimal(18, 2), inversion);
  request.input('UNIDAD_SOLICITANTE', sql.Int, unidadSolicitante);
  request.input('COD_CATEGORIA', sql.Int, codCategoria);
  request.input('COD_TIPO', sql.Int, codTipo);
  request.input('COD_PRIORIDAD', sql.Int, codPrioridad);
  request.input('COD_RELACION', sql.Int, codRelacion);
  
  // Estos son los campos clave. Al desestructurarlos, nos aseguramos de
  // pasar su valor al SP, incluso si en el objeto 'projectData' se llaman diferente.
  request.input('ID_PROYECTO_RELACIONADO', sql.Int, idProyectoRelacionado);
  request.input('TIPO_RELACION', sql.VarChar(50), tipoRelacion);

  const result = await request.execute('SP_ADD_PROYECTO_A_CARTERA');
  
  return result.recordset[0];
};

/**
 * Llama al SP para editar un proyecto existente en una cartera.
 * @param {object} fastify - Instancia de Fastify.
 * @param {number} idProyecto - ID del proyecto a editar.
 * @param {object} projectData - Datos del proyecto a modificar.
 * @returns {Promise<object>} - El proyecto actualizado.
 */
export const editProyectoInCartera = async (fastify, idProyecto, projectData) => {
  const pool = fastify.mssql;
  const request = pool.request();

  request.input('ID_PROYECTO', sql.Int, idProyecto);
  request.input('USUARIO_MODIFICACION', sql.VarChar(100), projectData.usuarioModificacion);
  
  // Mapeo de campos del formulario
  request.input('ID_ARANDA', sql.VarChar(50), projectData.idAranda);
  request.input('DESC_PROYECTO', sql.VarChar(255), projectData.descripcion);
  request.input('ALCANCE_PROYECTO', sql.VarChar(600), projectData.alcance);
  request.input('FECHA_INICIAL_PLANIFICADA', sql.Date, projectData.fechaInicial);
  request.input('FECHA_FINAL_PLANIFICADA', sql.Date, projectData.fechaFinal);
  request.input('MONTO_INVERSION', sql.Decimal(18, 2), projectData.inversion);
  
  // Mapeo de los IDs de los SelectFields
  request.input('UNIDAD_SOLICITANTE', sql.Int, projectData.unidadSolicitante);
  request.input('COD_CATEGORIA', sql.Int, projectData.codCategoria);
  request.input('COD_TIPO', sql.Int, projectData.codTipo);
  request.input('COD_PRIORIDAD', sql.Int, projectData.codPrioridad);
  request.input('COD_RELACION', sql.Int, projectData.codRelacion);
  
  // Mapeo de la relación de proyectos
  request.input('ID_PROYECTO_RELACIONADO', sql.Int, projectData.idProyectoRelacionado);
  request.input('TIPO_RELACION', sql.VarChar(50), projectData.tipoRelacion);

  // --- FIN DE LA SOLUCIÓN ---

  const result = await request.execute('SP_EDITAR_PROYECTO_EN_CARTERA');
  return result.recordset[0];
};

export const getProyectoCarteraById = async (fastify, idProyecto) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('ID_PROYECTO', sql.Int, idProyecto);
  const result = await request.execute('SP_GET_PROYECTO_CARTERA_BY_ID');
  
  if (!result.recordset[0]) {
    throw new Error('Proyecto no encontrado o no editable.');
  }
  return result.recordset[0];
};

/**
 * Llama al SP para obtener la lista de proyectos de una gerencia que pueden ser relacionados.
 */
export const getProyectosParaRelacionar = async (fastify, codDir, codDepto) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('COD_DIR', sql.Int, codDir);
  request.input('COD_DEPTO', sql.Int, codDepto);
  const result = await request.execute('SP_GET_PROYECTOS_PARA_RELACIONAR');
  return result.recordset;
};

/**
 * Llama al SP para aprobar una cartera completa.
 */
export const aprobarCartera = async (fastify, idCartera, usuarioAprobacion) => {
  const pool = fastify.mssql;
  const request = pool.request();
  request.input('ID_CARTERA', sql.Int, idCartera);
  request.input('USUARIO_APROBACION', sql.VarChar(100), usuarioAprobacion);
  await request.execute('SP_APROBAR_CARTERA');
  return { message: 'Cartera aprobada y proyectos puestos en ejecución exitosamente.' };
};


// src/services/carteras.service.js

export const deleteProyectoFromCartera = async (fastify, idProyecto, idGerente, usuarioModificacion) => {
  const pool = fastify.mssql;
  const request = pool.request();

  // Se añaden los 3 parámetros que el SP espera
  request.input('ID_PROYECTO', sql.Int, idProyecto);
  request.input('ID_GERENTE', sql.Int, idGerente);
  request.input('USUARIO_MODIFICACION', sql.VarChar(100), usuarioModificacion);

  // Se llama al SP con el nombre correcto
  await request.execute('SP_DELETE_PROYECTO_DE_CARTERA');
};