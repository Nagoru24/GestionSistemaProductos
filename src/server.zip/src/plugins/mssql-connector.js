import fp from 'fastify-plugin';
import sql from 'mssql';

async function mssqlPlugin(fastify, options) {
  //console.log('Configuración recibida:', options);
  const pool = new sql.ConnectionPool(options);
  try {
    await pool.connect();
    fastify.decorate('mssql', pool);
    fastify.log.info('Conectado a SQL Server');
  } catch (err) {
    fastify.log.error('Error conectando a SQL Server:', err);
    throw err;
  }

  fastify.addHook('onClose', async () => {
    await pool.close();
  });
}

export default fp(mssqlPlugin);