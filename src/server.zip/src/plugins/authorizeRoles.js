import fp from 'fastify-plugin';

/**
 * Plugin de autorización basado en roles.
 * Crea un decorador 'authorizeRoles' que es una factoría.
 * Acepta un array de roles permitidos y devuelve un hook preHandler.
 */
async function authorizeRolesPlugin(fastify, options) {
  // Se decora con 'authorizeRoles' para no entrar en conflicto con tu 'authorize' existente.
  fastify.decorate('authorizeRoles', (allowedRoles = []) => {
    // Devuelve la función hook que Fastify espera.
    return async function (request, reply) {
      try {
        if (!request.user || !request.user.rol) {
          // Esto no debería pasar si 'authenticate' se ejecuta primero.
          throw new Error('No hay información de rol del usuario.');
        }

        const userRole = request.user.rol;

        // Verifica si el rol del usuario está incluido en la lista de roles permitidos.
        if (!allowedRoles.some(allowedRole => allowedRole === userRole || allowedRole === request.user.rol.COD_ROL)) { // Compara tanto string como número si es necesario
          reply.code(403).send({ error: 'Acceso prohibido. Tu rol no tiene permiso para este recurso.' });
          return;
        }
        
        // Si el rol es válido, la petición continúa.
      } catch (err) {
        fastify.log.error(err, 'Error en el plugin de authorizeRoles');
        reply.code(500).send({ error: 'Error interno del servidor durante la autorización.' });
      }
    };
  });
}

export default fp(authorizeRolesPlugin);