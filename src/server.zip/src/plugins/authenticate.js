import fp from 'fastify-plugin';

async function authenticatePlugin(fastify, options) {
  fastify.decorate('authenticate', async (request, reply) => {
    try {
      // Verifica el token en el header 'Authorization: Bearer <token>'
      // y añade el payload decodificado a request.user.
      await request.jwtVerify();
    } catch (err) {
      // Si el token es inválido, ausente o expirado, envía un error.
      reply.code(401).send({ error: 'No autorizado. Se requiere un token válido.' });
    }
  });
}

export default fp(authenticatePlugin);