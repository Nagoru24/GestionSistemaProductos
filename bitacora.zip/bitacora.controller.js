/**
 * @fileoverview Controladores para el módulo de Bitácoras.
 * Maneja las solicitudes HTTP y se comunica con el servicio de bitácoras.
 */

import {
  getBitacoraCambios,
  getBitacoraPlanificacion,
  getBitacoraRecursos
} from '../services/bitacora.service.js';

/**
 * @description Controlador para obtener la bitácora de cambios.
 * @param {import('fastify').FastifyRequest} request - Objeto de solicitud de Fastify.
 * @param {import('fastify').FastifyReply} reply - Objeto de respuesta de Fastify.
 */
export const getBitacoraCambiosHandler = async (request, reply) => {
  try {
    const data = await getBitacoraCambios(request.server, request.query);
    reply.code(200).send(data);
  } catch (error) {
    request.log.error(error);
    reply.code(500).send({ message: 'Error al obtener la bitácora de cambios.', error: error.message });
  }
};

/**
 * @description Controlador para obtener la bitácora de planificación.
 * @param {import('fastify').FastifyRequest} request - Objeto de solicitud de Fastify.
 * @param {import('fastify').FastifyReply} reply - Objeto de respuesta de Fastify.
 */
export const getBitacoraPlanificacionHandler = async (request, reply) => {
  try {
    const data = await getBitacoraPlanificacion(request.server, request.query);
    reply.code(200).send(data);
  } catch (error) {
    request.log.error(error);
    reply.code(500).send({ message: 'Error al obtener la bitácora de planificación.', error: error.message });
  }
};

/**
 * @description Controlador para obtener la bitácora de recursos.
 * @param {import('fastify').FastifyRequest} request - Objeto de solicitud de Fastify.
 * @param {import('fastify').FastifyReply} reply - Objeto de respuesta de Fastify.
 */
export const getBitacoraRecursosHandler = async (request, reply) => {
  try {
    const data = await getBitacoraRecursos(request.server, request.query);
    reply.code(200).send(data);
  } catch (error) {
    request.log.error(error);
    reply.code(500).send({ message: 'Error al obtener la bitácora de recursos.', error: error.message });
  }
};