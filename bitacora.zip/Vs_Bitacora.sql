-- =============================================================================================
-- VISTA 1: V_BITACORA_CAMBIOS_PROYECTO
-- Prop�sito: Ofrece un registro detallado y enriquecido de todos los cambios realizados
--            en los proyectos, bas�ndose en la tabla de auditor�a. Es la vista central
--            para el seguimiento de eventos.
-- =============================================================================================
CREATE OR ALTER VIEW V_BITACORA_CAMBIOS_PROYECTO AS
SELECT
    -- Informaci�n del Evento de Auditor�a
    AUD.ID_AUDITORIA,
    AUD.FECHA_EVENTO,
    AUD.HORA_EVENTO,
    AUD.ACCION,
    AUD.ENTIDAD AS ENTIDAD_AFECTADA,
    AUD.CAMPO_MODIFICADO,
    AUD.VALOR_ANTERIOR,
    AUD.VALOR_NUEVO,

    -- Justificaci�n Unificada
    COALESCE(
        AUD.MOTIVO_EVENTO,
        AUD.JUSTIFICACION_CAMBIO_AVANCE,
        AUD.JUSTIFICACION_CAMBIO_FECHAS,
        AUD.JUSTIFICACION_CAMBIO_ESTATUS,
        AUD.JUSTIFICACION_RECLASIFICACION,
        AUD.JUSTIFICACION_CAMBIO_ASIGNACION
    ) AS JUSTIFICACION,

    -- Informaci�n del Usuario que realiz� la acci�n
    AUD.USUARIO AS USUARIO_NT_ACCION,
    ISNULL(FUNC_ACCION.PRIMER_NOMBRE + ' ' + FUNC_ACCION.APELLIDO_PATERNO, AUD.USUARIO) AS USUARIO_ACCION,

    -- Informaci�n del Proyecto afectado
    PROY.ID_PROYECTO,
    PROY.DESC_PROYECTO,
    
    -- Origen del Proyecto (Cartera o Demanda)
    CASE 
        WHEN PROY.ID_CARTERA IS NULL THEN 'Demanda'
        ELSE 'Cartera'
    END AS ORIGEN_PROYECTO,

    -- Informaci�n de la Cartera (si aplica)
    CART.ID_CARTERA,
    CART.NOMBRE_CARTERA,
    CART.PERIODO AS PERIODO_CARTERA,

    -- Informaci�n de la Gerencia
    DEP.DESC_DEPARTAMENTO AS GERENCIA_PROYECTO

FROM
    dbo.T_DIM_AUDITORIA AS AUD
    -- Unimos con Proyectos para obtener el contexto del proyecto afectado.
    -- LEFT JOIN porque algunas acciones de auditor�a podr�an no tener un ID de registro (aunque es raro).
LEFT JOIN
    dbo.T_FACT_PROYECTO AS PROY ON AUD.ID_REGISTRO = PROY.ID_PROYECTO
    -- Unimos con Funcionarios para obtener el nombre de qui�n realiz� la acci�n.
LEFT JOIN
    dbo.T_DIM_FUNCIONARIO AS FUNC_ACCION ON AUD.USUARIO = FUNC_ACCION.USUARIO_NT
    -- Unimos con Cartera para identificar el origen del proyecto.
LEFT JOIN
    dbo.T_DIM_CARTERA AS CART ON PROY.ID_CARTERA = CART.ID_CARTERA
    -- Unimos con Departamento para saber a qu� gerencia pertenece el proyecto.
LEFT JOIN
    dbo.T_DIM_DEPARTAMENTO AS DEP ON PROY.COD_DIR = DEP.COD_DIR AND PROY.COD_DEPTO = DEP.COD_DEPTO;
GO

-- =============================================================================================
-- VISTA 2: V_BITACORA_PLANIFICADO_VS_REAL
-- Prop�sito: Facilita la comparaci�n directa entre las fechas y costos planificados y
--            los reales, permitiendo analizar desviaciones y el impacto de los proyectos
--            de demanda sobre la planificaci�n anual.
-- =============================================================================================
CREATE OR ALTER VIEW V_BITACORA_PLANIFICADO_VS_REAL AS
SELECT
    -- Identificaci�n del Proyecto
    P.ID_PROYECTO,
    P.DESC_PROYECTO,
    P.PERIODO,
    
    -- Origen del Proyecto
    CASE 
        WHEN P.ID_CARTERA IS NULL THEN 'Demanda'
        ELSE 'Cartera'
    END AS ORIGEN_PROYECTO,
    
    -- Fechas Planificadas vs. Reales
    P.FECHA_INICIAL_PLANIFICADA,
    P.FECHA_FINAL_PLANIFICADA,
    P.FECHA_INICIAL_REAL,
    P.FECHA_FINAL_REAL,
    
    -- C�lculo de Desviaciones en d�as
    DATEDIFF(day, P.FECHA_INICIAL_PLANIFICADA, P.FECHA_INICIAL_REAL) AS DESVIACION_DIAS_INICIO,
    DATEDIFF(day, P.FECHA_FINAL_PLANIFICADA, P.FECHA_FINAL_REAL) AS DESVIACION_DIAS_FIN,
    
    -- Informaci�n de la Gerencia y Cartera
    D.DESC_DEPARTAMENTO AS GERENCIA_RESPONSABLE,
    C.NOMBRE_CARTERA,
    
    -- Estatus actual del proyecto
    E.DESC_ESTATUS

FROM
    dbo.T_FACT_PROYECTO AS P
    -- Joins para enriquecer los datos con descripciones
LEFT JOIN
    dbo.T_DIM_CARTERA AS C ON P.ID_CARTERA = C.ID_CARTERA
LEFT JOIN
    dbo.T_DIM_DEPARTAMENTO AS D ON P.COD_DIR = D.COD_DIR AND P.COD_DEPTO = D.COD_DEPTO
LEFT JOIN
    dbo.T_DIM_ESTATUS_PROYECTO AS E ON P.COD_ESTATUS = E.COD_ESTATUS
WHERE
    P.ESTADO_REGISTRO = 1; -- Considerar solo proyectos activos
GO

-- =============================================================================================
-- VISTA 3: V_BITACORA_ASIGNACION_RECURSOS
-- Prop�sito: Proporciona una visi�n clara de qu� colaboradores est�n o estuvieron asignados
--            a qu� proyectos, cu�ndo fueron asignados y su estado actual. Es clave para
--            entender la carga de trabajo y la participaci�n del personal.
-- =============================================================================================
CREATE OR ALTER VIEW V_BITACORA_ASIGNACION_RECURSOS AS
SELECT
    -- Informaci�n de la Relaci�n
    RF.ID_PROYECTO,
    RF.ID_FUNCIONARIO AS ID_COLABORADOR,
    
    -- Detalles del Proyecto
    P.DESC_PROYECTO,
    
    -- Detalles del Colaborador Asignado
    ISNULL(F.PRIMER_NOMBRE, '') + ' ' + ISNULL(F.APELLIDO_PATERNO, '') AS NOMBRE_COLABORADOR,
    R.NOMBRE_ROL AS ROL_COLABORADOR,
    
    -- Fechas y Estado de la Asignaci�n
    RF.FECHA_ASIGNACION,
    RF.FECHA_MODIFICACION AS FECHA_ULTIMA_MODIFICACION,
    ER.DESC_ESTADO AS ESTADO_ASIGNACION, -- 'Activo' o 'Inactivo'
    
    -- Usuarios que gestionaron la asignaci�n
    RF.USUARIO_ASIGNACION,
    RF.USUARIO_MODIFICACION

FROM
    dbo.T_REL_FUNCIONARIO AS RF
    -- Unimos con Proyectos para obtener el nombre del proyecto
INNER JOIN
    dbo.T_FACT_PROYECTO AS P ON RF.ID_PROYECTO = P.ID_PROYECTO
    -- Unimos con Funcionarios para obtener los datos del colaborador
INNER JOIN
    dbo.T_DIM_FUNCIONARIO AS F ON RF.ID_FUNCIONARIO = F.ID_FUNCIONARIO
    -- Unimos con Roles para saber el rol del colaborador
LEFT JOIN
    dbo.T_DIM_ROL AS R ON F.COD_ROL = R.COD_ROL
    -- Unimos con Estado de Registro para obtener la descripci�n del estado
INNER JOIN
    dbo.T_DIM_ESTADO_REGISTRO AS ER ON RF.ESTADO_REGISTRO = ER.COD_ESTADO;
GO

-------------  STORED PROCEDURES PARA EL M�DULO DE BIT�CORAS   ---------------------

-- =============================================================================================
-- SP 1: SP_GET_BITACORA_CAMBIOS
-- Prop�sito: Recupera el historial de cambios de los proyectos desde la vista
--            V_BITACORA_CAMBIOS_PROYECTO, permitiendo m�ltiples filtros din�micos.
-- Par�metros:
--   @FechaInicio:      Filtra eventos a partir de esta fecha.
--   @FechaFin:         Filtra eventos hasta esta fecha.
--   @IDProyecto:       Filtra eventos para un proyecto espec�fico.
--   @UsuarioNT:        Filtra por el usuario que realiz� la acci�n.
--   @Origen:           Filtra por 'Cartera' o 'Demanda'.
--   @Accion:           Filtra por una acci�n espec�fica (ej. 'PAUSAR', 'INSERT').
-- Ejemplo:
--   EXEC SP_GET_BITACORA_CAMBIOS @FechaInicio = '2024-01-01', @IDProyecto = 5;
-- =============================================================================================
CREATE OR ALTER PROCEDURE SP_GET_BITACORA_CAMBIOS
    @FechaInicio DATE = NULL,
    @FechaFin DATE = NULL,
    @IDProyecto INT = NULL,
    @UsuarioNT VARCHAR(100) = NULL,
    @Origen VARCHAR(50) = NULL,
    @Accion VARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID_AUDITORIA,
        FECHA_EVENTO,
        HORA_EVENTO,
        ACCION,
        ENTIDAD_AFECTADA,
        JUSTIFICACION,
        USUARIO_ACCION,
        ID_PROYECTO,
        DESC_PROYECTO,
        ORIGEN_PROYECTO,
        NOMBRE_CARTERA,
        PERIODO_CARTERA,
        GERENCIA_PROYECTO
    FROM
        V_BITACORA_CAMBIOS_PROYECTO
    WHERE
        -- El patr�n (@Param IS NULL OR Columna = @Param) permite que el filtro sea opcional.
        -- Si el par�metro es NULL, la condici�n se vuelve verdadera y no filtra por esa columna.
        (@FechaInicio IS NULL OR FECHA_EVENTO >= @FechaInicio) AND
        (@FechaFin IS NULL OR FECHA_EVENTO <= @FechaFin) AND
        (@IDProyecto IS NULL OR ID_PROYECTO = @IDProyecto) AND
        (@UsuarioNT IS NULL OR USUARIO_NT_ACCION = @UsuarioNT) AND
        (@Origen IS NULL OR ORIGEN_PROYECTO = @Origen) AND
        (@Accion IS NULL OR ACCION = @Accion)
    ORDER BY
        FECHA_EVENTO DESC; -- Ordenar por los eventos m�s recientes primero.

END;
GO

-- =============================================================================================
-- SP 2: SP_GET_BITACORA_PLANIFICACION
-- Prop�sito: Obtiene los datos de comparaci�n entre lo planificado y lo real desde la vista
--            V_BITACORA_PLANIFICADO_VS_REAL.
-- Par�metros:
--   @Periodo:         Filtra los proyectos por el a�o de planificaci�n.
--   @Gerencia:        Filtra por el nombre de la gerencia responsable.
--   @Origen:          Filtra por 'Cartera' o 'Demanda'.
-- Ejemplo:
--   EXEC SP_GET_BITACORA_PLANIFICACION @Periodo = 2024, @Origen = 'Demanda';
-- =============================================================================================
CREATE OR ALTER PROCEDURE SP_GET_BITACORA_PLANIFICACION
    @Periodo INT = NULL,
    @Gerencia VARCHAR(100) = NULL,
    @Origen VARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID_PROYECTO,
        DESC_PROYECTO,
        PERIODO,
        ORIGEN_PROYECTO,
        FECHA_INICIAL_PLANIFICADA,
        FECHA_FINAL_PLANIFICADA,
        FECHA_INICIAL_REAL,
        FECHA_FINAL_REAL,
        DESVIACION_DIAS_INICIO,
        DESVIACION_DIAS_FIN,
        GERENCIA_RESPONSABLE,
        NOMBRE_CARTERA,
        DESC_ESTATUS
    FROM
        V_BITACORA_PLANIFICADO_VS_REAL
    WHERE
        (@Periodo IS NULL OR PERIODO = @Periodo) AND
        (@Gerencia IS NULL OR GERENCIA_RESPONSABLE = @Gerencia) AND
        (@Origen IS NULL OR ORIGEN_PROYECTO = @Origen)
    ORDER BY
        PERIODO, GERENCIA_RESPONSABLE, ID_PROYECTO;

END;
GO

-- =============================================================================================
-- SP 3: SP_GET_BITACORA_RECURSOS
-- Prop�sito: Consulta el historial de asignaciones de colaboradores a proyectos desde la
--            vista V_BITACORA_ASIGNACION_RECURSOS.
-- Par�metros:
--   @IDProyecto:      Filtra por un proyecto espec�fico.
--   @IDColaborador:   Filtra para ver todos los proyectos de un colaborador.
--   @EstadoAsignacion: Filtra por estado de asignaci�n ('Activo' o 'Inactivo').
-- Ejemplo:
--   EXEC SP_GET_BITACORA_RECURSOS @IDColaborador = 289;
-- =============================================================================================
CREATE OR ALTER PROCEDURE SP_GET_BITACORA_RECURSOS
    @IDProyecto INT = NULL,
    @IDColaborador INT = NULL,
    @EstadoAsignacion VARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ID_PROYECTO,
        DESC_PROYECTO,
        ID_COLABORADOR,
        NOMBRE_COLABORADOR,
        ROL_COLABORADOR,
        FECHA_ASIGNACION,
        FECHA_ULTIMA_MODIFICACION,
        ESTADO_ASIGNACION,
        USUARIO_ASIGNACION,
        USUARIO_MODIFICACION
    FROM
        V_BITACORA_ASIGNACION_RECURSOS
    WHERE
        (@IDProyecto IS NULL OR ID_PROYECTO = @IDProyecto) AND
        (@IDColaborador IS NULL OR ID_COLABORADOR = @IDColaborador) AND
        (@EstadoAsignacion IS NULL OR ESTADO_ASIGNACION = @EstadoAsignacion)
    ORDER BY
        ID_PROYECTO, FECHA_ASIGNACION;

END;
GO


