/**
 * @fileoverview Servicio para la gestión de bitácoras.
 * Interactúa con la base de datos para obtener los registros de auditoría.
 */

import sql from 'mssql';

/**
 * @description Obtiene los registros de la bitácora de cambios.
 * @param {import('fastify').FastifyInstance} fastify - Instancia de Fastify para acceder a la conexión de BD.
 * @param {object} filters - Objeto con los filtros a aplicar en la consulta.
 * @returns {Promise<Array<object>>} Un array con los registros de la bitácora.
 */
export const getBitacoraCambios = async (fastify, filters) => {
  const pool = await fastify.mssql.pool;
  const request = pool.request();

  if (filters) {
    for (const key in filters) {
      if (Object.hasOwnProperty.call(filters, key)) {
        request.input(key, sql.VarChar, filters[key]);
      }
    }
  }

  const result = await request.execute('SP_GET_BITACORA_CAMBIOS');
  return result.recordset;
};

/**
 * @description Obtiene los registros de la bitácora de planificación.
 * @param {import('fastify').FastifyInstance} fastify - Instancia de Fastify para acceder a la conexión de BD.
 * @param {object} filters - Objeto con los filtros a aplicar en la consulta.
 * @returns {Promise<Array<object>>} Un array con los registros de la bitácora.
 */
export const getBitacoraPlanificacion = async (fastify, filters) => {
  const pool = await fastify.mssql.pool;
  const request = pool.request();

  if (filters) {
    for (const key in filters) {
      if (Object.hasOwnProperty.call(filters, key)) {
        request.input(key, sql.VarChar, filters[key]);
      }
    }
  }

  const result = await request.execute('SP_GET_BITACORA_PLANIFICACION');
  return result.recordset;
};

/**
 * @description Obtiene los registros de la bitácora de asignación de recursos.
 * @param {import('fastify').FastifyInstance} fastify - Instancia de Fastify para acceder a la conexión de BD.
 * @param {object} filters - Objeto con los filtros a aplicar en la consulta.
 * @returns {Promise<Array<object>>} Un array con los registros de la bitácora.
 */
export const getBitacoraRecursos = async (fastify, filters) => {
  const pool = await fastify.mssql.pool;
  const request = pool.request();

  if (filters) {
    for (const key in filters) {
      if (Object.hasOwnProperty.call(filters, key)) {
        request.input(key, sql.VarChar, filters[key]);
      }
    }
  }

  const result = await request.execute('SP_GET_BITACORA_RECURSOS');
  return result.recordset;
};