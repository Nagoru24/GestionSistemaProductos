/**
 * @fileoverview Define las rutas para el módulo de Bitácoras.
 */

import {
  getBitacoraCambiosHandler,
  getBitacoraPlanificacionHandler,
  getBitacoraRecursosHandler
} from '../controllers/bitacora.controller.js';

/**
 * @description Configura las rutas para el módulo de bitácoras.
 * @param {import('fastify').FastifyInstance} fastify - Instancia de Fastify.
 * @param {object} options - Opciones de configuración del plugin.
 */
export const bitacorasRoutes = async (fastify, options) => {
  const authOpts = {
    preHandler: [fastify.authenticate],
  };

  fastify.get('/bitacoras/cambios', authOpts, getBitacoraCambiosHandler);
  fastify.get('/bitacoras/planificacion', authOpts, getBitacoraPlanificacionHandler);
  fastify.get('/bitacoras/recursos', authOpts, getBitacoraRecursosHandler);
};