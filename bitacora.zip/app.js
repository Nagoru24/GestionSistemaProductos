/**
 * @fileoverview Archivo principal del servidor Fastify.
 * Configura la conexión a la base de datos, los plugins de seguridad (JWT, CORS)
 * y las rutas necesarias para la autenticación y autorización de usuarios.
 */

import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';

// --- Plugins y configuraciones esenciales para la ejecución ---
import mssqlPlugin from './src/plugins/mssql-connector.js';
import sqlConfig from './src/config/db.config.js';

// --- Plugins y rutas de autenticación ---
import authenticatePlugin from './src/plugins/authenticate.js';
import authorizeRolesPlugin from './src/plugins/authorizeRoles.js';
import authorizePlugin from './src/plugins/authorize.js';
import { authRoutes } from './src/routes/auth.routes.js';

// --- Enpoints de paginas ---
import { proyectosRoutes } from './src/routes/proyectos.routes.js';
import { carterasRoutes } from './src/routes/carteras.routes.js';
import { colaboradoresRoutes } from './src/routes/colaboradores.routes.js';
import { gerenciasRoutes} from './src/routes/gerencias.routes.js';
import { bitacorasRoutes } from './src/routes/bitacoras.routes.js';

// -------------------- INSTANCIA DE FASTIFY --------------------------------------------------------
/**
 * @description Instancia principal de Fastify con el logger activado.
 * @type {import('fastify').FastifyInstance}
 */
const fastify = Fastify({ logger: true });

/**
 * @description Función asíncrona autoejecutable (IIFE) para inicializar el servidor.
 */
(async () => {
  try {
    // -------------------- PLUGINS ESENCIALES PARA LA OPERACIÓN ------------------------------------

    /**
     * @description Registra el plugin de CORS (@fastify/cors).
     * Esto es **indispensable** para permitir que tu frontend (que corre en un origen
     * diferente) pueda hacer peticiones a este backend sin ser bloqueado por el navegador.
     */
    await fastify.register(cors, {
      origin: true, // Permite cualquier origen, ideal para desarrollo.
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'], 
    });

    /**
     * @description Registra el plugin de conexión a SQL Server.
     * Es **crítico** para la autenticación, ya que permite al servidor consultar
     * la base de datos para validar usuarios y contraseñas.
     */
    await fastify.register(mssqlPlugin, sqlConfig);


    // -------------------- REGISTRO DE PLUGINS DE AUTENTICACIÓN ------------------------------------

    /**
     * @description Registra el plugin oficial de JWT (@fastify/jwt).
     * Permite crear y verificar los tokens de sesión.
     */
    await fastify.register(jwt, {
      secret: process.env.JWT_SECRET,
    });

    /**
     * @description Registra el decorador 'authenticate' para validar tokens en rutas protegidas.
     */
    await fastify.register(authenticatePlugin);

    /**
     * @description Registra el decorador 'authorizeRoles' para validar roles.
     */
    await fastify.register(authorizeRolesPlugin);

    /**
     * @description Registra el decorador 'authorize' para validaciones complejas.
     */
    await fastify.register(authorizePlugin);


    // -------------------- REGISTRO DE RUTAS DE AUTENTICACIÓN --------------------------------------
    /**
     * @description Registra las rutas de login (ej. '/auth/login').
     */
    await fastify.register(authRoutes, { prefix: '/auth' });



    // -------------------- REGISTRO DE RUTAS DE PÁGINAS --------------------------------------------
    /**
     * @description Registra las rutas relacionadas con proyectos (ej. '/proyectos').
     */
    await fastify.register(proyectosRoutes);

    /**
     * @description Registra las rutas relacionadas con carteras (ej. '/carteras').
     */
    await fastify.register(carterasRoutes);

    /** 
     * @description Registra las rutas relacionadas con colaboradores (ej. '/colaboradores'). 
     */
    await fastify.register(colaboradoresRoutes);

    /** 
     * @description Registra las rutas relacionadas con gerencias (ej. '/gerencias'). 
     */
    await fastify.register(gerenciasRoutes);

    /** 
     * @description Registra las rutas relacionadas con bitácoras (ej. '/bitacoras'). 
     */
    await fastify.register(bitacorasRoutes);

    
    // -------------------- INICIAR SERVIDOR -----------------------------
    await fastify.listen({ port: 3000 });
    console.log('Servidor de autenticación corriendo en http://localhost:3000');

  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
})();